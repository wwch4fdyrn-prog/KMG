/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, MouseEvent as ReactMouseEvent, TouchEvent as ReactTouchEvent } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

// Attach to window so existing references like (window as any).THREE work perfectly
if (typeof window !== 'undefined') {
  (window as any).THREE = THREE;
}

// Interfaces for Metrology system
interface TargetPoint {
  id: number;
  nominal: [number, number, number];
  measured: [number, number, number] | null;
  deviation: [number, number, number] | null;
  error: number | null; // Euclidean distance of deviation
  status: 'pending' | 'pass' | 'fail';
}

interface LevelConfig {
  id: string;
  name: string;
  description: string;
  tolerance: number; // in mm
  targetCount: number;
}

// Procedural texture generator for more realistic Granite and Aluminium
const createProceduralTexture = (type: 'granite' | 'alu') => {
  const canvas = document.createElement('canvas');
  const size = type === 'granite' ? 1024 : 512;
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext('2d');
  if (context) {
    if (type === 'granite') {
      context.fillStyle = '#15181e'; // Base dark charcoal
      context.fillRect(0, 0, size, size);
      
      // Multi-layered noise for granite specs
      const drawSpecs = (count: number, color: string, rectSize: number) => {
        context.fillStyle = color;
        for (let i = 0; i < count; i++) {
          const x = Math.random() * size;
          const y = Math.random() * size;
          context.fillRect(x, y, Math.random() * rectSize, Math.random() * rectSize);
        }
      };
      drawSpecs(60000, 'rgba(255, 255, 255, 0.08)', 2);
      drawSpecs(40000, 'rgba(255, 255, 255, 0.15)', 1);
      drawSpecs(15000, 'rgba(0, 0, 0, 0.5)', 3);
      drawSpecs(5000, 'rgba(200, 200, 200, 0.3)', 2);
      drawSpecs(1000, 'rgba(100, 150, 200, 0.15)', 4); // subtle blue quartz specs
    } else {
      context.fillStyle = '#b8c0cc'; // Base metallic grey
      context.fillRect(0, 0, size, size);
      
      // Brushed aluminium lines
      for (let i = 0; i < 6000; i++) {
        const y = Math.random() * size;
        const length = 20 + Math.random() * 150;
        const x = Math.random() * size;
        context.fillStyle = `rgba(0, 0, 0, ${Math.random() * 0.04})`;
        context.fillRect(x, y, length, Math.random() * 2);
        context.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.05})`;
        context.fillRect(x + length/2, y + Math.random(), length, Math.random() * 1.5);
      }
    }
  }
  
  return canvas;
};

interface DmisStep {
  originalLineIdx: number;
  text: string;
  type: 'goto' | 'ptmeas' | 'revo' | 'units' | 'other' | 'align' | 'eval';
  args: any;
}

export default function App() {
  // Navigation Tabs: 'steuern' | 'dmis' | 'daten' | 'bibliothek' | 'hilfe'
  const [activeTab, setActiveTab] = useState<'steuern' | 'dmis' | 'daten' | 'bibliothek' | 'hilfe'>('steuern');

  // Training Levels (10 Aufgaben Grundlagenschulung)
  const levels: LevelConfig[] = [
    {
      id: 'calibration',
      name: '1. Kalibrierkugel-Vermessung',
      description: 'Kalibriere den Rubintaster an der Referenzkugel. Taste den höchsten Punkt (Zenit / Scheitelpunkt) an.',
      tolerance: 0.002,
      targetCount: 1,
    },
    {
      id: '321_alignment',
      name: '2. 3-2-1 Ausrichtung',
      description: 'Lerne das Fundament der Messtechnik! Erstelle ein stabiles Bezugssystem. Taste 3 Pkt. für die Hauptebene (Z), 2 Pkt. für die Raumachse (X) und 1 Pkt. für den Nullpunkt (Y) an einem Block.',
      tolerance: 0.050,
      targetCount: 6,
    },
    {
      id: 'plane_measurement',
      name: '3. Ebenenmessung (Ebenheit)',
      description: 'Taste 4 gleichmäßig verteilte Punkte auf der oberen Deckfläche an, um die Ebenheit der Fläche zu bestimmen.',
      tolerance: 0.015,
      targetCount: 4,
    },
    {
      id: 'cylinder',
      name: '4. Zylinder-Rechtwinkligkeit',
      description: 'Prüfe den Außenmantel eines Zylinders an 4 Quadranten, um die Mittelachse und die Rechtwinkligkeit zur Basis zu bestimmen.',
      tolerance: 0.010,
      targetCount: 4,
    },
    {
      id: 'circle_center',
      name: '5. Bohrungsmittelpunkt (Innenkreis)',
      description: 'Fahre in eine Bohrung und taste 3 Punkte an der Innenwand ab, um das Zentrum des Kreises genau zu lokalisieren.',
      tolerance: 0.010,
      targetCount: 3,
    },
    {
      id: 'hole_distance',
      name: '6. Lochabstand messen (2 Bohrungen)',
      description: 'Messe zwei separate Bohrungen durch jeweils 3 Antastungen innen, um die genaue Distanz zwischen den Mittelpunkten zu ermitteln.',
      tolerance: 0.012,
      targetCount: 6,
    },
    {
      id: 'angle_measurement',
      name: '7. Winkelmessung (Schiefe Ebene)',
      description: 'Ermittle den Winkel eines prismatischen Keils. Taste 3 Punkte auf der unteren Basis und 3 auf der schiefen Rampe an.',
      tolerance: 0.020,
      targetCount: 6,
    },
    {
      id: 'parallelism',
      name: '8. Parallelität prüfen (Nut)',
      description: 'Messe die Parallelität einer breiten Längsnut. Taste 3 Punkte an der linken und 3 Punkte an der rechten Innenflanke der Nut.',
      tolerance: 0.010,
      targetCount: 6,
    },
    {
      id: 'head_indexing',
      name: '9. Kopf schwenken (A/B Winkel)',
      description: 'Taste versteckte Seitenflächen an die man vertikal nicht erreicht. Du MUSST den Tastkopf eindrehen (-90° Tilt), um Schaftantastung zu vermeiden!',
      tolerance: 0.010,
      targetCount: 4,
    },
    {
      id: 'complex_part',
      name: '10. Komplextteil (Praxis-Checkmaß)',
      description: 'Abschlussprüfung: Vermesse ein gestuftes Bauteil (2 Zylinderstufen, 1 Deckfläche, 1 Zylinderwandung).',
      tolerance: 0.015,
      targetCount: 4,
    }
  ];

  const [activeLevelIdx, setActiveLevelIdx] = useState<number>(0); // Default to first training
  const activeLevel = levels[activeLevelIdx];

  // Config options (Bibliothek tab)
  const [material, setMaterial] = useState<string>('Alu Matt');
  const [probeSize, setProbeSize] = useState<number>(2.0); // mm
  const [movementSpeed, setMovementSpeed] = useState<'crawl' | 'normal' | 'rapid'>('normal');
  const [isHeadIndexing, setIsHeadIndexing] = useState<boolean>(false);
  const isHeadIndexingRef = useRef<boolean>(false);
  
  useEffect(() => {
    isHeadIndexingRef.current = isHeadIndexing;
  }, [isHeadIndexing]);

  // Metrology and Game state
  const [targetPoints, setTargetPoints] = useState<TargetPoint[]>([]);
  const [collisions, setCollisions] = useState<number>(0);
  const [deviationSum, setDeviationSum] = useState<number>(0);
  const [accuracy, setAccuracy] = useState<number>(100.0);
  const [systemState, setSystemState] = useState<'online' | 'contact' | 'error'>('online');
  const [isLevelFinished, setIsLevelFinished] = useState<boolean>(false);

  // Gamification States
  const [isXrayMode, setIsXrayMode] = useState<boolean>(false);
  const [levelStartTime, setLevelStartTime] = useState<number>(0);
  const [elapsedTimeMs, setElapsedTimeMs] = useState<number>(0);
  const [finalScore, setFinalScore] = useState<number>(0);

  // Gemini report state
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [loadingReport, setLoadingReport] = useState<boolean>(false);
  const [reportError, setReportError] = useState<string | null>(null);

  // Live Position state (for React HUD rendering, polled from Three.js renderer loops)
  const [positionX, setPositionX] = useState<number>(0.0);
  const [positionY, setPositionY] = useState<number>(5.0);
  const [positionZ, setPositionZ] = useState<number>(0.0);
  const [probeAngleA, setProbeAngleA] = useState<number>(0.0);
  const [probeAngleB, setProbeAngleB] = useState<number>(0.0);

  // Manual target / input overrides
  const [controlZVal, setControlZVal] = useState<number>(50); // Slider 0-100
  const [isKeyboardTipsOpen, setIsKeyboardTipsOpen] = useState<boolean>(true);

  // Mobile adaptive layout & fluid analog joystick states
  const [showMobileSettings, setShowMobileSettings] = useState<boolean>(false);
  const [joystickOffset, setJoystickOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const joystickOffsetRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Split Screen and CAD Camera Fly-Drive Features
  const [isSplitScreen, setIsSplitScreen] = useState<boolean>(false);
  const [isVectorJourneyActive, setIsVectorJourneyActive] = useState<boolean>(false);

  // Wenzel DMIS / Denis Interactive Compilation States
  const [dmisCode, setDmisCode] = useState<string>('');
  const [isDmisExecuting, setIsDmisExecuting] = useState<boolean>(false);
  const isDmisExecutingRef = useRef<boolean>(false);
  const [currentStepIdx, setCurrentStepIdx] = useState<number>(-1);
  const currentStepIdxRef = useRef<number>(-1);
  const [activeDmisLineNo, setActiveDmisLineNo] = useState<number>(-1);
  const [dmisConsoleLogs, setDmisConsoleLogs] = useState<string[]>([]);
  const [dmisSteps, setDmisSteps] = useState<DmisStep[]>([]);
  const dmisStepsRef = useRef<DmisStep[]>([]);

  // Wenzel Quartis Ribbon layout active tab state
  const [activeRibbonTab, setActiveRibbonTab] = useState<'start' | 'messen' | 'dmis' | 'bericht' | 'katalog' | 'hilfe'>('start');
  const [isBeginnerMode, setIsBeginnerMode] = useState<boolean>(true); // Enabled by default for flawless rookie user experiences
  const [hasWebglError, setHasWebglError] = useState<boolean>(false);
  const [is2DMode, setIs2DMode] = useState<boolean>(false);

  useEffect(() => {
    if (hasWebglError) {
      setIs2DMode(true);
    }
  }, [hasWebglError]);

  const autoZoomToWorkpiece = () => {
    setIsVectorJourneyActive(false);
    if (!threeRef.current) return;
    const { camera, controls } = threeRef.current;
    const THREE = (window as any).THREE;
    if (!THREE) return;

    // Use a fixed distance scaled by mobile aspect ratio
    const aspect = window.innerWidth / window.innerHeight;
    const baseDist = 5.5; // Perfectly frames the central workpiece
    const dist = aspect < 1 ? baseDist / aspect : baseDist;

    const dir = new THREE.Vector3().subVectors(camera.position, controls.target).normalize();
    const targetCam = controls.target.clone().add(dir.multiplyScalar(dist));
    cameraMoveTargetRef.current = targetCam;
    playCmmSound('beep');
  };

  const focusNextTarget = () => {
    setIsVectorJourneyActive(false);
    if (!threeRef.current) return;
    const { camera, controls } = threeRef.current;
    const THREE = (window as any).THREE;
    if (!THREE) return;

    const pendingTarget = targetPoints.find(t => t.status === 'pending');
    if (pendingTarget) {
      const [nx, ny, nz] = pendingTarget.nominal;
      // move controls target to the point
      const targetLook = new THREE.Vector3(nx, ny, nz);
      controlsTargetMoveTargetRef.current = targetLook;
      
      // move camera close to it
      const dir = new THREE.Vector3().subVectors(camera.position, controls.target).normalize();
      const dist = 3.0; // Close inspection 
      const targetCam = targetLook.clone().add(dir.multiplyScalar(dist));
      cameraMoveTargetRef.current = targetCam;
      playCmmSound('beep');
    }
  };

  const isSplitScreenRef = useRef<boolean>(false);
  const isVectorJourneyActiveRef = useRef<boolean>(false);
  const isBeginnerModeRef = useRef<boolean>(true);
  const cameraMoveTargetRef = useRef<any>(null);
  const controlsTargetMoveTargetRef = useRef<any>(null);
  const viewCubeRef = useRef<HTMLDivElement>(null);
  const dpadRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    isSplitScreenRef.current = isSplitScreen;
  }, [isSplitScreen]);

  useEffect(() => {
    isVectorJourneyActiveRef.current = isVectorJourneyActive;
  }, [isVectorJourneyActive]);

  useEffect(() => {
    isBeginnerModeRef.current = isBeginnerMode;
  }, [isBeginnerMode]);

  useEffect(() => {
    (window as any).revoAngleA = probeAngleA;
    (window as any).revoAngleB = probeAngleB;
  }, [probeAngleA, probeAngleB]);

  // 2D Software Fallback Simulation Loop (when WebGL / GPU-Acceleration is blocked or toggled)
  useEffect(() => {
    if (!is2DMode) return;

    // Initialize state positions if needed
    if ((window as any).cmmTargetX === undefined) {
      (window as any).cmmTargetX = 0;
      (window as any).cmmTargetY = 3.5;
      (window as any).cmmTargetZ = 2.0;
    }
    if ((window as any).cmmCurrentX === undefined) {
      (window as any).cmmCurrentX = 0;
      (window as any).cmmCurrentY = 3.5;
      (window as any).cmmCurrentZ = 2.0;
    }

    let isColliding = false;
    let collisionCooldown = 0;
    let animFrameId: number;

    const animate2D = () => {
      animFrameId = requestAnimationFrame(animate2D);

      const prevX = (window as any).cmmCurrentX;
      const prevY = (window as any).cmmCurrentY;
      const prevZ = (window as any).cmmCurrentZ;

      // Analog joystick continuous update
      const joyX = joystickOffsetRef.current.x;
      const joyY = joystickOffsetRef.current.y;
      if (joyX !== 0 || joyY !== 0) {
        const joySpeed = (window as any).isRapidSpeedEnabled ? 0.08 : 0.015;
        let tX = ((window as any).cmmTargetX || 0) + joyX * joySpeed;
        let tZ = ((window as any).cmmTargetZ || 0) + joyY * joySpeed;
        tX = Math.max(-6.5, Math.min(6.5, tX));
        tZ = Math.max(-6.5, Math.min(6.5, tZ));
        (window as any).cmmTargetX = tX;
        (window as any).cmmTargetZ = tZ;
      }

      let currentSpeed = (window as any).isRapidSpeedEnabled ? 0.08 : 0.035;
      let curX = (window as any).cmmCurrentX;
      let curY = (window as any).cmmCurrentY;
      let curZ = (window as any).cmmCurrentZ;

      const diffX = (window as any).cmmTargetX - curX;
      const diffY = (window as any).cmmTargetY - curY;
      const diffZ = (window as any).cmmTargetZ - curZ;

      if (collisionCooldown > 0) {
        collisionCooldown--;
      }

      // Check boundary collisions using exact physical definitions of each level
      const currentLevelId = levels[activeLevelIdx].id;
      const rubyRadius = 0.15; // virtual units (1.5mm)
      let hitWall = false;
      let minDistanceToContour = Infinity;

      if (currentLevelId === 'calibration') {
        const dist = Math.sqrt(curX*curX + (curY - 1.05)*(curY - 1.05) + curZ*curZ);
        minDistanceToContour = dist - (1.35 + rubyRadius);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === '321_alignment' || currentLevelId === 'plane_measurement' || currentLevelId === 'head_indexing') {
        const dx = Math.max(0, Math.abs(curX) - 1.5);
        const dy = Math.max(0, Math.abs(curY - 0.75) - 0.75);
        const dz = Math.max(0, Math.abs(curZ) - 1.5);
        const distBox = Math.sqrt(dx*dx + dy*dy + dz*dz) - rubyRadius;
        const distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distBox, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'cylinder') {
        const radialDist = Math.sqrt(curX * curX + curZ * curZ);
        const distToSide = radialDist - 1.2;
        const distToTop = Math.abs(curY - 1.0) - 1.0;
        let distCyl = Math.max(distToSide, distToTop);
        if (distCyl > 0) {
          const dx = Math.max(0, radialDist - 1.2);
          const dy = Math.max(0, Math.abs(curY - 1.0) - 1.0);
          distCyl = Math.sqrt(dx*dx + dy*dy);
        }
        distCyl -= rubyRadius;
        const distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distCyl, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'circle_center') {
        const dx = Math.max(0, Math.abs(curX) - 2.0);
        const dy = Math.max(0, Math.abs(curY - 0.75) - 0.75);
        const dz = Math.max(0, Math.abs(curZ) - 2.0);
        let distBox = Math.sqrt(dx*dx + dy*dy + dz*dz);
        const radialDist = Math.sqrt(curX * curX + curZ * curZ);
        if (radialDist < 1.0 && curY > 0 && curY < 1.5) {
          distBox = 1.0 - radialDist; // Inside hollow bore cylinder
        } else if (radialDist < 1.0 && curY >= 1.5) {
          distBox = Math.min(distBox, curY - 1.5);
        }
        distBox -= rubyRadius;
        const distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distBox, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'hole_distance') {
        const dx = Math.max(0, Math.abs(curX) - 2.5); // safe outer check
        const dy = Math.max(0, Math.abs(curY - 0.75) - 0.75);
        const dz = Math.max(0, Math.abs(curZ) - 1.5);
        let distBox = Math.sqrt(dx*dx + dy*dy + dz*dz);
        
        // Check if inside left bore (x = -1.5, r = 0.8) or right bore (x = 1.5, r = 0.8)
        const distL = Math.sqrt((curX - (-1.5))**2 + curZ**2);
        const distR = Math.sqrt((curX - 1.5)**2 + curZ**2);
        if (distL < 0.8 && curY > 0 && curY < 1.5) {
          distBox = 0.8 - distL;
        } else if (distR < 0.8 && curY > 0 && curY < 1.5) {
          distBox = 0.8 - distR;
        } else if ((distL < 0.8 || distR < 0.8) && curY >= 1.5) {
          distBox = Math.min(distBox, curY - 1.5);
        }

        distBox -= rubyRadius;
        const distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distBox, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'angle_measurement') {
        const dx = Math.max(0, Math.abs(curX - 0.5) - 2.0);
        const dz = Math.max(0, Math.abs(curZ) - 1.5);
        const surfaceY = 0.5 + Math.max(0, curX + 1.0) * 0.5;
        const dy = curY < 0 ? -curY : (curY > surfaceY ? curY - surfaceY : 0);
        const distWedge = Math.sqrt(dx*dx + dy*dy + dz*dz) - rubyRadius;
        const distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distWedge, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'parallelism') {
        const dx = Math.max(0, Math.abs(curX) - 1.5);
        const dy = Math.max(0, Math.abs(curY - 0.75) - 0.75);
        const dz = Math.max(0, Math.abs(curZ) - 2.0);
        let distBox = Math.sqrt(dx*dx + dy*dy + dz*dz);
        // Inside slot groove: between X = -0.5 and 0.5, and above slot floor Y = 0.5
        if (curX > -0.5 && curX < 0.5 && curY > 0.5 && curY <= 1.5) {
          distBox = Math.min(curX - (-0.5), 0.5 - curX);
        }
        distBox -= rubyRadius;
        const distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distBox, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else {
        const distFloor = curY - rubyRadius;
        minDistanceToContour = distFloor;
        if (minDistanceToContour <= 0) hitWall = true;
      }

      // Automatically brake 5mm (0.5 units) before contour, slowing down dynamically!
      if (minDistanceToContour < 0.5 && minDistanceToContour > 0 && !hitWall) {
        currentSpeed *= Math.max(0.01, minDistanceToContour / 0.5);
      }

      if (hitWall) {
        curX = prevX;
        curY = prevY;
        curZ = prevZ;

        (window as any).cmmTargetX = curX;
        (window as any).cmmTargetY = curY;
        (window as any).cmmTargetZ = curZ;

        setControlZVal(curY * 20);

        if (!isColliding && collisionCooldown === 0) {
          isColliding = true;
          collisionCooldown = 35;
          setSystemState('error');
          playCmmSound('error');
          triggerProbingOnOverlap();
        }
      } else {
        isColliding = false;
        curX += diffX * currentSpeed;
        curY += diffY * currentSpeed;
        curZ += diffZ * currentSpeed;
        if (systemState === 'error' && Math.abs(diffX) + Math.abs(diffY) + Math.abs(diffZ) > 0.05) {
          setSystemState('online');
        }
      }

      (window as any).cmmCurrentX = curX;
      (window as any).cmmCurrentY = curY;
      (window as any).cmmCurrentZ = curZ;

      // Sync state for React UI elements
      setPositionX(+(curX * 100).toFixed(4));
      setPositionY(+(curY * 100).toFixed(4));
      setPositionZ(+(curZ * 100).toFixed(4));
    };

    animFrameId = requestAnimationFrame(animate2D);
    return () => {
      cancelAnimationFrame(animFrameId);
    };
  }, [is2DMode, activeLevelIdx, systemState]);

  const renderRevoArticulationPanel = (isMobile = false) => (
    <div className={`${isMobile ? 'flex-1 min-w-[240px] mt-2 mb-2 lg:hidden' : 'w-full mt-2'} bg-slate-950/40 p-2 rounded-lg border border-slate-800/80 space-y-2 pointer-events-auto shadow-lg z-50`}>
      <div className="flex items-center gap-1.5 text-[9px] text-slate-400 uppercase tracking-widest font-bold">
        <span className="material-symbols-outlined text-[12px] text-emerald-400">explore</span>
        REVO 5-Axis Articulation
      </div>
      <div className="grid grid-cols-2 gap-2 text-[10px] font-mono mt-1">
        <div className="flex flex-col gap-1 items-center bg-slate-900/50 p-1.5 rounded border border-slate-800 text-slate-300">
          <span className="text-[8px] text-slate-500">A-Achse (Tilt)</span>
          <div className="flex w-full justify-between items-center px-1">
            <button onClick={() => animateHeadRotation(Math.max(-115, probeAngleA - 22.5), probeAngleB)} disabled={isHeadIndexing} className={`hover:text-cyan-400 active:scale-90 px-1 cursor-pointer select-none ${isHeadIndexing ? 'opacity-50 pointer-events-none' : ''}`}>◄</button>
            <span className="font-bold text-cyan-400 min-w-[4ch] text-center">{probeAngleA.toFixed(1)}°</span>
            <button onClick={() => animateHeadRotation(Math.min(115, probeAngleA + 22.5), probeAngleB)} disabled={isHeadIndexing} className={`hover:text-cyan-400 active:scale-90 px-1 cursor-pointer select-none ${isHeadIndexing ? 'opacity-50 pointer-events-none' : ''}`}>►</button>
          </div>
        </div>
        <div className="flex flex-col gap-1 items-center bg-slate-900/50 p-1.5 rounded border border-slate-800 text-slate-300">
          <span className="text-[8px] text-slate-500">B-Achse (Roll)</span>
          <div className="flex w-full justify-between items-center px-1">
            <button onClick={() => animateHeadRotation(probeAngleA, (probeAngleB - 22.5) % 360)} disabled={isHeadIndexing} className={`hover:text-cyan-400 active:scale-90 px-1 cursor-pointer select-none ${isHeadIndexing ? 'opacity-50 pointer-events-none' : ''}`}>◄</button>
            <span className="font-bold text-cyan-400 min-w-[4ch] text-center">{Math.abs(probeAngleB % 360).toFixed(1)}°</span>
            <button onClick={() => animateHeadRotation(probeAngleA, (probeAngleB + 22.5) % 360)} disabled={isHeadIndexing} className={`hover:text-cyan-400 active:scale-90 px-1 cursor-pointer select-none ${isHeadIndexing ? 'opacity-50 pointer-events-none' : ''}`}>►</button>
          </div>
        </div>
      </div>
    </div>
  );

  const animateHeadRotation = (targetA: number, targetB: number) => {
    // Simulate complex indexing
    setIsHeadIndexing(true);
    (window as any).isHeadIndexing = true;
    const startA = probeAngleA;
    const startB = probeAngleB;
    const startTime = performance.now();
    const duration = 1000;
    
    const THREE = (window as any).THREE;
    let shiftBaseTargetX = (window as any).cmmTargetX || 0;
    let shiftBaseTargetY = (window as any).cmmTargetY || 0;
    let shiftBaseTargetZ = (window as any).cmmTargetZ || 0;

    const tipStart = new THREE.Vector3(0, -2.12, 0);
    if (THREE) {
      tipStart.applyEuler(new THREE.Euler(THREE.MathUtils.degToRad(startA), 0, 0));
      tipStart.add(new THREE.Vector3(0, -0.4, 0));
      tipStart.applyEuler(new THREE.Euler(0, THREE.MathUtils.degToRad(startB), 0));
      tipStart.add(new THREE.Vector3(0, -0.1, 0));
    }

    const animate = (time: number) => {
      const elapsed = time - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const ease = progress < 0.5 ? 2 * progress * progress : 1 - Math.pow(-2 * progress + 2, 2) / 2;
      
      const curA = startA + (targetA - startA) * ease;
      const curB = startB + (targetB - startB) * ease;
      setProbeAngleA(curA);
      setProbeAngleB(curB);
      
      // Instantly sync for smooth 3D rendering without 1-frame React state delays
      (window as any).revoAngleA = curA;
      (window as any).revoAngleB = curB;
      
      if (THREE) {
        const tipCur = new THREE.Vector3(0, -2.12, 0);
        tipCur.applyEuler(new THREE.Euler(THREE.MathUtils.degToRad(curA), 0, 0));
        tipCur.add(new THREE.Vector3(0, -0.4, 0));
        tipCur.applyEuler(new THREE.Euler(0, THREE.MathUtils.degToRad(curB), 0));
        tipCur.add(new THREE.Vector3(0, -0.1, 0));

        const shiftX = tipCur.x - tipStart.x;
        const shiftY = tipCur.y - tipStart.y;
        const shiftZ = tipCur.z - tipStart.z;

        // Apply shift continuously so the quill stays strictly fixed and the ruby ball moves in an arc
        (window as any).cmmTargetX = shiftBaseTargetX + shiftX;
        (window as any).cmmTargetY = shiftBaseTargetY + shiftY;
        (window as any).cmmTargetZ = shiftBaseTargetZ + shiftZ;
        (window as any).cmmCurrentX = shiftBaseTargetX + shiftX;
        (window as any).cmmCurrentY = shiftBaseTargetY + shiftY;
        (window as any).cmmCurrentZ = shiftBaseTargetZ + shiftZ;
        
        setControlZVal(Math.max(0, Math.min(100, ((window as any).cmmTargetY / 5) * 100)));
      }
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setIsHeadIndexing(false);
        (window as any).isHeadIndexing = false;
        setProbeAngleA(targetA);
        setProbeAngleB(targetB);
        
        (window as any).revoAngleA = targetA;
        (window as any).revoAngleB = targetB;
      }
    };
    
    requestAnimationFrame(animate);
  };



  // 3D Canvas Reference
  const canvasContainerRef = useRef<HTMLDivElement>(null);

  // Three.js instances via Ref to keep them alive between tab changes
  const threeRef = useRef<{
    scene: any;
    camera: any;
    renderer: any;
    quill: any;
    probeHead: any;
    stylus: any;
    targetsGroup: any;
    workpieceGroup: any;
    splineCurve?: any;
    levelId?: string;
    keyboardHandlers?: any;
  } | null>(null);

  // Current targets state backup for the Three.js loop to read/write safely without closures locks
  const targetsBackupRef = useRef<TargetPoint[]>([]);
  targetsBackupRef.current = targetPoints;

  // Initialize targets based on level
  useEffect(() => {
    initTargetsForLevel();
  }, [activeLevelIdx]);

  // Gamification Timer
  useEffect(() => {
    let timer: number;
    if (!isLevelFinished && levelStartTime > 0) {
      timer = window.setInterval(() => {
        setElapsedTimeMs(Date.now() - levelStartTime);
      }, 100);
    }
    return () => clearInterval(timer);
  }, [isLevelFinished, levelStartTime]);

  useEffect(() => {
    // Synchronize Three.js workpiece when level or material changes
    if (threeRef.current) {
      updateThreeWorkpiece();
    }
  }, [activeLevelIdx, material, probeSize, isXrayMode]);

  const initTargetsForLevel = () => {
    let pts: TargetPoint[] = [];
    const level = levels[activeLevelIdx];

    if (level.id === 'calibration') {
      pts = [
        { id: 1, nominal: [0, 2.52, 0], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    } else if (level.id === '321_alignment') {
      pts = [
        // 3 points on Top surface (Spatial Alignment / Z-Axis Reference)
        { id: 1, nominal: [-1.0, 1.5, 0.5], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 2, nominal: [1.0, 1.5, 0.5], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 3, nominal: [0.0, 1.5, -0.5], measured: null, deviation: null, error: null, status: 'pending' },
        // 2 points on Front surface (Planar Alignment / Rotation)
        { id: 4, nominal: [-0.8, 0.8, 1.5], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 5, nominal: [0.8, 0.8, 1.5], measured: null, deviation: null, error: null, status: 'pending' },
        // 1 point on Left surface (Origin / Translation)
        { id: 6, nominal: [-1.5, 0.8, 0.0], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    } else if (level.id === 'plane_measurement') {
      pts = [
        { id: 1, nominal: [-1.2, 1.5, -1.2], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 2, nominal: [1.2, 1.5, -1.2], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 3, nominal: [1.2, 1.5, 1.2], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 4, nominal: [-1.2, 1.5, 1.2], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    } else if (level.id === 'cylinder') {
      pts = [
        { id: 1, nominal: [1.5, 1.0, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 2, nominal: [0, 1.0, 1.5], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 3, nominal: [-1.5, 1.0, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 4, nominal: [0, 1.0, -1.5], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    } else if (level.id === 'circle_center') {
      pts = [
        { id: 1, nominal: [1.0, 0.5, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 2, nominal: [-0.5, 0.5, 0.866], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 3, nominal: [-0.5, 0.5, -0.866], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    } else if (level.id === 'hole_distance') {
      // 2 holes, 3 pts each. Hole 1 center: (-1.5, 0), Hole 2 center: (1.5, 0)
      pts = [
        { id: 1, nominal: [-0.5, 0.5, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 2, nominal: [-2.0, 0.5, 0.866], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 3, nominal: [-2.0, 0.5, -0.866], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 4, nominal: [2.5, 0.5, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 5, nominal: [1.0, 0.5, 0.866], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 6, nominal: [1.0, 0.5, -0.866], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    } else if (level.id === 'angle_measurement') {
      pts = [
        // Base plane
        { id: 1, nominal: [-1.0, 0.5, -1.0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 2, nominal: [-1.0, 0.5, 1.0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 3, nominal: [0.0, 0.5, 0.0], measured: null, deviation: null, error: null, status: 'pending' },
        // Angled plane
        { id: 4, nominal: [1.0, 1.0, -1.0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 5, nominal: [1.0, 1.0, 1.0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 6, nominal: [2.0, 2.0, 0.0], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    } else if (level.id === 'parallelism') {
      pts = [
        // Left flank (X = -0.5)
        { id: 1, nominal: [-0.5, 0.8, -1.5], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 2, nominal: [-0.5, 0.8, 0.0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 3, nominal: [-0.5, 0.8, 1.5], measured: null, deviation: null, error: null, status: 'pending' },
        // Right flank (X = 0.5)
        { id: 4, nominal: [0.5, 0.8, -1.5], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 5, nominal: [0.5, 0.8, 0.0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 6, nominal: [0.5, 0.8, 1.5], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    } else if (level.id === 'head_indexing') {
      pts = [
        { id: 1, nominal: [-1.5, 0.5, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 2, nominal: [1.5, 0.5, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 3, nominal: [0, 0.5, -1.5], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 4, nominal: [0, 0.5, 1.5], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    } else if (level.id === 'complex_part') {
      pts = [
        { id: 1, nominal: [0, 2.0, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 2, nominal: [1.0, 1.0, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 3, nominal: [-1.0, 1.0, 0], measured: null, deviation: null, error: null, status: 'pending' },
        { id: 4, nominal: [0, 0.5, 1.5], measured: null, deviation: null, error: null, status: 'pending' }
      ];
    }

    setTargetPoints(pts);
    setCollisions(0);
    setDeviationSum(0);
    setAccuracy(100.0);
    setAiReport(null);
    setIsLevelFinished(false);
    setSystemState('online');
    
    // Gamification resets
    setLevelStartTime(Date.now());
    setElapsedTimeMs(0);
    setFinalScore(0);
  };

  const handleLevelCompletion = (finalPoints: TargetPoint[], currentCollisions: number) => {
    setIsLevelFinished(true);
    
    // Gamification Scoring
    const timeSecs = elapsedTimeMs / 1000;
    const currentLevel = levels[activeLevelIdx];
    const baseScore = currentLevel.targetCount * 1000;
    const timePenalty = Math.floor(timeSecs * 15); // 15 pts per second
    const collPenalty = currentCollisions * 500;
    
    const devSum = finalPoints.reduce((acc, curr) => acc + (curr.error || 0), 0);
    const accuracyBonus = Math.max(0, Math.floor(2000 - devSum * 10000)); // up to 2000 bonus
    
    const calculatedScore = Math.max(0, baseScore - timePenalty - collPenalty + accuracyBonus);
    setFinalScore(calculatedScore);
    
    setTimeout(() => {
      playCmmSound('success');
    }, 300);
  };

  // Sound generator
  const playCmmSound = (type: 'beep' | 'error' | 'success') => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      if (type === 'beep') {
        osc.frequency.setValueAtTime(840, ctx.currentTime);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.12);
      } else if (type === 'error') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(160, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(75, ctx.currentTime + 0.3);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      } else if (type === 'success') {
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.08); // E5
        osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.16); // G5
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        gain.gain.setValueAtTime(0.08, ctx.currentTime + 0.16);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      }
    } catch (e) {
      console.log('Audio error ignored for browser safety policy', e);
    }
  };

  // Trigger contact/collision animation on screen
  const triggerImpactFeedback = (isCollision: boolean) => {
    if (isCollision) {
      setSystemState('error');
      playCmmSound('error');
      setCollisions(prev => {
        const nextColl = prev + 1;
        // Reduce accuracy
        setAccuracy(acc => Math.max(10, +(acc - 4.5).toFixed(1)));
        return nextColl;
      });

      // Flashes the red contact screen
      const flash = document.getElementById('contact-flash');
      if (flash) {
        flash.classList.add('active');
        setTimeout(() => flash.classList.remove('active'), 150);
      }

      // Vibrate screen
      const body = document.getElementById('app-body');
      if (body) {
        body.classList.add('screen-shake');
        setTimeout(() => body.classList.remove('screen-shake'), 250);
      }

      setTimeout(() => setSystemState('online'), 800);
    } else {
      // Valid measured point probing
      setSystemState('contact');
      playCmmSound('beep');
      setTimeout(() => setSystemState('online'), 800);
    }
  };

  // Three.js Scene Setup
  useEffect(() => {
    if (!canvasContainerRef.current) return;

    // Load Three via global / modular
    const THREE = (window as any).THREE;
    if (!THREE) {
      console.warn("Three.js not found. Reloading canvas after initialization delay.");
      return;
    }

    const container = canvasContainerRef.current;
    
    // Create Scene, Camera, WebGLRenderer
    const scene = new THREE.Scene();
    // Slightly dark blue background with atmosphere fogging
    scene.background = new THREE.Color(0x0a1122);
    scene.fog = new THREE.FogExp2(0x0a1122, 0.06);

    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(9, 7, 9);

    // Taster-Cam (PIP) Camera
    const pipCamera = new THREE.PerspectiveCamera(35, 1, 0.05, 50);

    // CAD Orthogonal/Flat Top inspection camera for split screen viewport representation
    const cadCamera = new THREE.OrthographicCamera(-6, 6, 6, -6, 0.1, 1000);
    cadCamera.position.set(0, 15, 0);
    cadCamera.up.set(0, 0, -1); // Up is north (negative Z coordinate) for correct CNC alignment
    cadCamera.lookAt(0, 1.8, 0);

    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    } catch (e) {
      console.error("WebGL WebGLRenderer context creation failed:", e);
      setHasWebglError(true);
      return () => {
        // Safe empty cleanup
      };
    }
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setClearColor(0x000000, 0); // Transparent background to allow CSS gradient
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;
    container.appendChild(renderer.domElement);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;

    // Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 2;
    controls.maxDistance = 24;
    controls.target.set(0, 1.8, 0);

    // Clear snap views animation targets when user manually orbits
    controls.addEventListener('start', () => {
      cameraMoveTargetRef.current = null;
      controlsTargetMoveTargetRef.current = null;
    });

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.67);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.71);
    mainLight.position.set(6, 12, 8);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 2048;
    mainLight.shadow.mapSize.height = 2048;
    mainLight.shadow.bias = -0.0005;
    scene.add(mainLight);

    const rimLight = new THREE.PointLight(0x00a3ff, 2.23, 20);
    rimLight.position.set(-6, 4, -6);
    scene.add(rimLight);

    const sideYellowLight = new THREE.DirectionalLight(0xffb77f, 0.74);
    sideYellowLight.position.set(-8, 3, 5);
    scene.add(sideYellowLight);

    // Floor active uplight pointing upwards to illuminate stylus metal rod and probe underside clearly
    const floorUpLight = new THREE.DirectionalLight(0xffffff, 1.04);
    floorUpLight.position.set(0, -6, 0);
    scene.add(floorUpLight);

    // Coordinate Table: Professional completely opaque matte light-gray Wenzel Granite Plate
    const tableGeo = new THREE.BoxGeometry(16, 1.0, 16);
    const tableMat = new THREE.MeshPhysicalMaterial({ 
      color: 0x525660, // Authentic lighter medium-gray Impala/Wenzel granite slate representation
      roughness: 0.8,  // Solid matte tactile stone surface
      metalness: 0.12,
      transparent: false,
      opacity: 1.0,
      depthWrite: true
    });
    const tableMesh = new THREE.Mesh(tableGeo, tableMat);
    tableMesh.position.y = -0.5; // Slightly lower thick slab
    tableMesh.receiveShadow = true;
    scene.add(tableMesh);

    // Grid removed as requested for Wenzel-like authentic slate look

    // CMM Gantry Bridge Representation (Visual Props in background - styled exactly like Wenzel LH 87)
    const gantryGroup = new THREE.Group();

    // Wenzel corporate cladding materials
    const wenzelIvoryMat = new THREE.MeshPhysicalMaterial({
      color: 0xeaecef, // Clean sleek warm light-gray/ivory protective casing
      roughness: 0.35,
      metalness: 0.12
    });

    const wenzelBlueMat = new THREE.MeshPhysicalMaterial({
      color: 0x054a87, // Iconic Wenzel industrial royal blue accent styling
      roughness: 0.3,
      metalness: 0.15
    });

    const blackGraniteMat = new THREE.MeshPhysicalMaterial({
      color: 0x141619, // Deep black polished granite with high density
      roughness: 0.45,
      metalness: 0.1
    });

    // Portal columns Left & Right (lh87 sturdy geometric covers)
    const colGeo = new THREE.BoxGeometry(1.2, 8, 1.3);
    const colLeft = new THREE.Mesh(colGeo, wenzelIvoryMat);
    colLeft.position.set(-7, 4, 0);
    colLeft.castShadow = true;
    colLeft.receiveShadow = true;
    colLeft.visible = false; // Hidden due to 'ohne seitliche Säule' to free up the view
    
    const colRight = colLeft.clone();
    colRight.position.x = 7;
    colRight.visible = false;
    gantryGroup.add(colLeft, colRight);

    // Brand identification: royal blue vertical styling bands on the columns' front face
    const blueStripLeft = new THREE.Mesh(new THREE.BoxGeometry(0.35, 7.6, 0.02), wenzelBlueMat);
    blueStripLeft.position.set(-7, 4, 0.66);
    blueStripLeft.visible = false;
    const blueStripRight = blueStripLeft.clone();
    blueStripRight.position.x = 7;
    blueStripRight.visible = false;
    gantryGroup.add(blueStripLeft, blueStripRight);

    // Traverse (Cross-beam): Authentic LH 87 combination of black granite beam guideway + rear ivory shroud
    const graniteRailGeo = new THREE.BoxGeometry(14.8, 1.2, 0.6);
    const graniteRail = new THREE.Mesh(graniteRailGeo, blackGraniteMat);
    graniteRail.position.set(0, 7.6, 0.2);
    graniteRail.castShadow = true;
    gantryGroup.add(graniteRail);

    // Steel runner guiderails on the granite face for physical slide aesthetics
    const steelRailMat = new THREE.MeshPhysicalMaterial({ color: 0xdddde5, metalness: 0.95, roughness: 0.1 });
    const topSteelRail = new THREE.Mesh(new THREE.BoxGeometry(14.8, 0.05, 0.05), steelRailMat);
    topSteelRail.position.set(0, 8.12, 0.51);
    const bottomSteelRail = topSteelRail.clone();
    bottomSteelRail.position.y = 7.08;
    gantryGroup.add(topSteelRail, bottomSteelRail);

    // Cream-Ivory protection shroud on the rear side
    const shroudBeamGeo = new THREE.BoxGeometry(14.8, 1.5, 0.9);
    const shroudBeam = new THREE.Mesh(shroudBeamGeo, wenzelIvoryMat);
    shroudBeam.position.set(0, 7.75, -0.45);
    shroudBeam.castShadow = true;
    shroudBeam.receiveShadow = true;
    gantryGroup.add(shroudBeam);

    // Top horizontal stripe
    const beamBlueLine = new THREE.Mesh(new THREE.BoxGeometry(14.8, 0.08, 0.92), wenzelBlueMat);
    beamBlueLine.position.set(0, 8.42, -0.45);
    gantryGroup.add(beamBlueLine);

    scene.add(gantryGroup);

    // Probe Assembly Group (Renishaw Touch Probe)
    const quillGroup = new THREE.Group();
    
    // Vertikaler Pinole-Schaft (Z-axis pillar - high precision square tube)
    // LH 87 features a solid black granite quill for absolute thermal parity
    const shaftGeo = new THREE.BoxGeometry(0.62, 12, 0.62);
    const shaftMat = new THREE.MeshPhysicalMaterial({ 
      color: 0x131518, // Ultimate solid black granite representation
      metalness: 0.1, 
      roughness: 0.65 
    });
    const shaftMesh = new THREE.Mesh(shaftGeo, shaftMat);
    shaftMesh.position.y = 6;
    quillGroup.add(shaftMesh);

    // Side metal guide rails for physical realism
    const railMat = new THREE.MeshPhysicalMaterial({ color: 0xc0c8d0, metalness: 0.95, roughness: 0.05 });
    const leftRailGeo = new THREE.BoxGeometry(0.04, 12, 0.15);
    const leftRail = new THREE.Mesh(leftRailGeo, railMat);
    leftRail.position.set(-0.31, 6, 0);
    const rightRail = leftRail.clone();
    rightRail.position.x = 0.31;
    quillGroup.add(leftRail, rightRail);

    // Chrome/Silver optical linear encoder strip (ticks measuring bar)
    const scaleGeo = new THREE.BoxGeometry(0.08, 12, 0.015);
    const scaleMat = new THREE.MeshPhysicalMaterial({ color: 0xddddf2, metalness: 0.9, roughness: 0.1 });
    const scaleBar = new THREE.Mesh(scaleGeo, scaleMat);
    scaleBar.position.set(0, 6, 0.311);
    quillGroup.add(scaleBar);

    // Active metrologic state indicator LED Ring
    const ledIndicatorGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.1, 24);
    const ledIndicatorMat = new THREE.MeshPhysicalMaterial({
      color: 0x00d2ff,
      emissive: 0x00a8cc,
      emissiveIntensity: 1.0,
      roughness: 0.1,
      metalness: 0.1
    });
    const ledIndicator = new THREE.Mesh(ledIndicatorGeo, ledIndicatorMat);
    ledIndicator.position.y = 0.05;
    ledIndicator.name = "status_led";
    quillGroup.add(ledIndicator);

    // Gold anodized locking collar at Pinole base
    const collarGeo = new THREE.CylinderGeometry(0.28, 0.28, 0.12, 24);
    const goldLockMat = new THREE.MeshPhysicalMaterial({ color: 0xd4af37, roughness: 0.15, metalness: 0.95 });
    const collarMesh = new THREE.Mesh(collarGeo, goldLockMat);
    collarMesh.position.y = -0.06;
    quillGroup.add(collarMesh);

    // Renishaw REVO-2 5-Axis Probe Head Assembly
    const headGroup = new THREE.Group();
    headGroup.name = "revo_head";
    
    // 1. REVO Base (Fixed to quill, sleek graphite/black -> now silver matte)
    const revoMat = new THREE.MeshPhysicalMaterial({
      color: 0xc0c4c8,
      roughness: 0.65,
      metalness: 0.5
    });
    // Replace block with rounded cylinder
    const revoBaseGeo = new THREE.CylinderGeometry(0.28, 0.28, 0.4, 32);
    const revoBase = new THREE.Mesh(revoBaseGeo, revoMat);
    revoBase.position.y = 0.1;
    headGroup.add(revoBase);

    // Subtle silver REVO logo stripe
    const logoStripeGeo = new THREE.CylinderGeometry(0.285, 0.285, 0.08, 32);
    const logoStripeMat = new THREE.MeshPhysicalMaterial({ color: 0xaaaaaa, metalness: 0.9, roughness: 0.2 });
    const logoStripe = new THREE.Mesh(logoStripeGeo, logoStripeMat);
    logoStripe.position.y = 0.15;
    headGroup.add(logoStripe);

    // Add visual scale ring to base (B-axis scale)
    const scaleRingGeo = new THREE.CylinderGeometry(0.282, 0.282, 0.02, 64);
    const scaleRingMat = new THREE.MeshBasicMaterial({ color: 0x333333, wireframe: true, wireframeLinewidth: 2 });
    const scaleRing = new THREE.Mesh(scaleRingGeo, scaleRingMat);
    scaleRing.position.y = -0.05;
    headGroup.add(scaleRing);

    // 2. B-Axis Group (Pan / Roll around Y axis)
    const revoBAxis = new THREE.Group();
    revoBAxis.name = "revo_b_axis";
    revoBAxis.position.y = -0.1;
    headGroup.add(revoBAxis);

    // B-Axis Rotating Body (Cylindrical transition)
    const bAxisBodyGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.3, 32);
    const bAxisBody = new THREE.Mesh(bAxisBodyGeo, revoMat);
    bAxisBody.position.y = -0.15;
    revoBAxis.add(bAxisBody);

    // B-Axis lower detailed scale
    const bScaleGeo = new THREE.CylinderGeometry(0.242, 0.242, 0.015, 64);
    const bScale = new THREE.Mesh(bScaleGeo, scaleRingMat);
    bScale.position.y = -0.05;
    revoBAxis.add(bScale);

    // Yoke / Fork for A-Axis (Replace boxy arms with rounded capsules/cylinders)
    const yokeArmGeo = new THREE.CapsuleGeometry(0.08, 0.25, 8, 16);
    
    // Left Fork Arm
    const yokeLeft = new THREE.Mesh(yokeArmGeo, revoMat);
    yokeLeft.position.set(-0.16, -0.4, 0);
    revoBAxis.add(yokeLeft);
    
    // Right Fork Arm
    const yokeRight = yokeLeft.clone();
    yokeRight.position.set(0.16, -0.4, 0);
    revoBAxis.add(yokeRight);

    // 3. A-Axis Group (Tilt around X axis)
    const revoAAxis = new THREE.Group();
    revoAAxis.name = "revo_a_axis";
    revoAAxis.position.set(0, -0.4, 0); // Pivot point between the yoke arms
    revoBAxis.add(revoAAxis);

    // A-Axis Swivel Cylinder (between yoke arms)
    const aAxisSwivelGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.38, 32);
    aAxisSwivelGeo.rotateZ(Math.PI / 2);
    const aAxisSwivel = new THREE.Mesh(aAxisSwivelGeo, revoMat);
    revoAAxis.add(aAxisSwivel);

    // A-axis scale wheel (on the outside of the fork)
    const aScaleGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.35, 64);
    aScaleGeo.rotateZ(Math.PI / 2);
    const aScale = new THREE.Mesh(aScaleGeo, scaleRingMat);
    revoAAxis.add(aScale);

    // RSP2 / Probe Module Body
    const rsp2Mat = new THREE.MeshPhysicalMaterial({
      color: 0x222222,
      roughness: 0.5,
      metalness: 0.6,
    });
    // Add rounded upper part for sensor body
    const rsp2Geo = new THREE.CylinderGeometry(0.16, 0.14, 0.3, 32);
    const rsp2Body = new THREE.Mesh(rsp2Geo, rsp2Mat);
    rsp2Body.position.y = -0.25;
    revoAAxis.add(rsp2Body);

    // Needle stylus (Realistic matte aluminum styling)
    const stylusGroup = new THREE.Group();
    stylusGroup.name = "revo_stylus";
    const probeRodGeo = new THREE.CylinderGeometry(0.025, 0.025, 1.6, 16);
    const rodMat = new THREE.MeshPhysicalMaterial({ 
      color: 0xededef, // Highly reflective aluminum silver sheen to capture scene lighting bright and realistic
      metalness: 0.95, // High chrome/metal grade
      roughness: 0.16, // Beautifully polished semi-gloss aluminum
    });
    const probeRod = new THREE.Mesh(probeRodGeo, rodMat);
    probeRod.position.y = -0.8; 
    stylusGroup.add(probeRod);

    // Gold fitting caps at the ends of stylus rod
    const capGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.08, 16);
    const capTop = new THREE.Mesh(capGeo, goldLockMat);
    capTop.position.y = -0.04;
    const capBottom = capTop.clone();
    capBottom.position.y = -1.6;
    stylusGroup.add(capTop, capBottom);

    // Red ruby ball tip
    const rubyGeo = new THREE.SphereGeometry(0.12, 24, 24);
    const rubyMat = new THREE.MeshPhysicalMaterial({ 
      color: 0xff0044, 
      emissive: 0x220000, 
      roughness: 0.05, 
      metalness: 0.1,
      transmission: 0.8,
      thickness: 0.15,
      ior: 1.76, 
      clearcoat: 1.0,
      clearcoatRoughness: 0.02
    });
    const rubyBall = new THREE.Mesh(rubyGeo, rubyMat);
    rubyBall.position.y = -1.6 - 0.12; // Exactly at the end of the probe rod
    rubyBall.name = "ruby_ball";
    stylusGroup.add(rubyBall);

    // Assembly hierarchy
    stylusGroup.position.y = -0.4;
    revoAAxis.add(stylusGroup);

    headGroup.position.y = 0; // At bottom of gantry quill
    quillGroup.add(headGroup);
    scene.add(quillGroup);

    // Workpiece groups
    const workpieceGroup = new THREE.Group();
    scene.add(workpieceGroup);

    // Target markers groups
    const targetsGroup = new THREE.Group();
    scene.add(targetsGroup);

    // Save states in ref
    threeRef.current = {
      scene,
      camera,
      renderer,
      quill: quillGroup,
      probeHead: headGroup,
      stylus: stylusGroup,
      targetsGroup,
      workpieceGroup,
      keyboardHandlers: null
    };

    // Render loop coordinates
    let targetX = 0;
    let targetY = 2.8;
    let targetZ = 0;

    let curX = 0;
    let curY = 4.0;
    let curZ = 0;

    let isColliding = false;
    let collisionCooldown = 0;

    // Build the curve spline for the Channel (used for level 3)
    const splineCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-4, 2.2, -2.0),
      new THREE.Vector3(-2, 2.6, 1.5),
      new THREE.Vector3(0, 1.8, -2.0),
      new THREE.Vector3(2, 2.4, 1.8),
      new THREE.Vector3(4, 2.1, -1.0)
    ]);
    threeRef.current.splineCurve = splineCurve;

    // Apply level geometry
    updateThreeWorkpiece();

    // Register Resize Handler
    const handleResize = () => {
      if (!canvasContainerRef.current) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Loop Frame
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      // Analog continuous update for virtual joystick
      let joyX = joystickOffsetRef.current.x;
      let joyY = joystickOffsetRef.current.y;
      if (joyX !== 0 || joyY !== 0) {
        // "halbe Geschwindigkeit" requested -> reduced overall normal speeds
        const joySpeed = (window as any).isRapidSpeedEnabled ? 0.15 : 0.0225;
        let tX = ((window as any).cmmTargetX || 0) + joyX * joySpeed;
        let tZ = ((window as any).cmmTargetZ || 0) + joyY * joySpeed;

        // Apply physical workspace bounds so probe doesn't exit lab
        tX = Math.max(-6.5, Math.min(6.5, tX));
        tZ = Math.max(-6.5, Math.min(6.5, tZ));

        (window as any).cmmTargetX = tX;
        (window as any).cmmTargetZ = tZ;
      }

      // Smooth interpolation for probe coordinates
      let currentSpeed = (window as any).isRapidSpeedEnabled ? 0.08 : 0.035;
      
      const prevX = curX;
      const prevY = curY;
      const prevZ = curZ;

      if ((window as any).isHeadIndexing || isHeadIndexing) {
        curX = (window as any).cmmCurrentX !== undefined ? (window as any).cmmCurrentX : curX;
        curY = (window as any).cmmCurrentY !== undefined ? (window as any).cmmCurrentY : curY;
        curZ = (window as any).cmmCurrentZ !== undefined ? (window as any).cmmCurrentZ : curZ;
      } else {
        curX += ((window as any).cmmTargetX - curX) * currentSpeed;
        curY += ((window as any).cmmTargetY - curY) * currentSpeed;
        curZ += ((window as any).cmmTargetZ - curZ) * currentSpeed;
      }

      // Expose for accurate probing / compensation
      (window as any).cmmCurrentX = curX;
      (window as any).cmmCurrentY = curY;
      (window as any).cmmCurrentZ = curZ;

      // Apply REVO angles
      const angleA = (window as any).revoAngleA || 0;
      const angleB = (window as any).revoAngleB || 0;

      const revoBAxis = quillGroup.getObjectByName("revo_b_axis");
      if (revoBAxis) revoBAxis.rotation.y = THREE.MathUtils.degToRad(angleB);

      const revoAAxis = quillGroup.getObjectByName("revo_a_axis");
      if (revoAAxis) revoAAxis.rotation.x = THREE.MathUtils.degToRad(angleA);

      // Calculate stylus tip offset based on REVO kinematics
      // Tip is at -2.12 in A-Axis local space
      const tipLocal = new THREE.Vector3(0, -2.12, 0);
      tipLocal.applyEuler(new THREE.Euler(THREE.MathUtils.degToRad(angleA), 0, 0));
      tipLocal.add(new THREE.Vector3(0, -0.4, 0)); // A-Axis pivot offset
      tipLocal.applyEuler(new THREE.Euler(0, THREE.MathUtils.degToRad(angleB), 0));
      tipLocal.add(new THREE.Vector3(0, -0.1, 0)); // B-Axis pivot offset

      // Calculate Quill Position to place the tip exactly at curX, curY, curZ
      quillGroup.position.set(curX - tipLocal.x, curY - tipLocal.y, curZ - tipLocal.z);

      // Dynamically update status LED ring based on continuous machine contact state
      const ledRing = queueMicrotask ? quillGroup.getObjectByName("status_led") : null;
      const actualLedRing = quillGroup.getObjectByName("status_led");
      if (actualLedRing && actualLedRing.material) {
        if (collisionCooldown > 15) {
          // Intense warning blushing red on collision/contact
          actualLedRing.material.color.setHex(0xff0033);
          actualLedRing.material.emissive.setHex(0xaa0033);
          actualLedRing.material.emissiveIntensity = 2.0;
        } else {
          // See if there's a recently successfully touched point nearby
          const nearSuccess = targetsBackupRef.current.some(t => 
            t.measured !== null && 
            t.status === 'pass' && 
            Math.abs(curX - t.nominal[0]) < 0.35 && 
            Math.abs(curY - t.nominal[1]) < 0.35 && 
            Math.abs(curZ - t.nominal[2]) < 0.35
          );
          if (nearSuccess) {
            // Glow green when successfully acquired nominal points
            actualLedRing.material.color.setHex(0x00ff66);
            actualLedRing.material.emissive.setHex(0x00aa33);
            actualLedRing.material.emissiveIntensity = 1.8;
          } else {
            // Standard beautiful neon cyan active state
            actualLedRing.material.color.setHex(0x00d2ff);
            actualLedRing.material.emissive.setHex(0x0066aa);
            actualLedRing.material.emissiveIntensity = 1.0;
          }
        }
      }

      // Update state for React HUD diagnostics (throttle state dispatch)
      if (Math.abs(positionX - curX) > 0.001 || Math.abs(positionY - curY) > 0.001 || Math.abs(positionZ - curZ) > 0.001) {
        // Convert virtual units (decimeters) to millimeters (e.g. 1 unit of spatial distance = 100mm)
        setPositionX(+(curX * 100).toFixed(4));
        // Keep altitude above granite base
        setPositionY(+(curY * 100).toFixed(4));
        setPositionZ(+(curZ * 100).toFixed(4));
      }

      // Proximity testing & Collision mechanics
      if (collisionCooldown > 0) {
        collisionCooldown--;
      }

      // Check boundary collisions
      const currentLevelId = levels[activeLevelIdx].id;
      const rubyRadius = 0.15; // virtual units
      let hitWall = false;
      let minDistanceToContour = Infinity;

      const tipPos = new THREE.Vector3(curX, curY, curZ);

      if (currentLevelId === 'calibration') {
        const sphereCenter = new THREE.Vector3(0, 1.05, 0);
        const dist = tipPos.distanceTo(sphereCenter);
        minDistanceToContour = dist - (1.35 + rubyRadius);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === '321_alignment' || currentLevelId === 'plane_measurement' || currentLevelId === 'head_indexing') {
        const dx = Math.max(0, Math.abs(curX) - 1.5);
        const dy = Math.max(0, Math.abs(curY - 0.75) - 0.75);
        const dz = Math.max(0, Math.abs(curZ) - 1.5);
        const distBox = Math.sqrt(dx*dx + dy*dy + dz*dz) - rubyRadius;
        
        let distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distBox, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'cylinder') {
        const radialDist = Math.sqrt(curX * curX + curZ * curZ);
        const distToSide = radialDist - 1.2;
        const distToTop = Math.abs(curY - 1.0) - 1.0;
        let distCyl = Math.max(distToSide, distToTop);
        if (distCyl > 0) {
          const dx = Math.max(0, radialDist - 1.2);
          const dy = Math.max(0, Math.abs(curY - 1.0) - 1.0);
          distCyl = Math.sqrt(dx*dx + dy*dy);
        }
        distCyl -= rubyRadius;
        
        let distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distCyl, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'circle_center') {
        const dx = Math.max(0, Math.abs(curX) - 2.0);
        const dy = Math.max(0, Math.abs(curY - 0.75) - 0.75);
        const dz = Math.max(0, Math.abs(curZ) - 2.0);
        let distBox = Math.sqrt(dx*dx + dy*dy + dz*dz);
        const radialDist = Math.sqrt(curX * curX + curZ * curZ);
        if (radialDist < 1.0 && curY > 0 && curY < 1.5) {
            distBox = 1.0 - radialDist; // Inside the hole, dist to inner wall
        } else if (radialDist < 1.0 && curY >= 1.5) {
            distBox = Math.min(distBox, curY - 1.5);
        }
        
        distBox -= rubyRadius;
        let distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distBox, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'hole_distance') {
        const dx = Math.max(0, Math.abs(curX) - 3.0);
        const dy = Math.max(0, Math.abs(curY - 0.75) - 0.75);
        const dz = Math.max(0, Math.abs(curZ) - 2.0);
        let distBox = Math.sqrt(dx*dx + dy*dy + dz*dz) - rubyRadius;
        let distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distBox, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'angle_measurement') {
        const dx = Math.max(0, Math.abs(curX - 0.5) - 2.0);
        const dz = Math.max(0, Math.abs(curZ) - 1.5);
        const surfaceY = 0.5 + Math.max(0, curX + 1.0) * 0.5; // Slope
        const dy = curY < 0 ? -curY : (curY > surfaceY ? curY - surfaceY : 0);
        let distWedge = Math.sqrt(dx*dx + dy*dy + dz*dz) - rubyRadius;
        let distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distWedge, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'parallelism') {
        const dx = Math.max(0, Math.abs(curX) - 1.5);
        const dy = Math.max(0, Math.abs(curY - 0.75) - 0.75);
        const dz = Math.max(0, Math.abs(curZ) - 2.0);
        let distBox = Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (curX > -0.5 && curX < 0.5 && curY > 0.5 && curY <= 1.5) {
            distBox = Math.min(curX - (-0.5), 0.5 - curX);
        }
        distBox -= rubyRadius;
        let distFloor = curY - rubyRadius;
        minDistanceToContour = Math.min(distBox, distFloor);
        if (minDistanceToContour <= 0) hitWall = true;
      } else if (currentLevelId === 'complex_part') {
        const distFloor = curY - rubyRadius;
        minDistanceToContour = distFloor;
        if (minDistanceToContour <= 0) hitWall = true;
      } else {
        const distFloor = curY - rubyRadius;
        minDistanceToContour = distFloor;
        if (minDistanceToContour <= 0) hitWall = true;
      }

      // Automatically brake 5mm (0.5 units) before contour, slowing down dynamically!
      // This realizes the requested "automatisch abbremsen 5 mm vor Kontur"
      if (minDistanceToContour < 0.5 && minDistanceToContour > 0 && !hitWall) {
        currentSpeed *= Math.max(0.01, minDistanceToContour / 0.5); 
      }

      if (hitWall) {
        // --- INDUSTRIAL PROBE TOUCH AUTO-STOP & MEASURE ---
        // Restore previous safe coordinates to prevent penetration into geometry
        curX = prevX;
        curY = prevY;
        curZ = prevZ;
        
        quillGroup.position.set(curX - tipLocal.x, curY - tipLocal.y, curZ - tipLocal.z);

        // Instantly stop the CMM gantry movement at the point of contact
        (window as any).cmmTargetX = curX;
        (window as any).cmmTargetY = curY;
        (window as any).cmmTargetZ = curZ;

        // Trigger manual vertical slider visual coupling update
        setControlZVal(curY * 20);

        if (!isColliding && collisionCooldown === 0) {
          isColliding = true;
          collisionCooldown = 35; // throttle touches

          // Automatically trigger the touch probe recording ("get Point" with compensation)
          triggerProbingOnOverlap();
        }
      } else {
        isColliding = false;
      }

      // Target points visual glow rotation
      targetsGroup.children.forEach((mesh: any) => {
        mesh.rotation.y += 0.012;
        mesh.rotation.x += 0.005;
      });

      // Interpolate main camera and controls.target for snapping to ortho faces smoothly
      if (cameraMoveTargetRef.current) {
        camera.position.lerp(cameraMoveTargetRef.current, 0.08);
        if (camera.position.distanceTo(cameraMoveTargetRef.current) < 0.02) {
          cameraMoveTargetRef.current = null;
        }
      }
      if (controlsTargetMoveTargetRef.current) {
        controls.target.lerp(controlsTargetMoveTargetRef.current, 0.08);
        if (controls.target.distanceTo(controlsTargetMoveTargetRef.current) < 0.02) {
          controlsTargetMoveTargetRef.current = null;
        }
      }

      // Probing vector action fly-along drive tracking mode
      if (isVectorJourneyActiveRef.current) {
        const pendingPt = (targetsBackupRef.current || []).find((p: any) => p.status === 'pending');
        if (pendingPt) {
          const tx = pendingPt.nominal[0];
          const ty = pendingPt.nominal[1];
          const tz = pendingPt.nominal[2];

          // Automatically drive the probe targets towards the upcoming checkpoint
          (window as any).cmmTargetX = tx;
          (window as any).cmmTargetY = ty;
          (window as any).cmmTargetZ = tz;

          const probePos = new THREE.Vector3(curX, curY, curZ);
          const targetPos = new THREE.Vector3(tx, ty, tz);
          
          const direction = new THREE.Vector3().subVectors(probePos, targetPos);
          if (direction.lengthSq() > 0.01) {
            direction.normalize();
            
            // Set behind the ruby looking down the line of action vector
            const driveCamPos = probePos.clone().addScaledVector(direction, 3.5);
            driveCamPos.y += 1.8; // Elevated view and looking directly at target
            
            camera.position.lerp(driveCamPos, 0.07);
            controls.target.lerp(targetPos, 0.07);
          }
        }
      } else if (!cameraMoveTargetRef.current && !controlsTargetMoveTargetRef.current) {
        // User requested: "Maschine steht" (Machine stands still, camera does not track probe)
        // Main camera stays where it is. PIP Taster-Cam handles the close-up tracking.
      }

      // Sync the physical interactive HTML CSS 3D ViewCube has been removed as requested

      controls.update();

      // Sync compass D-pad rotation
      if (dpadRef.current && camera && controls) {
        // Find Euler Y angle of the camera relative to origin/target
        // Using Math.atan2 on camera position - controls target
        const vDir = new THREE.Vector3().subVectors(camera.position, controls.target);
        // We want 0 degrees when looking down -Z axis.
        const theta = Math.atan2(vDir.x, vDir.z); 
        dpadRef.current.style.transform = `rotate(${theta}rad)`;
      }

      // Render Multi-Viewport Split Screen if enabled
      const splitActive = isSplitScreenRef.current;
      const width = container.clientWidth;
      const height = container.clientHeight;

      if (splitActive) {
        // Left viewport: main camera
        camera.aspect = (width / 2) / height;
        camera.updateProjectionMatrix();

        renderer.setViewport(0, 0, width / 2, height);
        renderer.setScissor(0, 0, width / 2, height);
        renderer.setScissorTest(true);
        renderer.render(scene, camera);

        // Right viewport: Orthographic close-up Top inspect following stylus coordinates
        const cadAspect = (width / 2) / height;
        cadCamera.left = -5 * cadAspect;
        cadCamera.right = 5 * cadAspect;
        cadCamera.top = 5;
        cadCamera.bottom = -5;
        cadCamera.updateProjectionMatrix();

        // Pin the vertical inspection top camera right above probe's action center
        cadCamera.position.set(curX, 12, curZ);
        cadCamera.lookAt(curX, curY, curZ);

        renderer.setViewport(width / 2, 0, width / 2, height);
        renderer.setScissor(width / 2, 0, width / 2, height);
        renderer.setScissorTest(true);
        renderer.render(scene, cadCamera);
      } else {
        // Full viewport
        camera.aspect = width / height;
        camera.updateProjectionMatrix();

        renderer.setViewport(0, 0, width, height);
        renderer.setScissorTest(false);
        renderer.render(scene, camera);

        // PIP Taster-Cam "immer sichtbar mitten rechtsseitig oben"
        if (width > 640 && !isSplitScreenRef.current) {
          const pipSize = 250;
          const pipX = width - Math.min(250, pipSize) - 20;
          // Top margin = 80px CSS, pipY is from bottom
          const pipY = height - Math.min(250, pipSize) - 80;

          renderer.setViewport(pipX, pipY, pipSize, pipSize);
          renderer.setScissor(pipX, pipY, pipSize, pipSize);
          renderer.setScissorTest(true);

          // Position pipCamera looking at the probe tip from an angular offset
          const pipTarget = new THREE.Vector3(curX, curY, curZ);
          pipCamera.position.copy(pipTarget).add(new THREE.Vector3(0.5, 0.4, 0.5));
          pipCamera.lookAt(pipTarget);

          const oldClearColor = new THREE.Color();
          const oldClearAlpha = renderer.getClearAlpha();
          renderer.getClearColor(oldClearColor);

          // Clear area for PIP with dark background
          renderer.autoClear = false;
          renderer.setClearColor(0x0a1122, 1.0);
          renderer.clear();

          renderer.render(scene, pipCamera);

          renderer.setClearColor(oldClearColor, oldClearAlpha);
          renderer.autoClear = true;
          renderer.setScissorTest(false);
        }
      }
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [activeLevelIdx]);

  // Handle setting/updating 3D workpieces based on active level and material custom styles
  const updateThreeWorkpiece = () => {
    const THREE = (window as any).THREE;
    if (!THREE || !threeRef.current) return;

    const { scene, workpieceGroup, targetsGroup, splineCurve } = threeRef.current;
    
    // Clear existing workpiece children
    while (workpieceGroup.children.length > 0) {
      workpieceGroup.remove(workpieceGroup.children[0]);
    }

    // Clear existing target visuals
    while (targetsGroup.children.length > 0) {
      targetsGroup.remove(targetsGroup.children[0]);
    }

    // Material definitions
    let workpieceMat: any;
    let materialColor = 0xc0c0c0; // Default Alu-Matt

    // Lazily evaluate and cache textures
    if (!(window as any).graniteTexture) {
      const tex = new THREE.CanvasTexture(createProceduralTexture('granite'));
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      (window as any).graniteTexture = tex;
    }
    if (!(window as any).aluTexture) {
      const tex = new THREE.CanvasTexture(createProceduralTexture('alu'));
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      (window as any).aluTexture = tex;
    }

    if (material === 'Granit Dunkel') {
      workpieceMat = new THREE.MeshPhysicalMaterial({
        color: 0x1f232d,
        map: (window as any).graniteTexture,
        roughness: 0.12,
        metalness: 0.2,
        clearcoat: 0.5,
        clearcoatRoughness: 0.2
      });
    } else if (material === 'Alu Poliert') {
      workpieceMat = new THREE.MeshPhysicalMaterial({
        color: 0xddf1ff,
        metalness: 1.0,
        roughness: 0.05,
        clearcoat: 0.8,
        clearcoatRoughness: 0.05
      });
    } else if (material === 'Carbonfaser') {
      workpieceMat = new THREE.MeshPhysicalMaterial({
        color: 0x151515,
        roughness: 0.6,
        metalness: 0.9,
        clearcoat: 1.0,
        clearcoatRoughness: 0.1,
        wireframe: false
      });
    } else {
      // Alu Matt
      workpieceMat = new THREE.MeshPhysicalMaterial({
        color: 0xbfc7d4,
        map: (window as any).aluTexture,
        roughness: 0.45,
        metalness: 0.8,
        clearcoat: 0.1,
        clearcoatRoughness: 0.3
      });
    }

    if (isXrayMode) {
      workpieceMat.transparent = true;
      workpieceMat.opacity = 0.3;
      workpieceMat.depthWrite = false;
    }

    const currentLevel = levels[activeLevelIdx];

    // Position targets & generate physical geometry elements
    if (currentLevel.id === 'calibration') {
      // 1. Reference calibration sphere on metallic base stalk
      const stalkGeo = new THREE.CylinderGeometry(0.18, 0.4, 1.2, 16);
      const stalkMat = new THREE.MeshPhysicalMaterial({ color: 0x778899, metalness: 0.9, roughness: 0.1 });
      const stalk = new THREE.Mesh(stalkGeo, stalkMat);
      stalk.position.y = 0.4;
      workpieceGroup.add(stalk);

      const refSphereGeo = new THREE.SphereGeometry(1.35, 32, 32);
      // High accuracy calibration sphere is typically matte ceramic white or mirror silver
      const refSphereMat = new THREE.MeshPhysicalMaterial({ color: 0xeef5fc, roughness: 0.2, metalness: 0.4 });
      const refSphere = new THREE.Mesh(refSphereGeo, refSphereMat);
      refSphere.position.y = 1.05;
      refSphere.castShadow = true;
      refSphere.receiveShadow = true;
      workpieceGroup.add(refSphere);

      // Seed targets backup value
      (window as any).cmmTargetX = 0;
      (window as any).cmmTargetY = 4.0; // Start gantry hovering
      (window as any).cmmTargetZ = 2.0;

      // Add target ring/halo at apex point
      const targetMesh = createVisualTargetMesh(0, 2.52, 0, 1);
      targetsGroup.add(targetMesh);

    } else if (currentLevel.id === '321_alignment' || currentLevel.id === 'plane_measurement' || currentLevel.id === 'head_indexing') {
      const blockGeo = new THREE.BoxGeometry(3.0, 1.5, 3.0);
      const blockMesh = new THREE.Mesh(blockGeo, workpieceMat);
      blockMesh.position.set(0, 0.75, 0); 
      blockMesh.receiveShadow = true;
      blockMesh.castShadow = true;
      workpieceGroup.add(blockMesh);

      (window as any).cmmTargetX = -2.0;
      (window as any).cmmTargetY = 3.0;
      (window as any).cmmTargetZ = 1.5;

      const coords = currentLevel.id === '321_alignment' ? [
        [-1.0, 1.5, 0.5, 1], [1.0, 1.5, 0.5, 2], [0.0, 1.5, -0.5, 3],
        [-0.8, 0.8, 1.5, 4], [0.8, 0.8, 1.5, 5], [-1.5, 0.8, 0.0, 6]
      ] : currentLevel.id === 'plane_measurement' ? [
        [-1.2, 1.5, -1.2, 1], [1.2, 1.5, -1.2, 2], [1.2, 1.5, 1.2, 3], [-1.2, 1.5, 1.2, 4]
      ] : [
        [-1.5, 0.5, 0, 1], [1.5, 0.5, 0, 2], [0, 0.5, -1.5, 3], [0, 0.5, 1.5, 4]
      ];
      coords.forEach(([x, y, z, id]) => {
        targetsGroup.add(createVisualTargetMesh(x, y, z, id));
      });

    } else if (currentLevel.id === 'cylinder') {
      const baseFixtureGeo = new THREE.BoxGeometry(4.5, 0.2, 4.5);
      const baseFixture = new THREE.Mesh(baseFixtureGeo, workpieceMat);
      baseFixture.position.y = 0.1;
      baseFixture.receiveShadow = true;
      baseFixture.castShadow = true;
      workpieceGroup.add(baseFixture);

      const cylGeo = new THREE.CylinderGeometry(1.2, 1.2, 2.0, 32);
      const cyl = new THREE.Mesh(cylGeo, workpieceMat);
      cyl.position.y = 1.1;
      cyl.receiveShadow = true;
      cyl.castShadow = true;
      workpieceGroup.add(cyl);

      (window as any).cmmTargetX = 0;
      (window as any).cmmTargetY = 3.5;
      (window as any).cmmTargetZ = 3.0;

      const coordinates = [
        [1.2, 1.0, 0, 1], [0, 1.0, 1.2, 2], [-1.2, 1.0, 0, 3], [0, 1.0, -1.2, 4]
      ];
      coordinates.forEach(([x, y, z, id]) => {
        targetsGroup.add(createVisualTargetMesh(x, y, z, id));
      });

    } else if (currentLevel.id === 'circle_center') {
      // 3D Block built with actual physical hollow structures
      // Surround blocks leaving a 2x2 central square opening
      const frontPart = new THREE.Mesh(new THREE.BoxGeometry(4.0, 1.5, 1.0), workpieceMat);
      frontPart.position.set(0, 0.75, 1.5);
      
      const backPart = new THREE.Mesh(new THREE.BoxGeometry(4.0, 1.5, 1.0), workpieceMat);
      backPart.position.set(0, 0.75, -1.5);
      
      const leftPart = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.5, 2.0), workpieceMat);
      leftPart.position.set(-1.5, 0.75, 0);
      
      const rightPart = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.5, 2.0), workpieceMat);
      rightPart.position.set(1.5, 0.75, 0);

      const parts = [frontPart, backPart, leftPart, rightPart];
      parts.forEach(p => {
        p.receiveShadow = true;
        p.castShadow = true;
        workpieceGroup.add(p);
      });

      // Hollow boring sleeve
      const tubeGeo = new THREE.CylinderGeometry(1.0, 1.0, 1.5, 32, 1, true); // open-ended cylindrical hollow
      const tubeMat = workpieceMat.clone();
      tubeMat.side = THREE.DoubleSide; // double-sided so we see inside
      tubeMat.roughness = 0.55;
      const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
      tubeMesh.position.set(0, 0.75, 0);
      tubeMesh.receiveShadow = true;
      tubeMesh.castShadow = true;
      workpieceGroup.add(tubeMesh);

      (window as any).cmmTargetX = 0;
      (window as any).cmmTargetY = 2.5;
      (window as any).cmmTargetZ = 0.0;

      const coordinates = [
        [1.0, 0.5, 0, 1], [-0.5, 0.5, 0.866, 2], [-0.5, 0.5, -0.866, 3]
      ];
      coordinates.forEach(([x, y, z, id]) => {
        targetsGroup.add(createVisualTargetMesh(x, y, z, id));
      });

    } else if (currentLevel.id === 'hole_distance') {
      // Re-architected with real physical hollow dual drillings!
      // Surround blocks to hollow out two bores of radius 0.8 at x=-1.5 and x=1.5
      const frontPart = new THREE.Mesh(new THREE.BoxGeometry(6.0, 1.5, 1.2), workpieceMat);
      frontPart.position.set(0, 0.75, 1.4);
      
      const backPart = new THREE.Mesh(new THREE.BoxGeometry(6.0, 1.5, 1.2), workpieceMat);
      backPart.position.set(0, 0.75, -1.4);
      
      const farLeftPart = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.5, 1.6), workpieceMat);
      farLeftPart.position.set(-2.65, 0.75, 0);
      
      const middlePart = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.5, 1.6), workpieceMat);
      middlePart.position.set(0, 0.75, 0);
      
      const farRightPart = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.5, 1.6), workpieceMat);
      farRightPart.position.set(2.65, 0.75, 0);

      const parts = [frontPart, backPart, farLeftPart, middlePart, farRightPart];
      parts.forEach(p => {
        p.receiveShadow = true;
        p.castShadow = true;
        workpieceGroup.add(p);
      });

      // Hollow bores
      const tubeMat = workpieceMat.clone();
      tubeMat.side = THREE.DoubleSide;
      tubeMat.roughness = 0.55;

      const tube1 = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.8, 1.5, 32, 1, true), tubeMat);
      tube1.position.set(-1.5, 0.75, 0);
      tube1.receiveShadow = true;
      tube1.castShadow = true;
      workpieceGroup.add(tube1);

      const tube2 = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.8, 1.5, 32, 1, true), tubeMat);
      tube2.position.set(1.5, 0.75, 0);
      tube2.receiveShadow = true;
      tube2.castShadow = true;
      workpieceGroup.add(tube2);

      (window as any).cmmTargetX = -1.5;
      (window as any).cmmTargetY = 2.5;
      (window as any).cmmTargetZ = 0.0;

      const coordinates = [
        [-0.7, 0.5, 0, 1], [-1.9, 0.5, 0.692, 2], [-1.9, 0.5, -0.692, 3],
        [2.3, 0.5, 0, 4], [1.1, 0.5, 0.692, 5], [1.1, 0.5, -0.692, 6]
      ];
      coordinates.forEach(([x, y, z, id]) => {
        targetsGroup.add(createVisualTargetMesh(x, y, z, id));
      });

    } else if (currentLevel.id === 'angle_measurement') {
       const shape = new THREE.Shape();
       shape.moveTo(-2.5, 0);
       shape.lineTo(1.5, 0);
       shape.lineTo(1.5, 2.0);
       shape.lineTo(-2.5, 0);
       const extrudeSettings = { depth: 3.0, bevelEnabled: false };
       const wedgeGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
       wedgeGeo.center(); 

       const wedgeMesh = new THREE.Mesh(wedgeGeo, workpieceMat);
       wedgeMesh.position.set(-0.5, 1.0, 0); 
       workpieceGroup.add(wedgeMesh);

      (window as any).cmmTargetX = -2.0;
      (window as any).cmmTargetY = 2.5;
      (window as any).cmmTargetZ = 2.5;

       const coordinates = [
        [-1.0, 0.5, -1.0, 1], [-1.0, 0.5, 1.0, 2], [0.0, 0.5, 0.0, 3],
        [1.0, 1.0, -1.0, 4], [1.0, 1.0, 1.0, 5], [2.0, 2.0, 0.0, 6]
      ];
      coordinates.forEach(([x, y, z, id]) => {
        targetsGroup.add(createVisualTargetMesh(x, y, z, id));
      });

    } else if (currentLevel.id === 'parallelism') {
      // Real physical hollow parallel Groove!
      // Built using 3 blocks: Left rail, Right rail, and Bottom center under the groove path
      const leftPart = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.5, 4.0), workpieceMat);
      leftPart.position.set(-1.0, 0.75, 0);
      
      const rightPart = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.5, 4.0), workpieceMat);
      rightPart.position.set(1.0, 0.75, 0);
      
      const bottomPart = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.5, 4.0), workpieceMat);
      bottomPart.position.set(0, 0.25, 0);

      const parts = [leftPart, rightPart, bottomPart];
      parts.forEach(p => {
        p.receiveShadow = true;
        p.castShadow = true;
        workpieceGroup.add(p);
      });

      (window as any).cmmTargetX = 0;
      (window as any).cmmTargetY = 2.5;
      (window as any).cmmTargetZ = 0.0;

       const coordinates = [
        [-0.5, 0.8, -1.5, 1], [-0.5, 0.8, 0.0, 2], [-0.5, 0.8, 1.5, 3],
        [0.5, 0.8, -1.5, 4], [0.5, 0.8, 0.0, 5], [0.5, 0.8, 1.5, 6]
      ];
      coordinates.forEach(([x, y, z, id]) => {
        targetsGroup.add(createVisualTargetMesh(x, y, z, id));
      });
      
    } else if (currentLevel.id === 'complex_part') {
      const baseGeo = new THREE.BoxGeometry(3.0, 1.0, 3.0);
      const topGeo = new THREE.CylinderGeometry(1.0, 1.0, 1.0, 32);
      
      const blockMesh = new THREE.Mesh(baseGeo, workpieceMat);
      blockMesh.position.set(0, 0.5, 0); 
      workpieceGroup.add(blockMesh);
      
      const cylMesh = new THREE.Mesh(topGeo, workpieceMat);
      cylMesh.position.set(0, 1.5, 0); 
      workpieceGroup.add(cylMesh);

      (window as any).cmmTargetX = 2.0;
      (window as any).cmmTargetY = 2.5;
      (window as any).cmmTargetZ = 2.0;

       const coordinates = [
        [0, 2.0, 0, 1], [1.0, 1.0, 0, 2], [-1.0, 1.0, 0, 3], [0, 0.5, 1.5, 4]
      ];
      coordinates.forEach(([x, y, z, id]) => {
        targetsGroup.add(createVisualTargetMesh(x, y, z, id));
      });
    }
  };

  // Helper inside Three.js thread to create glowing target models
  const createVisualTargetMesh = (x: number, y: number, z: number, id: number) => {
    const THREE = (window as any).THREE;
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.name = `target_group_${id}`;

    // Outer spinning double crosshair rings
    const ringGeo = new THREE.RingGeometry(0.24, 0.28, 16);
    const goldMat = new THREE.MeshBasicMaterial({ 
      color: 0xffd700, 
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.6
    });
    
    const ringX = new THREE.Mesh(ringGeo, goldMat);
    const ringY = new THREE.Mesh(ringGeo, goldMat);
    ringY.rotation.y = Math.PI / 2;

    // Small central core target nodule
    const coreGeo = new THREE.SphereGeometry(0.08, 16, 16);
    const coreMat = new THREE.MeshBasicMaterial({ color: 0xffea00 });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    coreMesh.name = `target_core_${id}`;

    group.add(ringX, ringY, coreMesh);
    return group;
  };

  // Handle active hotkeys / keyboard drive controls (highly polished addition)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't act on arrows if user inside other input fields
      if (activeTab !== 'steuern') return;
      if (isHeadIndexingRef.current) return; // Disable during head rotation

      const step = movementSpeed === 'rapid' ? 0.16 : (movementSpeed === 'normal' ? 0.025 : 0.015);
      let dx = 0;
      let dy = 0;
      let dz = 0;

      // Map arrow keys and height controls WS / PageUp PageDown
      if (e.key === 'ArrowLeft') {
        dx = -step;
        e.preventDefault();
      } else if (e.key === 'ArrowRight') {
        dx = step;
        e.preventDefault();
      } else if (e.key === 'ArrowUp') {
        dz = -step;
        e.preventDefault();
      } else if (e.key === 'ArrowDown') {
        dz = step;
        e.preventDefault();
      } else if (e.key.toLowerCase() === 'w' || e.key === 'PageUp') {
        dy = step;
        e.preventDefault();
      } else if (e.key.toLowerCase() === 's' || e.key === 'PageDown') {
        dy = -step;
        e.preventDefault();
      } else if (e.key === 'Shift') {
        setMovementSpeed('rapid');
        (window as any).isRapidSpeedEnabled = true;
      } else if (e.key === ' ' || e.key === 'Enter') {
        // Space / Enter triggers metrological coordinate touch probes!
        triggerProbingOnOverlap();
        e.preventDefault();
      }

      if (dx !== 0 || dy !== 0 || dz !== 0) {
        let moveX = dx;
        let moveZ = dz;

        const THREE = (window as any).THREE;
        if (THREE && threeRef.current?.camera) {
          const cam = threeRef.current.camera;
          const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(cam.quaternion);
          forward.y = 0;
          if (forward.lengthSq() > 0.001) forward.normalize();
          
          const right = new THREE.Vector3(1, 0, 0).applyQuaternion(cam.quaternion);
          right.y = 0;
          if (right.lengthSq() > 0.001) right.normalize();

          moveX = (right.x * dx) - (forward.x * dz);
          moveZ = (right.z * dx) - (forward.z * dz);
        }

        let nX = ((window as any).cmmTargetX || 0) + moveX;
        let nY = ((window as any).cmmTargetY || 0) + dy;
        let nZ = ((window as any).cmmTargetZ || 0) + moveZ;

        // Apply physical workspace bounds so probe doesn't exit lab
        nX = Math.max(-6.5, Math.min(6.5, nX));
        // Keep vertical movement above granite (Y > 0) and below portal beam (Y < 5.0)
        nY = Math.max(0.01, Math.min(4.8, nY));
        nZ = Math.max(-6.5, Math.min(6.5, nZ));

        (window as any).cmmTargetX = nX;
        (window as any).cmmTargetY = nY;
        (window as any).cmmTargetZ = nZ;

        // Update Z manual slider state for visual coupling
        setControlZVal(nY * 20); // Scale Y to slider percentage 0-100 (where 5 units represents max height)
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'Shift') {
        setMovementSpeed('normal');
        (window as any).isRapidSpeedEnabled = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [activeLevelIdx, movementSpeed, activeTab]);

  // Handle Dragging the virtual Joystick UI (Horizontal Cartesian bridge control XY)
  const handleJoystickMove = (dx: number, dy: number) => {
    // Relative coordinate shifting mapped to XY target axes and oriented to camera
    const sensitivity = movementSpeed === 'rapid' ? 0.08 : (movementSpeed === 'normal' ? 0.03 : 0.008);
    
    let moveDX = dx * sensitivity;
    let moveDZ = dy * sensitivity;
    
    let moveX = moveDX;
    let moveZ = moveDZ;

    const THREE = (window as any).THREE;
    if (THREE && threeRef.current?.camera) {
      const cam = threeRef.current.camera;
      const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(cam.quaternion);
      forward.y = 0;
      if (forward.lengthSq() > 0.001) forward.normalize();
      
      const right = new THREE.Vector3(1, 0, 0).applyQuaternion(cam.quaternion);
      right.y = 0;
      if (right.lengthSq() > 0.001) right.normalize();

      moveX = (right.x * moveDX) - (forward.x * moveDZ);
      moveZ = (right.z * moveDX) - (forward.z * moveDZ);
    }

    let nX = ((window as any).cmmTargetX || 0) + moveX;
    let nZ = ((window as any).cmmTargetZ || 0) + moveZ;

    nX = Math.max(-6.5, Math.min(6.5, nX));
    nZ = Math.max(-6.5, Math.min(6.5, nZ));

    (window as any).cmmTargetX = nX;
    (window as any).cmmTargetZ = nZ;
  };

  // Dragging the Z axes slider (altitude Quill/Pinole)
  const handleZSliderChange = (val: number) => {
    if (isHeadIndexingRef.current) return;
    setControlZVal(val);
    const scaleY = (val / 100) * 4.8; // Map slider 0-100 to Three altitude 0-4.8 units
    (window as any).cmmTargetY = Math.max(0.01, scaleY);
  };

  // CMM Joystick Mouse Drag Event listeners configuration
  const startDPad = (x: number, y: number) => (e: React.PointerEvent) => {
    if (isHeadIndexingRef.current) return;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setJoystickOffset({ x, y });
    joystickOffsetRef.current = { x, y };
  };

  const stopDPad = (e: React.PointerEvent) => {
    (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    setJoystickOffset({ x: 0, y: 0 });
    joystickOffsetRef.current = { x: 0, y: 0 };
  };

  // Z-Axis Custom Touch Vertical Slider event listener configuration
  const setupZSliderTracker = (e: ReactMouseEvent<any> | ReactTouchEvent<any>) => {
    e.preventDefault();
    const isTouch = 'touches' in e;
    const container = e.currentTarget as HTMLDivElement;
    
    const updateZFromCoords = (clientY: number) => {
      const rect = container.getBoundingClientRect();
      const padding = 25; // px from top/bottom for labels
      const relativeY = clientY - rect.top;
      const usableHeight = rect.height - padding * 2;
      // Convert to pct (bottom is 0%, top is 100%)
      const pct = 1.0 - (relativeY - padding) / usableHeight;
      const finalPct = Math.max(0, Math.min(100, Math.round(pct * 100)));
      handleZSliderChange(finalPct);
    };

    const clientY = isTouch ? e.touches[0].clientY : e.clientY;
    updateZFromCoords(clientY);

    const handleMove = (moveEv: MouseEvent | TouchEvent) => {
      const cy = 'touches' in moveEv ? moveEv.touches[0].clientY : moveEv.clientY;
      updateZFromCoords(cy);
    };

    const handleStop = () => {
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleStop);
      window.removeEventListener('touchmove', handleMove);
      window.removeEventListener('touchend', handleStop);
    };

    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleStop);
    window.addEventListener('touchmove', handleMove, { passive: false });
    window.addEventListener('touchend', handleStop);
  };

  // Trigger Proximity scan on coordinate points to inspect and seal nominal values with Probe Radius Compensation (TRK)
  const triggerProbingOnOverlap = () => {
    // Get precise live position of the ruby sphere center
    const curX = (window as any).cmmCurrentX !== undefined ? (window as any).cmmCurrentX : ((window as any).cmmTargetX || 0);
    const curY = (window as any).cmmCurrentY !== undefined ? (window as any).cmmCurrentY : ((window as any).cmmTargetY || 0);
    const curZ = (window as any).cmmCurrentZ !== undefined ? (window as any).cmmCurrentZ : ((window as any).cmmTargetZ || 0);

    let probeHit = false;
    let targetIdTriggered = -1;
    let calculatedDeviation: [number, number, number] = [0, 0, 0];
    let calculatedError = 0;
    let compensatedVirt: [number, number, number] = [curX, curY, curZ];

    // We search the pending nominal points to detect if probe tip is inside the capture zone (0.45 units, equivalent to 45mm)
    const pts = [...targetPoints];
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i];
      if (p.status === 'pending') {
        const dx = p.nominal[0] - curX;
        const dy = p.nominal[1] - curY;
        const dz = p.nominal[2] - curZ;
        const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);

        // Capture zone checks proximity of center to nominal point (0.45 units)
        if (dist <= 0.45) {
          probeHit = true;
          targetIdTriggered = p.id;

          // --- TASTERRADIUSKOMPENSATION (TRK) ---
          // Center of ruby sphere is (curX, curY, curZ). Contact occurs at the surface.
          // Direction of contact is along the probing vector connecting sphere center to the nominal target.
          // Ruby radius in virtual units = (probeSize / 2) / 100 (where 1 unit = 100mm)
          const rubyRadiusVirt = (probeSize / 2) / 100;
          
          let ux = 0;
          let uy = 0;
          let uz = 0;
          if (dist > 0.001) {
            ux = dx / dist;
            uy = dy / dist;
            uz = dz / dist;
          }

          // Compensated coordinates of actual contact on sphere surface in virtual units:
          const compX = curX + rubyRadiusVirt * ux;
          const compY = curY + rubyRadiusVirt * uy;
          const compZ = curZ + rubyRadiusVirt * uz;
          compensatedVirt = [compX, compY, compZ];

          // Calculate deviation in millimeters (1 virtual unit = 100mm)
          // The difference of actual contacted surface point from nominal value
          const mmDx = +((compX - p.nominal[0]) * 100).toFixed(5);
          const mmDy = +((compY - p.nominal[1]) * 100).toFixed(5);
          const mmDz = +((compZ - p.nominal[2]) * 100).toFixed(5);

          calculatedDeviation = [mmDx, mmDy, mmDz];
          calculatedError = +Math.sqrt(mmDx*mmDx + mmDy*mmDy + mmDz*mmDz).toFixed(5);
          break;
        }
      }
    }

    if (probeHit && targetIdTriggered !== -1) {
      // Correct alignment! Capture coordinate and update point
      triggerImpactFeedback(false);

      const updated = targetPoints.map(p => {
        if (p.id === targetIdTriggered) {
          const satisfiesTolerance = calculatedError <= activeLevel.tolerance;
          return {
            ...p,
            measured: [+compensatedVirt[0].toFixed(4), +compensatedVirt[1].toFixed(4), +compensatedVirt[2].toFixed(4)],
            deviation: calculatedDeviation,
            error: calculatedError,
            status: satisfiesTolerance ? 'pass' as const : 'fail' as const
          };
        }
        return p;
      });

      setTargetPoints(updated);
      setDeviationSum(prev => +(prev + calculatedError).toFixed(5));

      // Trigger 3D target change visualization inside Three.js scene thread
      const THREE = (window as any).THREE;
      if (THREE && threeRef.current) {
        const targetNode = threeRef.current.targetsGroup.getObjectByName(`target_group_${targetIdTriggered}`);
        if (targetNode) {
          const core = targetNode.getObjectByName(`target_core_${targetIdTriggered}`);
          if (core) {
            // Success glow changes from yellow to green!
            core.material.color.setHex(0x00ff88);
          }
        }
      }

      // Evaluate task completeness
      const checkedAll = updated.every(p => p.status !== 'pending');
      if (checkedAll) {
        handleLevelCompletion(updated, collisions);
      }
    } else {
      // Contact with CAD walls but no target point nearby
      if (!isBeginnerModeRef.current) {
        triggerImpactFeedback(true);
      } else {
        // Soft beginner feedback: valid safe beep without incrementing collisions or shaking
        setSystemState('contact');
        playCmmSound('beep');
        setTimeout(() => setSystemState('online'), 800);
      }
    }
  };

  // Reset/re-level current task
  const restartLevelTask = () => {
    initTargetsForLevel();
    updateThreeWorkpiece();
  };

  // Generate real server-side AI Report via Gemini analysis API proxy
  const generateAiMetrologyReport = async () => {
    setLoadingReport(true);
    setReportError(null);
    setAiReport(null);

    // Filter only measured points
    const measurements = targetPoints.map(p => ({
      punktNummer: p.id,
      nominalZentren: p.nominal,
      gemessenerWert: p.measured || "Nicht gemessen",
      abweichungen_dx_dy_dz_mm: p.deviation || "N/A",
      fehlerAbstand_mm: p.error || 0,
      bewertung: p.status.toUpperCase()
    }));

    try {
      const response = await fetch('/api/gemini/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          measurements,
          partName: activeLevel.name,
          config: {
            material,
            probeSize,
            tolerance: activeLevel.tolerance
          }
        })
      });

      if (!response.ok) {
        const errJson = await response.json();
        throw new Error(errJson.error || 'Fehler bei der Kontaktaufnahme zum Server.');
      }

      const resData = await response.json();
      setAiReport(resData.text);
    } catch (err: any) {
      setReportError(err.message || 'Ein unerwarteter Fehler ist aufgetreten.');
    } finally {
      setLoadingReport(false);
    }
  };

  // Move camera presets to specific isometrics or closeups
  const setCameraPreset = (viewName: 'iso_a' | 'iso_b' | 'probe') => {
    if (!threeRef.current) return;
    const { camera, controls } = threeRef.current;
    
    if (viewName === 'iso_a') {
      camera.position.set(9, 7, 9);
      controls.target.set(0, 1.8, 0);
    } else if (viewName === 'iso_b') {
      camera.position.set(-9, 7, 9);
      controls.target.set(0, 1.8, 0);
    } else if (viewName === 'probe') {
      // Focus closely directly on probe head
      const px = (window as any).cmmTargetX || 0;
      const py = (window as any).cmmTargetY || 0;
      const pz = (window as any).cmmTargetZ || 0;
      camera.position.set(px + 1.8, py + 1.0, pz + 2.0);
      controls.target.set(px, py, pz);
    }
    controls.update();
  };

  // Snap camera direction precisely and smoothly to specific orthogonal CAD planes
  const snapToView = (viewName: 'iso_a' | 'iso_b' | 'iso_c' | 'iso_d' | 'top') => {
    // Disable active vector action so snap viewpoints are not instantly overridden
    setIsVectorJourneyActive(false);

    if (!threeRef.current) return;
    const { camera, controls } = threeRef.current;
    
    const THREE = (window as any).THREE;
    if (!THREE) return;

    const targetCam = new THREE.Vector3();
    const targetLook = new THREE.Vector3(0, 1.8, 0);

    // Default distance
    let dist = camera.position.distanceTo(controls.target);

    let dir = new THREE.Vector3();
    if (viewName === 'iso_a') {
      dir.set(1, 0.8, 1).normalize();
    } else if (viewName === 'iso_b') {
      dir.set(-1, 0.8, 1).normalize();
    } else if (viewName === 'iso_c') {
      dir.set(-1, 0.8, -1).normalize();
    } else if (viewName === 'iso_d') {
      dir.set(1, 0.8, -1).normalize();
    } else if (viewName === 'top') {
      dir.set(0.001, 1, 0.001).normalize();
    }
    
    targetCam.copy(targetLook).add(dir.multiplyScalar(dist));

    // Assign/store to refs for the rendering frame loop to lerp towards on each frame
    cameraMoveTargetRef.current = targetCam;
    controlsTargetMoveTargetRef.current = targetLook;
  };

  const setZoomLevel = (level: number) => {
    setIsVectorJourneyActive(false);
    if (!threeRef.current) return;
    const { camera, controls } = threeRef.current;
    
    const THREE = (window as any).THREE;
    if (!THREE) return;

    // Get current direction vector
    const dir = new THREE.Vector3().subVectors(camera.position, controls.target).normalize();
    
    // Define distance for each zoom level multiplier
    // Level 1: Far (radius ~ 16)
    // Level 2: Medium (radius ~ 9)
    // Level 3: Near (radius ~ 4.5)
    const distances: Record<number, number> = { 1: 16, 2: 9, 3: 4.5 };
    const dist = distances[level];
    
    // We calculate new camera position from same target
    const targetCam = controls.target.clone().add(dir.multiplyScalar(dist));
    
    cameraMoveTargetRef.current = targetCam;
  };

  // PANIC EMERGENCY RECOVERY SYSTEM (Not-Halt & Autohome)
  const triggerPanicHomeReset = () => {
    // 1. Instantly hard-set target coordinates to safe hovering home point (X:0, Y:4.0, Z:0)
    (window as any).cmmTargetX = 0;
    (window as any).cmmTargetY = 4.0;
    (window as any).cmmTargetZ = 0;

    // Reset current/instant feedback coordinates to home so there is zero transition delay
    (window as any).cmmCurrentX = 0;
    (window as any).cmmCurrentY = 4.0;
    (window as any).cmmCurrentZ = 0;

    // Direct couple to manual Z slider
    setControlZVal(4.0 * 20);

    // 2. Safely interrupt any running CNC vector journeys or automated drives
    setIsVectorJourneyActive(false);

    // 3. Reset 3D viewport immediately to standard ISO A perspective
    snapToView('iso_a');

    // 4. Reset metrological error metrics and machine warning alarms
    setCollisions(0);
    setSystemState('online');

    // 5. Sound physical buzzer tone / error recovery beep
    playCmmSound('beep');
    if (typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
      window.navigator.vibrate([100, 50, 100]);
    }
  };

  // Auto-Drive the CMM Probe head directly and smoothly to a nominal target point (CNC-Autopilot Mode)
  const autoDriveToTargetPoint = (p: TargetPoint) => {
    if (isHeadIndexingRef.current) return;

    (window as any).cmmTargetX = p.nominal[0];
    (window as any).cmmTargetY = p.nominal[1];
    (window as any).cmmTargetZ = p.nominal[2];

    // Mirror to vertical depth slider
    setControlZVal(p.nominal[1] * 20);

    // Play feedback tone
    playCmmSound('beep');
  };

  // ==========================================
  // WENZEL DMIS & DENIS PROGRAMMING ASSISTANT
  // ==========================================

  const getDmisTemplate = (levelId: string): string => {
    switch (levelId) {
      case 'calibration':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: KALIBRIERUNG
FILNAM/'LEVEL1_CALIB',04.2
UNITS/MM,ANGDEC
SENS/PROBE,D1_5,1.5
REVO/A,0.0,B,0.0

$$ Zenit-Punkt der Kugel anfahren
GOTO/0.0, 3.5, 3.5
$$ Punkt antasten (Zenit/Scheitelpunkt)
MEAS/POINT, F(SCHAITEL), 1
  PTMEAS/CART, 0.0, 4.24, 0.0, 0.0, 1.0, 0.0
ENDMES`;

      case '321_alignment':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: 3-2-1 AUSRICHTUNG
FILNAM/'LEVEL2_321_ALIGN',04.2
UNITS/MM,ANGDEC
WKPLAN/XYPLAN

$$ --- HAUPTEBENE ANTASTEN (3 Punkte, Z-Richtung) ---
GOTO/-2.0, 3.5, -2.0
MEAS/PLANE, F(EBENE_Z), 3
  PTMEAS/CART, -2.0, 3.0, -2.0, 0.0, 1.0, 0.0
  PTMEAS/CART,  0.0, 3.0, -2.5, 0.0, 1.0, 0.0
  PTMEAS/CART,  2.0, 3.0, -2.0, 0.0, 1.0, 0.0
ENDMES

$$ --- ROTATIONSACHSE ANTASTEN (2 Punkte, X-Kante) ---
GOTO/-2.0, 3.5, 2.0
MEAS/LINE, F(LINIE_X), 2
  PTMEAS/CART, -1.5, 3.0, 2.0, 0.0, 0.0, -1.0
  PTMEAS/CART,  1.5, 3.0, 2.0, 0.0, 0.0, -1.0
ENDMES

$$ --- NULLPUNKT ANTASTEN (1 Punkt, Y-Stirnseite) ---
GOTO/-3.0, 3.5, 0.0
MEAS/POINT, F(PNT_Y), 1
  PTMEAS/CART, -3.0, 3.0, 0.0, 1.0, 0.0, 0.0
ENDMES

DATDEF/F(EBENE_Z), DAT_A
DATDEF/F(LINIE_X), DAT_B
DATDEF/F(PNT_Y),   DAT_C
ALIGN/321, DAT_A, DAT_B, DAT_C`;

      case 'plane_measurement':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: EBENHEIT
FILNAM/'LEVEL3_FLATNESS',04.2
UNITS/MM,ANGDEC

GOTO/-2.0, 4.0, -1.5
MEAS/PLANE, F(EBENE_OBEN), 4
  PTMEAS/CART, -2.0, 3.0, -1.5, 0.0, 1.0, 0.0
  PTMEAS/CART, -2.0, 3.0,  1.5, 0.0, 1.0, 0.0
  PTMEAS/CART,  2.0, 3.0,  1.5, 0.0, 1.0, 0.0
  PTMEAS/CART,  2.0, 3.0, -1.5, 0.0, 1.0, 0.0
ENDMES`;

      case 'cylinder':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: ZYLINDER
FILNAM/'LEVEL4_CYLINDER',04.2
UNITS/MM,ANGDEC

$$ Quadranten des Zylinders antasten
GOTO/-2.5, 2.5, 0.0
MEAS/CYLNDR, F(MANTEL), 4
  PTMEAS/CART, -1.5, 2.5,  0.0, 1.0, 0.0, 0.0
  PTMEAS/CART,  0.0, 2.5, -1.5, 0.0, 0.0, 1.0
  PTMEAS/CART,  1.5, 2.5,  0.0, -1.0, 0.0, 0.0
  PTMEAS/CART,  0.0, 2.5,  1.5, 0.0, 0.0, -1.0
ENDMES`;

      case 'circle_center':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: BOHRUNG_ZENTRUM
FILNAM/'LEVEL5_BORE_CENTER',04.2
UNITS/MM,ANGDEC

$$ Zentrieren über Bohrung, nach unten fahren
GOTO/0.0, 3.5, 0.0
GOTO/0.0, 1.5, 0.0

MEAS/CIRCLE, F(BOHRUNG1), 3
  PTMEAS/CART, -1.2, 1.5,  0.0, 1.0, 0.0, 0.0
  PTMEAS/CART,  0.6, 1.5, -1.0, -0.5, 0.0, 0.86
  PTMEAS/CART,  0.6, 1.5,  1.0, -0.5, 0.0, -0.86
ENDMES`;

      case 'hole_distance':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: LOCHABSTAND
FILNAM/'LEVEL6_HOLE_DIST',04.2
UNITS/MM,ANGDEC

$$ Erste Bohrung messen
GOTO/-2.2, 3.5, 0.0
GOTO/-2.2, 1.5, 0.0
MEAS/CIRCLE, F(BOHR1), 3
  PTMEAS/CART, -3.2, 1.5,  0.0, 1.0, 0.0, 0.0
  PTMEAS/CART, -1.7, 1.5,  0.8, -0.5, 0.0, -0.86
  PTMEAS/CART, -1.7, 1.5, -0.8, -0.5, 0.0, 0.86
ENDMES

$$ Freifahren
GOTO/-2.2, 3.5, 0.0

$$ Zweite Bohrung anfahren und messen
GOTO/2.2, 3.5, 0.0
GOTO/2.2, 1.5, 0.0
MEAS/CIRCLE, F(BOHR2), 3
  PTMEAS/CART, 1.2, 1.5,  0.0, 1.0, 0.0, 0.0
  PTMEAS/CART, 2.7, 1.5,  0.8, -0.5, 0.0, -0.86
  PTMEAS/CART, 2.7, 1.5, -0.8, -0.5, 0.0, 0.86
ENDMES`;

      case 'angle_measurement':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: WINKELMESSUNG
FILNAM/'LEVEL7_ANGLE',04.2
UNITS/MM,ANGDEC

$$ Basis-Ebene (3 Punkte)
GOTO/-2.0, 4.0, -2.0
MEAS/PLANE, F(EBENE_BASIS), 3
  PTMEAS/CART, -2.0, 1.0, -2.0, 0.0, 1.0, 0.0
  PTMEAS/CART,  0.0, 1.0, -2.0, 0.0, 1.0, 0.0
  PTMEAS/CART,  2.0, 1.0, -2.0, 0.0, 1.0, 0.0
ENDMES

$$ Schiefe Ebene (3 Punkte)
GOTO/-1.5, 4.0, 1.5
MEAS/PLANE, F(SCHIEFE_EBENE), 3
  PTMEAS/CART, -1.5, 2.8,  1.5, 0.0, 0.707, -0.707
  PTMEAS/CART,  0.0, 2.1,  0.0, 0.0, 0.707, -0.707
  PTMEAS/CART,  1.5, 1.4, -1.5, 0.0, 0.707, -0.707
ENDMES`;

      case 'parallelism':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: PARALLELITAET
FILNAM/'LEVEL8_PARALLEL',04.2
UNITS/MM,ANGDEC

$$ Linke Flanke (3 Punkte)
GOTO/-1.5, 3.5, -2.0
MEAS/PLANE, F(FLANKE_LINKS), 3
  PTMEAS/CART, -1.5, 2.0, -2.0, 1.0, 0.0, 0.0
  PTMEAS/CART, -1.5, 2.0,  0.0, 1.0, 0.0, 0.0
  PTMEAS/CART, -1.5, 2.0,  2.0, 1.0, 0.0, 0.0
ENDMES

$$ Rechte Flanke (3 Punkte)
GOTO/1.5, 3.5, -2.0
MEAS/PLANE, F(FLANKE_RECHTS), 3
  PTMEAS/CART, 1.5, 2.0, -2.0, -1.0, 0.0, 0.0
  PTMEAS/CART, 1.5, 2.0,  0.0, -1.0, 0.0, 0.0
  PTMEAS/CART, 1.5, 2.0,  2.0, -1.0, 0.0, 0.0
ENDMES`;

      case 'head_indexing':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: KOPF_SCHWENKEN
FILNAM/'LEVEL9_INDEXING',04.2
UNITS/MM,ANGDEC

$$ REVO Kopf schwenken auf A=-90, B=0
REVO/A,-90.0,B,0.0

$$ Horizontale Antastung durchführen
GOTO/-3.0, 2.5, 0.0
MEAS/POINT, F(SEITEN_PNT), 1
  PTMEAS/CART, -2.0, 2.5, 0.2, 1.0, 0.0, 0.0
ENDMES`;

      case 'complex_part':
        return `$$ WENZEL QUARTIS DMIS-PROGRAMM: KOMPLEXTEIL
FILNAM/'LEVEL10_COMPLEX',04.2
UNITS/MM,ANGDEC

$$ Verschiedene Stufen des Bauteils erfassen
GOTO/0.0, 4.5, 0.0
MEAS/PLANE, F(DECKFLSTUFE), 4
  PTMEAS/CART, 0.0, 3.8,  0.0, 0.0, 1.0, 0.0
ENDMES`;

      default:
        return `$$ WILKOMMEN BEI WENZEL QUARTIS
FILNAM/'CUSTOM_MEAS',04.2
UNITS/MM,ANGDEC
GOTO/0.0, 3.5, 2.0`;
    }
  };

  const parseDmis = (code: string): DmisStep[] => {
    const rawLines = code.split('\n');
    const steps: DmisStep[] = [];
    
    rawLines.forEach((rawLine, idx) => {
      const line = rawLine.trim();
      if (!line || line.startsWith('$$')) {
        return;
      }
      
      if (line.toUpperCase().startsWith('GOTO/')) {
        const parts = line.substring(5).split(',');
        if (parts.length >= 3) {
          const x = parseFloat(parts[0]);
          const y = parseFloat(parts[1]);
          const z = parseFloat(parts[2]);
          if (!isNaN(x) && !isNaN(y) && !isNaN(z)) {
            steps.push({
              originalLineIdx: idx,
              text: line,
              type: 'goto',
              args: { x, y, z }
            });
          }
        }
      } else if (line.toUpperCase().startsWith('PTMEAS/')) {
        const suffix = line.substring(7);
        const cartIdx = suffix.toUpperCase().indexOf('CART,');
        if (cartIdx !== -1) {
          const dataStr = suffix.substring(cartIdx + 5);
          const parts = dataStr.split(',');
          if (parts.length >= 3) {
            const x = parseFloat(parts[0]);
            const y = parseFloat(parts[1]);
            const z = parseFloat(parts[2]);
            if (!isNaN(x) && !isNaN(y) && !isNaN(z)) {
              steps.push({
                originalLineIdx: idx,
                text: line,
                type: 'ptmeas',
                args: { x, y, z }
              });
            }
          }
        }
      } else if (line.toUpperCase().startsWith('REVO/')) {
        const suffix = line.substring(5).toUpperCase();
        let valA = 0;
        let valB = 0;
        
        const aMatch = suffix.match(/A\s*,\s*(-?\d+\.?\d*)/);
        const bMatch = suffix.match(/B\s*,\s*(-?\d+\.?\d*)/);
        
        if (aMatch) valA = parseFloat(aMatch[1]);
        if (bMatch) valB = parseFloat(bMatch[1]);
        
        steps.push({
          originalLineIdx: idx,
          text: line,
          type: 'revo',
          args: { a: valA, b: valB }
        });
      } else if (line.toUpperCase().startsWith('UNITS/')) {
        steps.push({
          originalLineIdx: idx,
          text: line,
          type: 'units',
          args: { unit: 'MM' }
        });
      } else if (line.toUpperCase().startsWith('ALIGN/')) {
        steps.push({
          originalLineIdx: idx,
          text: line,
          type: 'align',
          args: {}
        });
      } else if (line.toUpperCase().startsWith('EVAL/')) {
        steps.push({
          originalLineIdx: idx,
          text: line,
          type: 'eval',
          args: {}
        });
      } else {
        steps.push({
          originalLineIdx: idx,
          text: line,
          type: 'other',
          args: {}
        });
      }
    });
    
    return steps;
  };

  const addDmisLog = (msg: string) => {
    const time = new Date().toLocaleTimeString();
    setDmisConsoleLogs(prev => [...prev, `[${time}] ${msg}`].slice(-40));
    // Autoscroll console
    setTimeout(() => {
      const box = document.getElementById('dmis-console-log-box');
      if (box) box.scrollTop = box.scrollHeight;
    }, 50);
  };

  const triggerTargetProbingHit = (triggeredId: number) => {
    // Check if state is already pending
    const current = targetPoints.find(tp => tp.id === triggeredId);
    if (!current || current.status !== 'pending') return;

    // Add slightly realistic tiny mock error (under tolerance)
    const randomShiftX = (Math.random() - 0.5) * 0.0004;
    const randomShiftY = (Math.random() - 0.5) * 0.0004;
    const randomShiftZ = (Math.random() - 0.5) * 0.0004;
    
    const compX = current.nominal[0] + randomShiftX;
    const compY = current.nominal[1] + randomShiftY;
    const compZ = current.nominal[2] + randomShiftZ;
    
    const mmDx = +(randomShiftX * 100).toFixed(5);
    const mmDy = +(randomShiftY * 100).toFixed(5);
    const mmDz = +(randomShiftZ * 100).toFixed(5);
    const calculatedError = +Math.sqrt(mmDx*mmDx + mmDy*mmDy + mmDz*mmDz).toFixed(5);

    // Audio beep and contact flash
    playCmmSound('beep');
    setSystemState('contact');
    setTimeout(() => setSystemState('online'), 800);
    
    const flash = document.getElementById('contact-flash');
    if (flash) {
      flash.classList.add('active');
      setTimeout(() => flash.classList.remove('active'), 150);
    }

    const updated = targetPoints.map(p => {
      if (p.id === triggeredId) {
        return {
          ...p,
          measured: [+compX.toFixed(4), +compY.toFixed(4), +compZ.toFixed(4)] as [number, number, number],
          deviation: [mmDx, mmDy, mmDz] as [number, number, number],
          error: calculatedError,
          status: 'pass' as const
        };
      }
      return p;
    });

    setTargetPoints(updated);
    setDeviationSum(prev => +(prev + calculatedError).toFixed(5));

    // Update Three.js scene target point color (yellow -> green)
    const THREE = (window as any).THREE;
    if (THREE && threeRef.current) {
      const targetNode = threeRef.current.targetsGroup.getObjectByName(`target_group_${triggeredId}`);
      if (targetNode) {
        const core = targetNode.getObjectByName(`target_core_${triggeredId}`);
        if (core) {
          core.material.color.setHex(0x00ff88);
        }
      }
    }

    // Evaluate completion
    const checkedAll = updated.every(p => p.status !== 'pending');
    if (checkedAll) {
      handleLevelCompletion(updated, collisions);
    }
  };

  const executeDmisStep = (stepIdx: number, stepsList: DmisStep[]) => {
    if (!isDmisExecutingRef.current) return;

    if (stepIdx < 0 || stepIdx >= stepsList.length) {
      addDmisLog(`[PROZESS] DMIS-Programm erfolgreich beendet.`);
      setIsDmisExecuting(false);
      isDmisExecutingRef.current = false;
      playCmmSound('success');
      return;
    }

    const step = stepsList[stepIdx];
    setCurrentStepIdx(stepIdx);
    currentStepIdxRef.current = stepIdx;
    setActiveDmisLineNo(step.originalLineIdx);

    addDmisLog(`[ZEILE ${step.originalLineIdx + 1}] ${step.text}`);

    switch (step.type) {
      case 'units': {
        addDmisLog(`[SYSTEM] Einheit auf Millimeter (MM) eingestellt.`);
        setTimeout(() => {
          if (isDmisExecutingRef.current) {
            executeDmisStep(stepIdx + 1, stepsList);
          }
        }, 300);
        break;
      }

      case 'revo': {
        const { a, b } = step.args;
        addDmisLog(`[REVO] Start 5-Achs-Kopfschwenk zu A: ${a}°, B: ${b}°`);
        animateHeadRotation(a, b);
        
        setTimeout(() => {
          if (isDmisExecutingRef.current) {
            addDmisLog(`[REVO] Kopfschwenk abgeschlossen.`);
            executeDmisStep(stepIdx + 1, stepsList);
          }
        }, 1200);
        break;
      }

      case 'goto': {
        const { x, y, z } = step.args;
        addDmisLog(`[CNC] Eilgang (GOTO) zu X: ${x.toFixed(3)}, Y: ${y.toFixed(3)}, Z: ${z.toFixed(3)}`);
        
        (window as any).cmmTargetX = x;
        (window as any).cmmTargetY = y;
        (window as any).cmmTargetZ = z;
        setControlZVal(Math.max(0, Math.min(100, (y / 5) * 100)));

        let checkCount = 0;
        const checkArrival = setInterval(() => {
          if (!isDmisExecutingRef.current) {
            clearInterval(checkArrival);
            return;
          }
          
          const curX = (window as any).cmmCurrentX || 0;
          const curY = (window as any).cmmCurrentY || 0;
          const curZ = (window as any).cmmCurrentZ || 0;
          
          const dist = Math.sqrt(
            Math.pow(curX - x, 2) +
            Math.pow(curY - y, 2) +
            Math.pow(curZ - z, 2)
          );
          
          if (dist < 0.08 || checkCount > 50) {
            clearInterval(checkArrival);
            addDmisLog(`[CNC] GOTO-Punkt erreicht.`);
            executeDmisStep(stepIdx + 1, stepsList);
          }
          checkCount++;
        }, 100);
        break;
      }

      case 'ptmeas': {
        const { x, y, z } = step.args;
        addDmisLog(`[CNC] Mess-Antastung (PTMEAS) zu X: ${x.toFixed(3)}, Y: ${y.toFixed(3)}, Z: ${z.toFixed(3)}`);
        
        const matchedPoint = targetPoints.find(p => {
          const dx = Math.abs(p.nominal[0] - x);
          const dy = Math.abs(p.nominal[1] - y);
          const dz = Math.abs(p.nominal[2] - z);
          return dx < 0.8 && dy < 0.8 && dz < 0.8;
        });

        const driveTargetX = matchedPoint ? matchedPoint.nominal[0] : x;
        const driveTargetY = matchedPoint ? matchedPoint.nominal[1] : y;
        const driveTargetZ = matchedPoint ? matchedPoint.nominal[2] : z;

        (window as any).cmmTargetX = driveTargetX;
        (window as any).cmmTargetY = driveTargetY;
        (window as any).cmmTargetZ = driveTargetZ;
        setControlZVal(Math.max(0, Math.min(100, (driveTargetY / 5) * 100)));

        let checkCount = 0;
        const checkProbing = setInterval(() => {
          if (!isDmisExecutingRef.current) {
            clearInterval(checkProbing);
            return;
          }

          const curX = (window as any).cmmCurrentX || 0;
          const curY = (window as any).cmmCurrentY || 0;
          const curZ = (window as any).cmmCurrentZ || 0;
          
          const dist = Math.sqrt(
            Math.pow(curX - driveTargetX, 2) +
            Math.pow(curY - driveTargetY, 2) +
            Math.pow(curZ - driveTargetZ, 2)
          );

          if (dist < 0.15 || checkCount > 60) {
            clearInterval(checkProbing);
            
            if (matchedPoint) {
              triggerTargetProbingHit(matchedPoint.id);
            } else {
              playCmmSound('beep');
              setSystemState('contact');
              setTimeout(() => setSystemState('online'), 800);
            }

            addDmisLog(`[ANTASTUNG] Messwert erfasst!`);
            
            // Back off slightly from contact zone
            const backedX = driveTargetX;
            const backedY = driveTargetY + 0.5;
            const backedZ = driveTargetZ;
            
            (window as any).cmmTargetX = backedX;
            (window as any).cmmTargetY = backedY;
            (window as any).cmmTargetZ = backedZ;

            setTimeout(() => {
              if (isDmisExecutingRef.current) {
                executeDmisStep(stepIdx + 1, stepsList);
              }
            }, 600);
          }
          checkCount++;
        }, 80);
        break;
      }

      default: {
        // Comments, empty, other statements
        setTimeout(() => {
          if (isDmisExecutingRef.current) {
            executeDmisStep(stepIdx + 1, stepsList);
          }
        }, 200);
        break;
      }
    }
  };

  const startDmisExecution = () => {
    const stepsList = parseDmis(dmisCode);
    if (stepsList.length === 0) {
      addDmisLog(`[ERROR] Kein ausführbares DMIS-Programm gefunden.`);
      return;
    }

    addDmisLog(`[SYSTEM] CNC-Automatik gestartet. ${stepsList.length} Anweisungen geladen.`);
    setDmisSteps(stepsList);
    dmisStepsRef.current = stepsList;
    
    setIsDmisExecuting(true);
    isDmisExecutingRef.current = true;
    
    setCurrentStepIdx(0);
    currentStepIdxRef.current = 0;
    
    executeDmisStep(0, stepsList);
  };

  const stopDmisExecution = () => {
    setIsDmisExecuting(false);
    isDmisExecutingRef.current = false;
    addDmisLog(`[HALT] Ausführung durch Anwender abgebrochen.`);
  };

  const resetDmisExecution = () => {
    setIsDmisExecuting(false);
    isDmisExecutingRef.current = false;
    setCurrentStepIdx(-1);
    currentStepIdxRef.current = -1;
    setActiveDmisLineNo(-1);
    setDmisConsoleLogs([]);
    addDmisLog(`[CNC] Programm zurückgesetzt.`);
  };

  // Auto-load template code when active level shifts
  useEffect(() => {
    const currentLvl = levels[activeLevelIdx];
    if (currentLvl) {
      setDmisCode(getDmisTemplate(currentLvl.id));
    }
    setIsDmisExecuting(false);
    isDmisExecutingRef.current = false;
    setCurrentStepIdx(-1);
    currentStepIdxRef.current = -1;
    setActiveDmisLineNo(-1);
  }, [activeLevelIdx]);

  const render2DVectorInspector = () => {
    const curX = positionX / 100;
    const curY = positionY / 100;
    const curZ = positionZ / 100;
    const currentLevel = levels[activeLevelIdx];

    // TOP VIEW SCALE & OFFSET (viewBox="-100 -100 200 200")
    const renderTopViewGeometry = () => {
      const id = currentLevel.id;
      if (id === 'calibration') {
        return (
          <>
            {/* Calibration circle */}
            <circle cx="0" cy="0" r={1.35 * 12} className="stroke-slate-500 fill-slate-800/20" strokeWidth="1.5" strokeDasharray="2,2" />
            <circle cx="0" cy="0" r={0.18 * 12} className="stroke-slate-600 fill-slate-800" strokeWidth="1" />
          </>
        );
      } else if (id === '321_alignment' || id === 'plane_measurement' || id === 'head_indexing') {
        return (
          <rect x={-1.5 * 12} y={-1.5 * 12} width={3.0 * 12} height={3.0 * 12} className="stroke-cyan-500 fill-slate-900/40" strokeWidth="1.5" />
        );
      } else if (id === 'cylinder') {
        return (
          <>
            {/* Base fixture block */}
            <rect x={-2.25 * 12} y={-2.25 * 12} width={4.5 * 12} height={4.5 * 12} className="stroke-slate-700 fill-slate-900/20" strokeWidth="1" strokeDasharray="2,2" />
            {/* Main cylinder circle */}
            <circle cx="0" cy="0" r={1.2 * 12} className="stroke-cyan-500 fill-slate-800" strokeWidth="1.5" />
          </>
        );
      } else if (id === 'circle_center') {
        return (
          <>
            {/* Outer block bounds */}
            <rect x={-2.0 * 12} y={-2.0 * 12} width={4.0 * 12} height={4.0 * 12} className="stroke-cyan-500 fill-slate-900/30" strokeWidth="1.5" />
            {/* Actual hollow drilling circle center */}
            <circle cx="0" cy="0" r={1.0 * 12} className="stroke-rose-500 fill-slate-950" strokeWidth="2" strokeDasharray="3,1" />
          </>
        );
      } else if (id === 'hole_distance') {
        return (
          <>
            {/* Outer Block */}
            <rect x={-3.0 * 12} y={-2.0 * 12} width={6.0 * 12} height={4.0 * 12} className="stroke-cyan-500 fill-slate-900/30" strokeWidth="1.5" />
            {/* Bore left */}
            <circle cx={-1.5 * 12} cy="0" r={0.8 * 12} className="stroke-rose-500 fill-slate-950" strokeWidth="2" strokeDasharray="3,1" />
            {/* Bore right */}
            <circle cx={1.5 * 12} cy="0" r={0.8 * 12} className="stroke-rose-500 fill-slate-950" strokeWidth="2" strokeDasharray="3,1" />
          </>
        );
      } else if (id === 'angle_measurement') {
        return (
          <>
            {/* Wedge top base rectangle */}
            <rect x={-2.5 * 12} y={-1.5 * 12} width={4.0 * 12} height={3.0 * 12} className="stroke-cyan-500 orfill-slate-900/30" strokeWidth="1.5" />
          </>
        );
      } else if (id === 'parallelism') {
        return (
          <>
            {/* Outer block boundary */}
            <rect x={-1.5 * 12} y={-2.0 * 12} width={3.0 * 12} height={4.0 * 12} className="stroke-cyan-500 fill-slate-900/30" strokeWidth="1.5" />
            {/* Inner parallel slot channel */}
            <rect x={-0.5 * 12} y={-2.0 * 12} width={1.0 * 12} height={4.0 * 12} className="stroke-rose-500 fill-slate-950" strokeWidth="1.5" strokeDasharray="3,1" />
          </>
        );
      } else if (id === 'complex_part') {
        return (
          <>
            <rect x={-1.5 * 12} y={-1.5 * 12} width={3.0 * 12} height={3.0 * 12} className="stroke-cyan-500 fill-slate-900/20" strokeWidth="1.2" />
            <circle cx="0" cy="0" r={1.0 * 12} className="stroke-cyan-400 fill-slate-800" strokeWidth="1.5" />
          </>
        );
      }
      return (
        <rect x={-1.5 * 12} y={-1.5 * 12} width={3.0 * 12} height={3.0 * 12} className="stroke-cyan-500 fill-none" strokeWidth="1.5" />
      );
    };

    // SIDE PROFILE VIEW SCALE (X across, Y vertically down, viewBox="-100 -20 200 120", table line at svgY=80)
    const renderSideViewGeometry = () => {
      const id = currentLevel.id;
      if (id === 'calibration') {
        return (
          <>
            {/* Calibration stalk */}
            <rect x={-0.18 * 12} y={80 - 0.45 * 15} width={0.36 * 12} height={0.45 * 15} className="stroke-slate-600 fill-slate-800" strokeWidth="1" />
            {/* Calibration sphere */}
            <circle cx="0" cy={80 - 1.05 * 15} r={1.35 * 15} className="stroke-slate-400 fill-slate-700/50" strokeWidth="1.5" />
          </>
        );
      } else if (id === '321_alignment' || id === 'plane_measurement' || id === 'head_indexing') {
        return (
          <rect x={-1.5 * 12} y={80 - 1.5 * 15} width={3.0 * 12} height={1.5 * 15} className="stroke-cyan-500 fill-slate-900/40" strokeWidth="1.5" />
        );
      } else if (id === 'cylinder') {
        return (
          <>
            {/* Base fixture */}
            <rect x={-2.25 * 12} y={80 - 0.2 * 15} width={4.5 * 12} height={0.2 * 15} className="stroke-slate-700 fill-slate-900/20" strokeWidth="1" />
            {/* Main cylinder */}
            <rect x={-1.2 * 12} y={80 - 2.2 * 15} width={2.4 * 12} height={2.0 * 15} className="stroke-cyan-500 fill-slate-800" strokeWidth="1.5" />
          </>
        );
      } else if (id === 'circle_center') {
        return (
          <>
            {/* Left flank of the block */}
            <rect x={-2.0 * 12} y={80 - 1.5 * 15} width={1.0 * 12} height={1.5 * 15} className="stroke-cyan-500 fill-slate-900/35" strokeWidth="1.5" />
            {/* Right flank of the block */}
            <rect x={1.0 * 12} y={80 - 1.5 * 15} width={1.0 * 12} height={1.5 * 15} className="stroke-cyan-500 fill-slate-900/35" strokeWidth="1.5" />
            {/* Center hollow borehole visual bounds */}
            <line x1={-1.0 * 12} y1={80} x2={-1.0 * 12} y2={80 - 1.5 * 15} className="stroke-rose-500" strokeWidth="1.5" strokeDasharray="3,2" />
            <line x1={1.0 * 12} y1={80} x2={1.0 * 12} y2={80 - 1.5 * 15} className="stroke-rose-500" strokeWidth="1.5" strokeDasharray="3,2" />
            <line x1={-1.0 * 12} y1={80} x2={1.0 * 12} y2={80} className="stroke-slate-500" strokeWidth="1" />
          </>
        );
      } else if (id === 'hole_distance') {
        return (
          <>
            {/* Outer bounds left flank */}
            <rect x={-3.0 * 12} y={80 - 1.5 * 15} width={0.7 * 12} height={1.5 * 15} className="stroke-cyan-500 fill-slate-900/35" strokeWidth="1.5" />
            {/* Center bridge */}
            <rect x={-0.7 * 12} y={80 - 1.5 * 15} width={1.4 * 12} height={1.5 * 15} className="stroke-cyan-500 fill-slate-900/35" strokeWidth="1.5" />
            {/* Right flank */}
            <rect x={2.3 * 12} y={80 - 1.5 * 15} width={0.7 * 12} height={1.5 * 15} className="stroke-cyan-500 fill-slate-900/35" strokeWidth="1.5" />
            {/* Bore left lines */}
            <line x1={-2.3 * 12} y1={80} x2={-2.3 * 12} y2={80 - 1.5 * 15} className="stroke-rose-500" strokeWidth="1.5" strokeDasharray="3,1" />
            <line x1={-0.7 * 12} y1={80} x2={-0.7 * 12} y2={80 - 1.5 * 15} className="stroke-rose-500" strokeWidth="1.5" strokeDasharray="3,1" />
            {/* Bore right lines */}
            <line x1={0.7 * 12} y1={80} x2={0.7 * 12} y2={80 - 1.5 * 15} className="stroke-rose-500" strokeWidth="1.5" strokeDasharray="3,1" />
            <line x1={2.3 * 12} y1={80} x2={2.3 * 12} y2={80 - 1.5 * 15} className="stroke-rose-500" strokeWidth="1.5" strokeDasharray="3,1" />
          </>
        );
      } else if (id === 'angle_measurement') {
        return (
          <polygon points={`${-2.5 * 12},80 ${1.5 * 12},80 ${1.5 * 12},${80 - 2.0 * 15}`} className="stroke-cyan-500 fill-slate-900/40" strokeWidth="1.5" />
        );
      } else if (id === 'parallelism') {
        return (
          <polygon points={`${-1.5 * 12},80 ${-1.5 * 12},${80 - 1.5 * 15} ${-0.5 * 12},${80 - 1.5 * 15} ${-0.5 * 12},${80 - 0.5 * 15} ${0.5 * 12},${80 - 0.5 * 15} ${0.5 * 12},${80 - 1.5 * 15} ${1.5 * 12},${80 - 1.5 * 15} ${1.5 * 12},80`} className="stroke-cyan-500 fill-slate-900/35" strokeWidth="1.5" />
        );
      } else if (id === 'complex_part') {
        return (
          <>
            <rect x={-1.5 * 12} y={80 - 1.0 * 15} width={3.0 * 12} height={1.0 * 15} className="stroke-cyan-500 fill-slate-900/30" strokeWidth="1.2" />
            <rect x={-1.0 * 12} y={80 - 2.0 * 15} width={2.0 * 12} height={1.0 * 15} className="stroke-cyan-400 fill-slate-800" strokeWidth="1.5" />
          </>
        );
      }
      return (
        <rect x={-1.5 * 12} y={80 - 1.5 * 15} width={3.0 * 12} height={1.5 * 15} className="stroke-cyan-500 fill-none" strokeWidth="1.5" />
      );
    };

    return (
      <div className="absolute inset-0 z-0 bg-slate-950 flex flex-col items-center justify-center p-4 gap-4 pb-20 pt-20 animate-fade-in">
        <div className="w-full max-w-5xl flex flex-col md:flex-row gap-6 h-[calc(100vh-140px)] min-h-0 select-none">
          
          {/* TOP VIEW SCREEN (XZ PLANE) */}
          <div className="flex-1 flex flex-col h-1/2 md:h-full min-h-0 border border-slate-800 rounded-2xl bg-slate-900/45 p-4 relative overflow-hidden backdrop-blur-md">
            <div className="absolute top-3 left-4 flex items-center gap-2 z-10">
              <span className="material-symbols-outlined text-cyan-400 text-sm">grid_view</span>
              <span className="text-[11px] font-mono tracking-wider text-cyan-400 font-extrabold uppercase">Draufsicht (Top View - XZ Coordinate Plane)</span>
            </div>
            
            <div className="absolute bottom-3 right-4 font-mono text-[9px] text-slate-500 font-bold">
              Meterschnitt: 1.0 dm = 12 px | Raster: ±6.5 dm [X/Z]
            </div>

            <svg className="w-full h-full min-h-0 min-w-0" viewBox="-100 -100 200 200" preserveAspectRatio="xMidYMid meet">
              <circle cx="0" cy="0" r="30" className="stroke-slate-800/25 fill-none" strokeWidth="0.5" />
              <circle cx="0" cy="0" r="60" className="stroke-slate-800/25 fill-none" strokeWidth="0.5" />
              <circle cx="0" cy="0" r="90" className="stroke-slate-800/25 fill-none" strokeWidth="0.5" />
              
              <line x1="-100" y1="0" x2="100" y2="0" className="stroke-slate-800" strokeWidth="1" />
              <line x1="0" y1="-100" x2="0" y2="100" className="stroke-slate-800" strokeWidth="1" />
              
              <g id="top-workpiece-group">
                {renderTopViewGeometry()}
              </g>

              <g id="top-targets-group">
                {targetPoints.map((tp) => {
                  const tx = tp.nominal[0] * 12;
                  const tz = tp.nominal[2] * 12;
                  const isMeasured = tp.status !== 'pending';
                  const isPass = tp.status === 'pass';
                  return (
                    <g key={`top-t-${tp.id}`}>
                      <path 
                        d={`M ${tx - 4} ${tz} L ${tx} ${tz - 4} L ${tx + 4} ${tz} L ${tx} ${tz + 4} Z`} 
                        className={`fill-none stroke-2 ${isMeasured ? (isPass ? 'stroke-emerald-400' : 'stroke-rose-400') : 'stroke-amber-400'}`} 
                      />
                      <text x={tx + 6} y={tz + 3} className="font-mono text-[7px] fill-slate-400 font-bold animate-pulse" textAnchor="start">{tp.id}</text>
                    </g>
                  );
                })}
              </g>

              <g id="top-stylus-group">
                <line x1={curX * 12} y1="-100" x2={curX * 12} y2="100" className="stroke-slate-800/40" strokeWidth="0.75" strokeDasharray="3,3" />
                <line x1="-100" y1={curZ * 12} x2="100" y2={curZ * 12} className="stroke-slate-800/40" strokeWidth="0.75" strokeDasharray="3,3" />

                <circle cx={curX * 12} cy={curZ * 12} r="5" className="stroke-slate-500 fill-slate-900/60" strokeWidth="0.5" />
                <circle cx={curX * 12} cy={curZ * 12} r={0.15 * 12} className="fill-rose-500 stroke-red-200" strokeWidth="0.8" />
                <circle cx={curX * 12} cy={curZ * 12} r={0.3 * 12} className="stroke-rose-400 fill-none opacity-50" strokeWidth="0.3" />
              </g>
            </svg>
          </div>

          {/* SIDE HEIGHT VIEW SCREEN (XY PLANE) */}
          <div className="flex-1 flex flex-col h-1/2 md:h-full min-h-0 border border-slate-800 rounded-2xl bg-slate-900/45 p-4 relative overflow-hidden backdrop-blur-md">
            <div className="absolute top-3 left-4 flex items-center gap-2 z-10">
              <span className="material-symbols-outlined text-cyan-400 text-sm">view_sidebar</span>
              <span className="text-[11px] font-mono tracking-wider text-cyan-400 font-extrabold uppercase">Seitenansicht (Side Heights - XY Coordinate Plane)</span>
            </div>
            
            <div className="absolute bottom-3 right-4 font-mono text-[9px] text-slate-500 font-bold">
              Vertical scale: 1.0 dY = 15 px | Granite Base at Y=0 (80px)
            </div>

            <svg className="w-full h-full min-h-0 min-w-0" viewBox="-100 -20 200 120" preserveAspectRatio="xMidYMid meet">
              <line x1="-100" y1="80" x2="100" y2="80" className="stroke-slate-700" strokeWidth="1.5" />
              <line x1="-100" y1="50" x2="100" y2="50" className="stroke-slate-800/40" strokeWidth="0.5" strokeDasharray="2,2" />
              <line x1="-100" y1="20" x2="100" y2="20" className="stroke-slate-800/40" strokeWidth="0.5" strokeDasharray="2,2" />

              <g id="side-workpiece-group">
                {renderSideViewGeometry()}
              </g>

              <g id="side-targets-group">
                {targetPoints.map((tp) => {
                  const tx = tp.nominal[0] * 12;
                  const ty = 80 - tp.nominal[1] * 15;
                  const isMeasured = tp.status !== 'pending';
                  const isPass = tp.status === 'pass';
                  return (
                    <g key={`side-t-${tp.id}`}>
                      <path 
                        d={`M ${tx - 3} ${ty} L ${tx} ${ty - 3} L ${tx + 3} ${ty} L ${tx} ${ty + 3} Z`} 
                        className={`fill-none stroke-1.5 ${isMeasured ? (isPass ? 'stroke-emerald-400' : 'stroke-rose-400') : 'stroke-amber-400'}`} 
                      />
                    </g>
                  );
                })}
              </g>

              {/* Live Stylus, Quill Stem representation */}
              <g id="side-stylus-group">
                <rect x="-100" y="-15" width="200" height="20" className="fill-slate-800 stroke-slate-700" strokeWidth="0.5" />
                <line x1={curX * 12} y1="5" x2={curX * 12} y2={80 - curY * 15} className="stroke-cyan-500/20" strokeWidth="2" />
                
                <rect x={curX * 12 - 3} y="5" width="6" height={80 - curY * 15 - 5} className="fill-slate-755 fill-slate-700 stroke-slate-500" strokeWidth="0.5" />
                <rect x={curX * 12 - 5} y={80 - curY * 15 - 12} width="10" height="12" className="fill-slate-800 stroke-slate-600 rounded-sm" strokeWidth="0.5" />
                <circle cx={curX * 12} cy={80 - curY * 15 - 6} r="3" className="fill-slate-900" />
                
                <circle cx={curX * 12} cy={80 - curY * 15} r={0.15 * 12} className="fill-rose-500 stroke-red-200" strokeWidth="0.8" />
                <circle cx={curX * 12} cy={80 - curY * 15} r={0.3 * 12} className="stroke-rose-400 fill-none opacity-40 animate-pulse" strokeWidth="0.3" />
              </g>
            </svg>
          </div>

        </div>
      </div>
    );
  };

  return (
    <div id="app-body" className="min-h-screen relative w-full overflow-hidden flex flex-col justify-between select-none">
      
      {/* Fallback overlay when WebGL / Hardware Acceleration under iframe environment fails */}
      {hasWebglError && (
        <div className="fixed inset-0 z-[99999] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/30 rounded-2xl max-w-lg w-full p-6 shadow-2xl shadow-black/80 space-y-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-500 shrink-0">
                <span className="material-symbols-outlined text-2xl">sensors_off</span>
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-100 uppercase tracking-wide">WebGL-Hardwarebeschleunigung nicht verfügbar</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Ihr Browser oder Ihr aktuelles System erlaubt keine 3D WebGL-Kontext-Initialisierung. Das liegt oft an Virtualisierung (z.B. Cloud-Container-Sitzung) oder deaktivierter Grafikbeschleunigung im Browser.
                </p>
              </div>
            </div>

            <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800 space-y-3 font-mono text-[11px] text-slate-300">
              <div className="text-amber-400 font-bold uppercase text-[9px] tracking-wider">Schnelle Lösungen & Links:</div>
              <div className="flex items-start gap-2.5">
                <span className="text-amber-500 font-bold">1.</span>
                <span><b>Direkter Live-Link:</b> Laden Sie die Anwendung direkt außerhalb des iframe-Fensters, um native GPU-Rendering-Privilegien zu aktivieren:<br/>
                <a 
                  href="https://ais-pre-yn2z5hbumgs4qwdlxdcu5x-280966017412.europe-west2.run.app" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-cyan-400 font-bold underline hover:text-cyan-300 break-all"
                >
                  https://ais-pre-yn2z5hbumgs4qwdlxdcu5x-280966017412.europe-west2.run.app
                </a>
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="text-amber-500 font-bold">2.</span>
                <span><b>Hardwarebeschleunigung im Browser:</b> Gehen Sie zu <i>Einstellungen &gt; System</i> und aktivieren Sie die Option "Hardwarebeschleunigung verwenden, wenn verfügbar". Starten Sie den Browser danach neu.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="text-amber-500 font-bold">3.</span>
                <span><b>Entwickler-Sitzung exportieren:</b> Sie können den gesamten Quellcode als vollwertige, eigenständige Offline-App herunterladen über das Menü <b>"Export to ZIP"</b> oben rechts im Workspace!</span>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button 
                onClick={() => {
                  window.open("https://ais-pre-yn2z5hbumgs4qwdlxdcu5x-280966017412.europe-west2.run.app", '_blank');
                }}
                className="flex-1 py-2 px-4 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-bold rounded-lg text-xs transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-amber-900/20"
              >
                <span className="material-symbols-outlined text-sm">open_in_new</span>
                In neuem Tab öffnen
              </button>
              <button 
                onClick={() => setHasWebglError(false)}
                className="py-2 px-4 bg-slate-800 hover:bg-slate-705 text-slate-350 hover:text-white font-bold rounded-lg text-xs transition-all active:scale-[0.98] cursor-pointer"
              >
                Steuerungs-HUD anzeigen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Visual Red Flash Impact Overlay */}
      <div id="contact-flash" className="fixed inset-0 bg-red-600/20 pointer-events-none z-[100] transition-opacity duration-100 ease-out opacity-0" />

      {/* PIP Border Overlay (Taster-Cam) */}
      {!isSplitScreen && (
        <div className="absolute top-[80px] right-[20px] w-[250px] h-[250px] border border-cyan-500/40 rounded-lg pointer-events-none shadow-2xl shadow-cyan-900/40 z-10 hidden sm:block overflow-hidden bg-transparent">
           <div className="absolute top-0 right-0 bg-cyan-950/90 border-b border-l border-cyan-500/40 px-2 py-0.5 text-[8px] font-bold text-cyan-400 font-mono tracking-wider backdrop-blur-md rounded-bl-md">
             <span className="inline-block w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse mr-1.5 align-middle"></span>
             TASTER-CAM LIVE
           </div>
           {/* Crosshair */}
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 border border-white/10 rounded-full pointer-events-none" />
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-1 bg-cyan-400/50 rounded-full pointer-events-none" />
        </div>
      )}

      {/* 3D Fixed Background Render Vessel or 2D CAD Vector Blueprint Fallback */}
      {is2DMode ? (
        render2DVectorInspector()
      ) : (
        <div 
          ref={canvasContainerRef} 
          id="three-canvas-container" 
          className="fixed inset-0 z-0 bg-cover bg-center"
          style={{
            backgroundImage: `linear-gradient(to bottom, rgba(10, 17, 34, 0.45), rgba(6, 10, 20, 0.85)), url('https://lh3.googleusercontent.com/aida-public/AB6AXuCKx-gQMxgIKn5JUwG18teWUpGG-J-L4o1_Ojc4aqUULp-R7XQ188bDzmuUxs_FTP8Mm9peLJY5fDN3bC4StuPtTPCQRXNFsjmUnhtBX8Htaj-WDIoMkarzFcKHWDrjQ3B_dvZkUzyNRvU8EMOe-Xl1ycn4pCGwj40595EFqc-2JGwRkdb57o25xx4uzPnfvD_y9mZZ3f-X85qfAlst70VWZQd5J8-j1cehvydLaNprZaYrQ2GN7hXZyaclT8AOAwTH41qB89wh93C-')`
          }}
        />
      )}

      {/* Main UI Header Screen Overlay */}
      <header className="hidden fixed top-0 w-full bg-slate-900/65 backdrop-blur-md border-b border-cyan-500/15 justify-between items-center px-6 h-16 z-[60] pt-[env(safe-area-inset-top)] box-content">
        <div className="flex items-center gap-3">
          <span className="material-symbols-outlined text-cyan-400 text-2xl drop-shadow-[0_0_8px_rgba(34,211,238,0.4)]">precision_manufacturing</span>
          <div className="flex flex-col">
            <h1 className="font-sans text-lg font-bold tracking-tight text-slate-100 uppercase sm:text-cyan-300">
              KMG-CONTROLLER v4.0 - OPTICS PRO
            </h1>
            <span className="text-[10px] font-mono text-cyan-500/80 -mt-1 hidden sm:inline">HIGH FIDELITY METROLOGY SIMULATOR</span>
          </div>
        </div>

        {/* CMM HUD System Telemetry Status Panel */}
        <div className="flex items-center gap-4">
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all duration-300 ${
            systemState === 'online' ? 'bg-emerald-950/45 border-emerald-500/20' :
            systemState === 'contact' ? 'bg-cyan-950/45 border-cyan-500/40 animate-pulse bg-cyan-950/50 scale-[1.03]' :
            'bg-rose-950/45 border-rose-500/45 animate-bounce shadow-lg shadow-rose-900/30'
          }`}>
            <span className={`w-2 h-2 rounded-full ${
              systemState === 'online' ? 'bg-emerald-400 animate-pulse' :
              systemState === 'contact' ? 'bg-cyan-400' :
              'bg-rose-500'
            }`} />
            <span className={`font-mono text-[10px] uppercase tracking-wider font-semibold ${
              systemState === 'online' ? 'text-emerald-400' :
              systemState === 'contact' ? 'text-cyan-400' :
              'text-rose-400'
            }`}>
              {systemState === 'online' && 'System: Online'}
              {systemState === 'contact' && 'Status: TASTUNG'}
              {systemState === 'error' && 'Status: COLLISION'}
            </span>
          </div>
          
          <button 
            onClick={() => setIs2DMode(prev => !prev)} 
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all text-xs font-mono font-bold select-none cursor-pointer ${
              is2DMode 
                ? 'bg-cyan-950/60 border-cyan-500/50 text-cyan-300' 
                : 'bg-slate-900/40 border-slate-700/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">
              {is2DMode ? 'grid_view' : '3d_rotation'}
            </span>
            <span>{is2DMode ? '2D-ANSICHT' : '3D-ANSICHT'}</span>
          </button>
          
          <button 
            onClick={() => setActiveTab('hilfe')} 
            className="material-symbols-outlined text-slate-400 hover:text-white p-2 transition-colors rounded-lg hover:bg-slate-800/50"
          >
            settings
          </button>
        </div>
      </header>

      {/* Main Navigation Tab Container Workspace */}
      <main className="relative w-full min-h-screen z-10 flex justify-between p-4 sm:p-6 pt-20 pb-24 pointer-events-none flex-col md:flex-row gap-4 sm:gap-6">
        
        {/* Navigation Switch Control Grid depending on active tab */}
        
        {/* TAB 1: STEUERN (Core 3D Simulation Gantry fly-through) */}
        {activeTab === 'steuern' && (
          <div className="flex flex-col justify-between h-full w-full pointer-events-none gap-4 md:flex-row relative">
            
            {/* Floating button on mobile/tablet to open Mobile settings panel */}
            <div className="lg:hidden absolute top-2 left-2 z-40 pointer-events-auto">
              <button 
                onClick={() => setShowMobileSettings(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-900/90 backdrop-blur-md text-cyan-400 font-extrabold border border-cyan-500/30 rounded-xl text-[11px] font-mono active:scale-95 shadow-lg shadow-cyan-950/40 select-none cursor-pointer"
                style={{ touchAction: 'manipulation' }}
              >
                <span className="material-symbols-outlined text-sm font-bold">menu</span>
                MESSAUFGABE
              </button>
            </div>

            {/* Mobile coordinates HUD floating ribbon */}
            <div className="lg:hidden absolute top-2 right-2 bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-xl border border-cyan-500/25 flex items-center gap-2 text-cyan-400 font-mono text-[10px] shadow-lg shadow-cyan-950/40 z-40 max-w-[55vw] overflow-hidden select-none">
              <span className="text-[8px] bg-cyan-500/15 text-cyan-300 px-1 py-0.2" style={{ borderRadius: '4px', border: '1px solid rgba(6,182,212,0.2)' }}>MM</span>
              <div className="flex gap-1.5">
                <span>X:<b className="text-slate-200 ml-0.5">{positionX >= 0 ? '+' : ''}{positionX.toFixed(1)}</b></span>
                <span>Y:<b className="text-slate-200 ml-0.5">{positionY >= 0 ? '+' : ''}{positionY.toFixed(1)}</b></span>
                <span>Z:<b className="text-slate-200 ml-0.5">{positionZ >= 0 ? '+' : ''}{positionZ.toFixed(1)}</b></span>
              </div>
            </div>

            {/* Mobile slide-out configuration drawer */}
            {showMobileSettings && (
              <div 
                className="lg:hidden fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-[100] flex justify-start pointer-events-auto"
                onClick={() => setShowMobileSettings(false)}
              >
                <div 
                  className="w-[85vw] max-w-sm bg-slate-950/95 backdrop-blur-xl border-r border-cyan-500/15 h-full p-5 flex flex-col gap-4 overflow-y-auto scrollbar-thin shadow-2xl relative pt-[calc(30px+env(safe-area-inset-top))]"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-1">
                    <span className="font-sans font-bold text-slate-100 text-xs tracking-wider uppercase">Mess-Konfiguration</span>
                    <button 
                      onClick={() => setShowMobileSettings(false)}
                      className="text-slate-400 hover:text-white material-symbols-outlined cursor-pointer"
                    >
                      close
                    </button>
                  </div>
                  
                  {/* Mission Selector */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5 text-cyan-400">
                      <span className="material-symbols-outlined text-base">flag</span>
                      <span className="font-mono text-[10px] font-extrabold tracking-wider">AKTIVE MESSAUFGABE</span>
                    </div>
                    {levels.map((lvl, index) => (
                      <button
                        key={lvl.id}
                        onClick={() => {
                          setActiveLevelIdx(index);
                          setShowMobileSettings(false);
                        }}
                        className={`w-full text-left p-2.5 rounded-xl border text-[11px] flex justify-between items-center transition-all cursor-pointer ${
                          activeLevelIdx === index 
                            ? 'bg-cyan-500/15 border-cyan-400/40 text-cyan-300 font-semibold' 
                            : 'bg-slate-800/35 border-slate-700/40 text-slate-400 hover:text-slate-200'
                        }`}
                        style={{ touchAction: 'manipulation' }}
                      >
                        <span>{lvl.name}</span>
                        {activeLevelIdx === index && (
                          <span className="material-symbols-outlined text-cyan-400 text-xs">radio_button_checked</span>
                        )}
                      </button>
                    ))}
                  </div>

                  {/* Diagnoses Card */}
                  <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/80 flex flex-col gap-2">
                    <span className="font-mono text-[9px] text-cyan-400 tracking-wider font-bold">MESSDIAGNOSE</span>
                    <h4 className="text-[12px] text-slate-200 font-medium leading-normal">{activeLevel.name}</h4>
                    <p className="text-[10px] text-slate-400 leading-normal">{activeLevel.description}</p>
                    
                    <div className="grid grid-cols-2 gap-3 mt-1.5 text-center font-mono">
                      <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                        <span className="text-[8px] text-slate-500 block">KOLLISION</span>
                        <span className={`text-sm font-extrabold ${collisions > 0 ? 'text-orange-400' : 'text-slate-300'}`}>{collisions}</span>
                      </div>
                      <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                        <span className="text-[8px] text-slate-500 block">PRÄZISION</span>
                        <span className="text-sm font-extrabold text-emerald-400">{accuracy.toFixed(1)}%</span>
                      </div>
                    </div>
                  </div>

                  {/* Materials Quick Link */}
                  <div className="space-y-1.5">
                    <span className="text-[9px] text-slate-500 font-mono tracking-wider font-bold uppercase block">Komponenten-Auswahl</span>
                    <div className="grid grid-cols-2 gap-2 text-[10px]">
                      <button 
                        onClick={() => { setActiveTab('bibliothek'); setShowMobileSettings(false); }} 
                        className="p-2.5 bg-slate-950/60 border border-slate-800 text-slate-300 rounded-lg font-semibold flex items-center justify-between uppercase font-mono cursor-pointer hover:border-cyan-500/30"
                        style={{ touchAction: 'manipulation' }}
                      >
                        <span className="flex items-center gap-1">
                          <span className="material-symbols-outlined text-xs">texture</span>
                          {material.split(' ')[0]}
                        </span>
                        <span className="material-symbols-outlined text-xs text-slate-500">chevron_right</span>
                      </button>
                      <button 
                        onClick={() => { setActiveTab('bibliothek'); setShowMobileSettings(false); }} 
                        className="p-2.5 bg-slate-950/60 border border-slate-800 text-slate-300 rounded-lg font-semibold flex items-center justify-between uppercase font-mono cursor-pointer hover:border-cyan-500/30"
                        style={{ touchAction: 'manipulation' }}
                      >
                        <span className="flex items-center gap-1">
                          <span className="material-symbols-outlined text-xs">lens</span>
                          Ø {probeSize.toFixed(1)}
                        </span>
                        <span className="material-symbols-outlined text-xs text-slate-500">chevron_right</span>
                      </button>
                    </div>
                  </div>

                  <button 
                    onClick={() => { restartLevelTask(); setShowMobileSettings(false); }}
                    className="w-full py-2.5 bg-slate-800 hover:bg-slate-755 font-bold text-slate-100 text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all border border-slate-700 cursor-pointer mt-2"
                    style={{ touchAction: 'manipulation' }}
                  >
                    <span className="material-symbols-outlined text-sm">sync</span>
                    NEUSTART DER AUFGABE
                  </button>

                  <button 
                    onClick={() => setShowMobileSettings(false)}
                    className="w-full py-2.5 bg-cyan-500 hover:bg-cyan-400 font-bold text-slate-950 text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all mt-auto cursor-pointer"
                    style={{ touchAction: 'manipulation' }}
                  >
                    <span className="material-symbols-outlined text-sm font-bold">play_arrow</span>
                    BEWEGUNG STARTEN
                  </button>
                </div>
              </div>
            )}
            
            {/* Sidebar Left: Compact Consolidated Wenzel controller panel */}
            <div className="hidden lg:flex flex-col gap-3 w-full lg:w-72 xl:w-80 shrink-0 select-none pointer-events-auto">
              
              <div className="bg-slate-950/95 backdrop-blur-xl p-4 rounded-xl border border-slate-800/80 flex flex-col gap-3 shadow-2xl">
                
                {/* 1. Header with Compact Mission Dropdown & Wenzel Branding */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[9px] text-cyan-400 tracking-wider font-bold">MESSAUFGABE</span>
                    <span className="font-mono text-[8.5px] bg-cyan-500/10 text-cyan-300 px-1.5 py-0.2 rounded border border-cyan-500/15 font-bold">CMM TRAINER</span>
                  </div>
                  
                  <div className="relative">
                    <select 
                      value={activeLevelIdx}
                      onChange={(e) => setActiveLevelIdx(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-1.5 px-2 rounded-lg text-xs font-semibold focus:outline-none focus:border-cyan-500/40 appearance-none cursor-pointer"
                    >
                      {levels.map((lvl, index) => (
                        <option key={lvl.id} value={index} className="bg-slate-900 text-slate-100">
                          {lvl.name}
                        </option>
                      ))}
                    </select>
                    <span className="material-symbols-outlined text-slate-500 text-xs absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">
                      unfold_more
                    </span>
                  </div>
                </div>

                {/* 2. Compact Live Telemetry values bar */}
                <div className="bg-slate-950/50 rounded-lg p-2 border border-slate-800/60">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-[8px] text-slate-500 tracking-widest font-bold">FEIN-KOORDINATEN (MM)</span>
                    <span className="font-mono text-[8px] text-cyan-400/80 font-bold">STATUS: {systemState.toUpperCase()}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-1 field-mono text-center">
                    <div className="bg-slate-900/50 p-1 rounded border border-slate-800">
                      <span className="text-[7.5px] text-slate-500 block">X-ACHSE (T)</span>
                      <span className="text-[12px] font-bold text-cyan-400 font-mono">
                        {positionX >= 0 ? '+' : ''}{positionX.toFixed(3)}
                      </span>
                    </div>
                    <div className="bg-slate-900/50 p-1 rounded border border-slate-800">
                      <span className="text-[7.5px] text-slate-550 block">Y-ACHSE (T)</span>
                      <span className="text-[12px] font-bold text-cyan-400 font-mono">
                        {positionZ >= 0 ? '+' : ''}{positionZ.toFixed(3)}
                      </span>
                    </div>
                    <div className="bg-slate-900/50 p-1 rounded border border-slate-800 font-mono">
                      <span className="text-[7.5px] text-slate-550 block">Z-ACHSE (P)</span>
                      <span className="text-[12px] font-bold text-cyan-400 font-mono">
                        {positionY >= 0 ? '+' : ''}{positionY.toFixed(3)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* 3. Task Diagnostics Summary */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-mono text-[8px] text-slate-500 font-bold uppercase">MESSDIAGNOSE</span>
                    <span className={`text-[8.5px] font-extrabold ${isLevelFinished ? 'text-emerald-400' : 'text-cyan-400'}`}>
                      {isLevelFinished ? 'ERFOLG' : 'MESSUNG LÄUFT...'}
                    </span>
                  </div>
                  <h3 className="text-xs text-slate-200 font-medium leading-tight">
                    {activeLevel.name}
                  </h3>
                  <p className="text-[10px] text-slate-400 leading-normal font-sans line-clamp-1">
                    {activeLevel.description}
                  </p>
                </div>

                {/* 4. Live Stats Meter */}
                <div className="grid grid-cols-4 gap-2 text-center font-mono">
                  <div className="bg-slate-950/40 py-1.5 rounded-lg border border-slate-800">
                    <span className="block text-[7.5px] text-slate-500 uppercase">ZEIT</span>
                    <span className="text-xs font-bold text-slate-300">
                      {(elapsedTimeMs / 1000).toFixed(1)}s
                    </span>
                  </div>
                  <div className="bg-slate-950/40 py-1.5 rounded-lg border border-slate-800">
                    <span className="block text-[7.5px] text-slate-500 uppercase">PUNKTE</span>
                    <span className="text-xs font-bold text-cyan-400">
                      {isLevelFinished ? finalScore : '---'}
                    </span>
                  </div>
                  <div className="bg-slate-950/40 py-1.5 rounded-lg border border-slate-800">
                    <span className="block text-[7.5px] text-slate-500 uppercase">KOLLISION</span>
                    <span className={`text-xs font-bold ${collisions > 0 ? 'text-orange-400' : 'text-slate-300'}`}>
                      {collisions}
                    </span>
                  </div>
                  <div className="bg-slate-940/40 py-1.5 rounded-lg border border-slate-800">
                    <span className="block text-[7.5px] text-slate-500 uppercase">PRÄZISION</span>
                    <span className="text-xs font-bold text-emerald-400">
                      {accuracy.toFixed(1)}%
                    </span>
                  </div>
                </div>

                {isLevelFinished && (
                  <div className="bg-emerald-950/40 p-3 rounded-lg border border-emerald-500/30 text-center animate-pulse">
                    <span className="material-symbols-outlined text-emerald-400 text-3xl mb-1">emoji_events</span>
                    <h4 className="text-emerald-400 font-bold text-sm">LEVEL {activeLevelIdx + 1} BEENDET</h4>
                    <p className="text-emerald-300/80 text-[10px] mt-1 font-mono">FINALE PUNKTZAHL: {finalScore}</p>
                    <p className="text-slate-400 text-[9px] mt-2">Gehe zur Bibliothek (📚) für das nächste Werkstück.</p>
                  </div>
                )}

                {/* --- BEGINNER MODE HELPER --- */}
                <div className="bg-slate-950/40 p-2 rounded-lg border border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] text-slate-350 font-semibold select-none">
                    <div className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-amber-500 text-sm font-bold">school</span>
                      <span>Anfänger-Modus (Hilfe)</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={isBeginnerMode}
                        onChange={(e) => setIsBeginnerMode(e.target.checked)}
                        className="sr-only peer" 
                      />
                      <div className="w-7 h-4 bg-slate-850 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-200 after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-cyan-500" />
                    </label>
                  </div>

                  {isBeginnerMode && (
                    <div className="space-y-1.5 pt-1.5 border-t border-slate-850">
                      <p className="text-[8.5px] leading-relaxed text-slate-450">
                        Keine Wandkollisionen. Klicke auf ein Messziel im Protokoll-Tab oder fliege automatisch:
                      </p>
                      <button
                        onClick={() => {
                          const nextOpen = targetPoints.find(p => p.status === 'pending');
                          if (nextOpen) {
                            autoDriveToTargetPoint(nextOpen);
                          } else {
                            playCmmSound('beep');
                          }
                        }}
                        className="w-full py-1.5 px-2 bg-gradient-to-r from-emerald-600/15 to-cyan-600/15 hover:from-emerald-500/20 hover:to-cyan-500/20 active:scale-95 text-[9px] text-emerald-300 border border-emerald-500/20 font-mono font-bold rounded flex items-center justify-center gap-1 cursor-pointer transition-all shadow shadow-slate-950"
                      >
                        <span className="material-symbols-outlined text-[10px] animate-pulse">navigation</span>
                        CNC-FAHRT STARTEN
                      </button>
                    </div>
                  )}
                </div>

                {/* 5. Checkpoints (Messstellen Indicator Dots) */}
                <div className="space-y-1 font-mono">
                  <div className="flex justify-between items-center text-[8.5px] text-slate-500">
                    <span>MESSSTELLEN</span>
                    <span>{targetPoints.filter(p => p.status !== 'pending').length}/{targetPoints.length}</span>
                  </div>
                  <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden flex gap-0.5">
                    {targetPoints.map((p, idx) => (
                      <div 
                        key={p.id} 
                        className={`h-full flex-1 transition-all duration-300 ${
                          p.status === 'pending' ? 'bg-slate-800' :
                          p.status === 'pass' ? 'bg-emerald-400 shadow-[0_0_4px_#34d399]' :
                          'bg-amber-400 shadow-[0_0_4px_#fbbf24]'
                        }`} 
                      />
                    ))}
                  </div>
                </div>

                {/* 6. Unified Quick Controller Action Buttons */}
                <div className="flex gap-2 pt-1 font-sans">
                  <button 
                    onClick={restartLevelTask}
                    title="Zurücksetzen"
                    className="flex-1 p-2 bg-slate-850 hover:bg-slate-800 active:scale-95 text-slate-300 rounded-lg border border-slate-800 transition-all flex items-center justify-center cursor-pointer gap-2"
                  >
                    <span className="material-symbols-outlined text-base">sync</span>
                    <span className="text-[11px] font-bold tracking-wider">ZURÜCKSETZEN</span>
                  </button>
                </div>

                {/* 7. REVO Articulation Settings */}
                {renderRevoArticulationPanel(false)}



                {/* Material Selected HUD footer inside */}
                <div className="border-t border-slate-800/60 pt-2 flex items-center justify-between text-[8px] text-slate-500 font-mono">
                  <span>WST: <b className="text-slate-400">{material.split(' ')[0].toUpperCase()}</b></span>
                  <span>RUBIN: <b className="text-slate-400">Ø {probeSize.toFixed(1)} MM</b></span>
                </div>

              </div>
            </div>

            {/* Middle bottom area: Controls & Driving Presets */}
            
            {/* Extended CAD Camera & Viewport Controls Toolbar */}
            {!is2DMode && (
              <div 
                className="absolute top-2 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur-xl px-4 py-1.5 rounded-2xl border border-cyan-500/15 flex items-center gap-2 opacity-95 hover:opacity-100 transition-opacity pointer-events-auto shadow-xl shadow-slate-950/45 z-30 min-w-max"
              >
                {/* 3 Zoom Levels */}
                <div className="flex items-center gap-0 bg-slate-900 rounded border border-slate-700/50 overflow-hidden">
                  <button 
                    onPointerDown={(e) => { e.preventDefault(); autoZoomToWorkpiece(); }} 
                    className="px-2 py-1 text-[9px] text-emerald-400 hover:text-white hover:bg-slate-800 font-bold transition-all cursor-pointer border-r border-slate-800"
                    title="Auto-Zoom (Einpassen auf Werkstück)"
                  >
                    AUTO
                  </button>
                  <button 
                    onPointerDown={(e) => { e.preventDefault(); setZoomLevel(1); }} 
                    className="px-2 py-1 text-[9px] text-slate-400 hover:text-white hover:bg-slate-800 font-bold transition-all cursor-pointer border-r border-slate-800"
                    title="Zoom 1 (Fern)"
                  >
                    Z1
                  </button>
                  <button 
                    onPointerDown={(e) => { e.preventDefault(); setZoomLevel(2); }} 
                    className="px-2 py-1 text-[9px] text-slate-400 hover:text-white hover:bg-slate-800 font-bold transition-all cursor-pointer border-r border-slate-800"
                    title="Zoom 2 (Mittel)"
                  >
                    Z2
                  </button>
                  <button 
                    onPointerDown={(e) => { e.preventDefault(); setZoomLevel(3); }} 
                    className="px-2 py-1 text-[9px] text-slate-400 hover:text-white hover:bg-slate-800 font-bold transition-all cursor-pointer"
                    title="Zoom 3 (Nah)"
                  >
                    Z3
                  </button>
                </div>

                <div className="w-[1px] h-3.5 bg-slate-800 mx-1" />

                {/* Focus Next Target Button */}
                <button 
                  onClick={focusNextTarget}
                  title="Auf nächsten Zielpunkt fokussieren"
                  className="flex items-center gap-1.5 px-2.5 py-1 text-[10px] rounded font-bold transition-all border border-slate-700/50 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 hover:text-amber-300 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[12px]">my_location</span>
                  FOKUS ZIEL
                </button>

                <div className="w-[1px] h-3.5 bg-slate-800 mx-1" />
                
                {/* X-Ray / Transparency Button */}
                <button 
                  onClick={() => setIsXrayMode(!isXrayMode)} 
                  title="Röntgenblick / Transparenz"
                  className={`flex items-center gap-1.5 px-2.5 py-1 text-[10px] rounded font-bold transition-all border cursor-pointer ${
                    isXrayMode 
                      ? 'bg-rose-500/15 border-rose-500/30 text-rose-300' 
                      : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-800/40'
                  }`}
                >
                  <span className="material-symbols-outlined text-[12px]">visibility</span>
                  X-RAY
                </button>

                <div className="w-[1px] h-3.5 bg-slate-800 mx-1" />

                {/* Split Screen Button */}
                <button 
                  onClick={() => setIsSplitScreen(!isSplitScreen)} 
                  className={`flex items-center gap-1.5 px-2.5 py-1 text-[10px] rounded font-bold transition-all border cursor-pointer ${
                    isSplitScreen 
                      ? 'bg-cyan-500/15 border-cyan-500/30 text-cyan-300' 
                      : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-800/40'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" style={{ display: isSplitScreen ? 'inline-block' : 'none' }} />
                  SPLIT-VIEW
                </button>
                
                {/* Vector Journey Drive Button */}
                <button 
                  onClick={() => setIsVectorJourneyActive(!isVectorJourneyActive)} 
                  className={`flex items-center gap-1.5 px-2.5 py-1 text-[10px] rounded font-bold transition-all border cursor-pointer ${
                    isVectorJourneyActive 
                      ? 'bg-amber-500/15 border-amber-500/30 text-amber-300' 
                      : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-800/40'
                  }`}
                  title="Sondenkopf folgt dem Pfad-Vektor zum Checkpoint"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" style={{ display: isVectorJourneyActive ? 'inline-block' : 'none' }} />
                  VEKTOR-FAHRT
                </button>
              </div>
            )}

            {/* Play info tips badge */}
            {isKeyboardTipsOpen && (
              <div className="absolute top-14 left-1/2 -translate-x-1/2 bg-slate-955/90 backdrop-blur-md p-3 rounded-xl border border-cyan-500/10 max-w-sm pointer-events-auto flex gap-3 text-slate-300 items-start shadow-xl">
                <span className="material-symbols-outlined text-cyan-400 text-lg mt-0.5">keyboard</span>
                <div className="flex-1 text-[10.5px] leading-relaxed">
                  <b className="text-cyan-300 font-semibold block mb-0.5">Tastatursteuerung aktiv!</b>
                  Bewege die Sonden-Nadel mit den <b className="text-slate-100">Pfeiltasten</b> und verändere die Höhe (Z-Pinole) mit <b className="text-slate-100">W / S</b> oder <b className="text-slate-100">Bild-Auf/-Ab</b>. Halte <b className="text-slate-100">Shift für Schnellsatz (Eilgang)</b>. Die Antastung erfolgt automatisch bei Kontakt!
                </div>
                <button onClick={() => setIsKeyboardTipsOpen(false)} className="text-slate-500 hover:text-slate-300 text-xs">✕</button>
              </div>
            )}
            
            {/* Industrial physical CMM control panel overlay right */}
            <div className="flex flex-col items-center sm:items-end gap-3 sm:gap-5 self-end pointer-events-auto w-full md:w-auto ml-auto select-none mt-auto">
              
              {/* REVO Panel for mobile view only */}
              {renderRevoArticulationPanel(true)}

              <div className="flex items-end justify-center gap-3 sm:gap-6 w-full">
                
                {/* Z Axis vertical altitude custom slider controller */}
                <div className="flex flex-col items-center gap-1.5">
                  <div 
                    onMouseDown={setupZSliderTracker}
                    onTouchStart={setupZSliderTracker}
                    className="bg-slate-950/95 backdrop-blur-xl w-10 h-36 sm:w-12 sm:h-40 rounded-2xl flex flex-col items-center justify-between py-4 border border-cyan-500/15 relative shadow-lg shadow-cyan-950/25 select-none overflow-hidden cursor-ns-resize"
                  >
                    <span className="font-mono text-[6px] sm:text-[7px] text-cyan-400 font-extrabold absolute top-1.5 tracking-wider select-none text-center w-full">PINOLE (Z)</span>
                    
                    {/* Visual +Z, -Z orientation indicators */}
                    <div className="absolute top-5 left-1/2 -translate-x-1/2 text-[8px] sm:text-[9px] font-mono font-black text-emerald-400 select-none pointer-events-none z-10 bg-slate-950/40 px-1 rounded-sm">+Z</div>
                    <div className="absolute bottom-5 left-1/2 -translate-x-1/2 text-[8px] sm:text-[9px] font-mono font-black text-emerald-400 select-none pointer-events-none z-10 bg-slate-950/40 px-1 rounded-sm">-Z</div>

                    {/* Visual vertical slider background indicator track */}
                    <div className="absolute inset-x-3.5 sm:inset-x-4 top-6 bottom-6 bg-slate-950 rounded-full overflow-hidden border border-slate-800 pointer-events-none">
                      {/* Height-filled blue indicator */}
                      <div 
                        className="absolute bottom-0 w-full bg-gradient-to-t from-cyan-600 to-cyan-400 transition-all duration-75"
                        style={{ height: `${controlZVal}%` }}
                      />
                      {/* Sliding handle node */}
                      <div 
                        className="absolute w-full h-1 bg-white border-y border-cyan-305 shadow shadow-cyan-500/50"
                        style={{ bottom: `calc(${controlZVal}% - 2px)` }}
                      />
                    </div>
 
                    {/* Height percentage readout labels bubble */}
                    <span className="font-mono text-[7px] text-slate-400 absolute bottom-1 sm:bottom-1.5 select-none uppercase font-bold text-center w-full scale-90 sm:scale-100">
                      Z: {controlZVal.toFixed(0)}%
                    </span>
                  </div>
                  <span className="font-mono text-[7.5px] sm:text-[8.5px] text-slate-400 font-bold tracking-widest uppercase">PINOLE (Z)</span>
                </div>
 
                {/* XY Horizontal Coordinate Slider Control Handle (D-Pad plate) */}
                <div className="flex flex-col items-center gap-1.5">
                  <div 
                    className="bg-slate-950/95 backdrop-blur-xl p-2 sm:p-3 rounded-full flex flex-col items-center justify-center border border-cyan-500/15 shadow-2xl relative"
                  >
                    
                    {/* D-Pad Container */}
                    <div ref={dpadRef} className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-slate-950 border border-cyan-500/20 relative flex items-center justify-center overflow-hidden transition-transform duration-75">
                      {/* Visual Wenzel Coordinate Cross Lines */}
                      <div className="absolute w-full h-[1px] bg-cyan-500/10 left-0 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <div className="absolute h-full w-[1px] bg-cyan-500/10 top-0 left-1/2 -translate-x-1/2 pointer-events-none" />
                      
                      {/* Grid of 4 Arrow Buttons */}
                      <div className="grid grid-cols-3 grid-rows-3 gap-1 w-[85%] h-[85%] z-10">
                        <div />
                        {/* UP (-Y axis mapping) */}
                        <button
                          onPointerDown={startDPad(0, -1)}
                          onPointerUp={stopDPad}
                          onPointerLeave={stopDPad}
                          onPointerCancel={stopDPad}
                          className="bg-slate-800/80 hover:bg-cyan-600/60 active:bg-cyan-500 rounded flex items-center justify-center select-none shadow transition-colors cursor-pointer border border-cyan-500/10 active:border-cyan-400/50"
                        >
                          <span className="material-symbols-outlined text-cyan-300 text-[18px]">arrow_upward</span>
                        </button>
                        <div />
                        
                        {/* LEFT (-X axis mapping) */}
                        <button
                          onPointerDown={startDPad(-1, 0)}
                          onPointerUp={stopDPad}
                          onPointerLeave={stopDPad}
                          onPointerCancel={stopDPad}
                          className="bg-slate-800/80 hover:bg-cyan-600/60 active:bg-cyan-500 rounded flex items-center justify-center select-none shadow transition-colors cursor-pointer border border-cyan-500/10 active:border-cyan-400/50"
                        >
                          <span className="material-symbols-outlined text-cyan-300 text-[18px]">arrow_backward</span>
                        </button>
                        
                        {/* Center deadzone */}
                        <div className="flex items-center justify-center pointer-events-none">
                          <div className="w-2 h-2 rounded-full bg-cyan-500/20" />
                        </div>
                        
                        {/* RIGHT (+X axis mapping) */}
                        <button
                          onPointerDown={startDPad(1, 0)}
                          onPointerUp={stopDPad}
                          onPointerLeave={stopDPad}
                          onPointerCancel={stopDPad}
                          className="bg-slate-800/80 hover:bg-cyan-600/60 active:bg-cyan-500 rounded flex items-center justify-center select-none shadow transition-colors cursor-pointer border border-cyan-500/10 active:border-cyan-400/50"
                        >
                          <span className="material-symbols-outlined text-cyan-300 text-[18px]">arrow_forward</span>
                        </button>
                        
                        <div />
                        {/* DOWN (+Y axis mapping) */}
                        <button
                          onPointerDown={startDPad(0, 1)}
                          onPointerUp={stopDPad}
                          onPointerLeave={stopDPad}
                          onPointerCancel={stopDPad}
                          className="bg-slate-800/80 hover:bg-cyan-600/60 active:bg-cyan-500 rounded flex items-center justify-center select-none shadow transition-colors cursor-pointer border border-cyan-500/10 active:border-cyan-400/50"
                        >
                          <span className="material-symbols-outlined text-cyan-300 text-[18px]">arrow_downward</span>
                        </button>
                        <div />
                      </div>
                      
                      {/* Axes orientation design labels */}
                      <span className="absolute top-[2px] text-[7.5px] font-mono font-black text-amber-500 pointer-events-none select-none -translate-x-1/2 left-1/2">-Y</span>
                      <span className="absolute bottom-[2px] text-[7.5px] font-mono font-black text-amber-500 pointer-events-none select-none -translate-x-1/2 left-1/2">+Y</span>
                      <span className="absolute left-[2px] text-[7.5px] font-mono font-black text-cyan-400 pointer-events-none select-none -translate-y-1/2 top-1/2">-X</span>
                      <span className="absolute right-[2px] text-[7.5px] font-mono font-black text-cyan-400 pointer-events-none select-none -translate-y-1/2 top-1/2">+X</span>
                    </div>
                  </div>
                  <span className="font-mono text-[8.5px] text-slate-400 font-bold tracking-widest uppercase">TISCH (X/Y)</span>
                </div>
 
                {/* Secondary buttons right toolbar */}
                <div className="flex flex-col gap-2 h-full justify-center select-none">
                  <button 
                    onClick={() => {
                      if (isHeadIndexingRef.current) return;
                      // Home button
                      if (activeLevel.id === '321_alignment') {
                        (window as any).cmmTargetX = -2.0;
                        (window as any).cmmTargetY = 3.0;
                        (window as any).cmmTargetZ = 1.5;
                      } else if (activeLevel.id === 'channel') {
                        (window as any).cmmTargetX = -4.0;
                        (window as any).cmmTargetY = 2.2;
                        (window as any).cmmTargetZ = -2.0;
                      } else if (activeLevel.id === 'expert_channel') {
                        (window as any).cmmTargetX = -4.5;
                        (window as any).cmmTargetY = 2.4;
                        (window as any).cmmTargetZ = -2.5;
                      } else {
                        (window as any).cmmTargetX = 0.0;
                        (window as any).cmmTargetY = 3.5;
                        (window as any).cmmTargetZ = 1.5;
                      }
                    }}
                    className="bg-slate-900/90 hover:bg-slate-800 backdrop-blur-xl h-10 w-10 active:scale-95 rounded-xl flex items-center justify-center text-cyan-200 border border-slate-750 transition-all shadow-lg hover:border-cyan-555" 
                    title="Nullpunkt anfahren"
                  >
                    <span className="material-symbols-outlined text-xl">home</span>
                  </button>

                  {/* Wenzel Speed Override Selector Block */}
                  <div className="flex flex-col gap-1 p-1 bg-slate-900 border border-slate-750 rounded-xl shadow-lg">
                    {/* Crawl - 15% slow precise crawling */}
                    <button 
                      onClick={() => {
                        setMovementSpeed('crawl');
                        (window as any).isRapidSpeedEnabled = false;
                      }}
                      className={`h-9 w-9 rounded-lg flex flex-col items-center justify-center transition-all ${
                        movementSpeed === 'crawl' 
                          ? 'bg-cyan-500/25 border border-cyan-500/50 text-cyan-200' 
                          : 'bg-transparent text-slate-500 hover:text-slate-300 border border-transparent'
                      }`} 
                      title="Kriechgang (Feinmessung - 15%)"
                    >
                      <span className="text-sm">🐢</span>
                      <span className="font-mono text-[7px] font-extrabold">15%</span>
                    </button>

                    {/* Normal - 50% positioning velocity */}
                    <button 
                      onClick={() => {
                        setMovementSpeed('normal');
                        (window as any).isRapidSpeedEnabled = false;
                      }}
                      className={`h-9 w-9 rounded-lg flex flex-col items-center justify-center transition-all ${
                        movementSpeed === 'normal' 
                          ? 'bg-emerald-500/25 border border-emerald-500/50 text-emerald-200' 
                          : 'bg-transparent text-slate-500 hover:text-slate-300 border border-transparent'
                      }`} 
                      title="Halbe Geschwindigkeit (Positionierung - 50%)"
                    >
                      <span className="text-sm">🌓</span>
                      <span className="font-mono text-[7px] font-extrabold">50%</span>
                    </button>

                    {/* Rapid - 100% fast bridge rabbit travel */}
                    <button 
                      onClick={() => {
                        setMovementSpeed('rapid');
                        (window as any).isRapidSpeedEnabled = true;
                      }}
                      className={`h-9 w-9 rounded-lg flex flex-col items-center justify-center transition-all ${
                        movementSpeed === 'rapid' 
                          ? 'bg-amber-500/25 border border-amber-500/50 text-amber-200 animate-pulse' 
                          : 'bg-transparent text-slate-500 hover:text-slate-300 border border-transparent'
                      }`} 
                      title="Eilgang / Turbo-Reise (100%)"
                    >
                      <span className="text-sm">🐇</span>
                      <span className="font-mono text-[7px] font-extrabold">100%</span>
                    </button>
                  </div>

                  <button 
                    onClick={() => {
                      if (isHeadIndexingRef.current) return;
                      // Automate reference sweep sweep test coordinates trigger
                      if (activeLevel.id === 'calibration') {
                        (window as any).cmmTargetX = 0; (window as any).cmmTargetY = 2.52; (window as any).cmmTargetZ = 0;
                      } else if (activeLevel.id === '321_alignment') {
                        (window as any).cmmTargetX = -1.0; (window as any).cmmTargetY = 1.5; (window as any).cmmTargetZ = 0.5;
                      } else if (activeLevel.id === 'cylinder') {
                        (window as any).cmmTargetX = 1.2; (window as any).cmmTargetY = 1.5; (window as any).cmmTargetZ = 0;
                      } else if (activeLevel.id === 'channel') {
                        (window as any).cmmTargetX = -2.85; (window as any).cmmTargetY = 2.2; (window as any).cmmTargetZ = -1.6;
                      } else if (activeLevel.id === 'expert_channel') {
                        (window as any).cmmTargetX = -4.0; (window as any).cmmTargetY = 2.4; (window as any).cmmTargetZ = -2.5;
                      }
                    }}
                    className="bg-slate-900/90 hover:bg-slate-800 backdrop-blur-xl h-10 w-10 active:scale-90 rounded-xl flex items-center justify-center text-emerald-300 border border-slate-750 transition-all shadow-lg hover:border-emerald-555" 
                    title="Ersten Toleranzpunkt auto-anfahren"
                  >
                    <span className="material-symbols-outlined text-xl">play_circle</span>
                  </button>

                  <button 
                    onClick={triggerPanicHomeReset}
                    className="bg-red-600/90 hover:bg-red-500 backdrop-blur-xl h-10 w-10 active:scale-95 rounded-xl flex items-center justify-center text-white border border-red-500/50 transition-all shadow-lg shadow-red-500/20" 
                    title="Not-Halt Autohome"
                  >
                    <span className="material-symbols-outlined text-lg">stop_circle</span>
                  </button>
                </div>
              </div>
 
              {/* Action shortcuts under Joystick */}
              <div className="flex gap-4 w-full pr-1 font-sans font-extrabold">
                <button 
                  onClick={() => {
                    restartLevelTask();
                    // Choose next workpiece
                    const nextIdx = (activeLevelIdx + 1) % levels.length;
                    setActiveLevelIdx(nextIdx);
                    playCmmSound('success');
                  }}
                  className="flex-1 bg-slate-900/95 border border-slate-755 hover:bg-slate-800 py-3.5 rounded-2xl flex items-center justify-center gap-2.5 backdrop-blur-xl transition-all shadow-md group active:scale-95 text-slate-100"
                >
                  <span className="material-symbols-outlined text-slate-200 group-hover:rotate-12 transition-transform text-lg">upload_file</span>
                  <span className="font-mono text-[9px] text-slate-205 font-extrabold tracking-wider">NÄCHSTES BAUTEIL</span>
                </button>
                <div className="flex-1 bg-slate-900/95 border border-slate-755 py-3.5 rounded-2xl flex items-center justify-center gap-2.5 backdrop-blur-xl transition-all shadow-inner text-slate-500 cursor-not-allowed">
                  <span className="material-symbols-outlined text-slate-600 text-lg">sensors</span>
                  <span className="font-mono text-[9px] font-bold tracking-wider">AUTO-TASTEN</span>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: DATEN (Inspections and quality protocol dashboard) */}
        {activeTab === 'daten' && (
          <div className="w-full max-w-5xl mx-auto pointer-events-auto bg-slate-950/95 backdrop-blur-3xl p-6 rounded-2xl border border-cyan-500/15 overflow-y-auto max-h-[calc(100vh-200px)] shadow-2xl select-text">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-cyan-400 text-2xl">monitoring</span>
                <div>
                  <h2 className="text-base font-bold text-slate-100 uppercase">Qualitätssicherungs-Protokoll</h2>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">Teilenummer: QA-RENI-{(activeLevelIdx*100).toFixed(0)} | Werkstück: {activeLevel.name}</p>
                </div>
              </div>

              {/* Tolerances certificate chip badges */}
              <div className="flex gap-2 items-center">
                <button
                  onClick={() => setActiveTab('steuern')}
                  className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 px-4 py-1.5 rounded-lg border border-cyan-500/30 text-[10px] font-bold uppercase transition flex items-center gap-1 cursor-pointer mr-2"
                >
                  <span className="material-symbols-outlined text-[14px]">sports_esports</span>
                  Zum Spiel
                </button>
                <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-right font-mono text-[10px]">
                  <span className="block text-slate-500 uppercase text-[8px] leading-tight">Zul. Abweichung</span>
                  <span className="text-amber-400 font-bold">{activeLevel.tolerance.toFixed(3)} mm</span>
                </div>
                <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-right font-mono text-[10px]">
                  <span className="block text-slate-500 uppercase text-[8px] leading-tight">Kollisions-Malus</span>
                  <span className="text-orange-400 font-bold">-{collisions * 4.5}%</span>
                </div>
              </div>
            </div>

            {/* Main diagnostic lists grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* Target checklist values table */}
              <div className="lg:col-span-7 space-y-4">
                <h3 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest mb-3">Soll-Ist-Vergleich (Abweichungsanalyse)</h3>
                
                <div className="overflow-x-auto rounded-xl border border-slate-800/80">
                  <table className="w-full text-left font-mono text-[10.5px]">
                    <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
                      <tr>
                        <th className="p-3">Pkt</th>
                        <th className="p-3">Soll (X,Y,Z)</th>
                        <th className="p-3">Abweichung (dx,dy,dz)</th>
                        <th className="p-3 text-right">Fehler Δ</th>
                        <th className="p-3 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850/80 bg-slate-900/35">
                      {targetPoints.map((p) => (
                        <tr 
                          key={p.id} 
                          onClick={() => autoDriveToTargetPoint(p)}
                          className="hover:bg-slate-800/40 cursor-pointer active:bg-cyan-950/30 transition-colors"
                          title="Anklicken, um die CMM-Sonde automatisch zu diesem Soll-Messpunkt fliegen zu lassen (Autopilot-Fahrt)"
                        >
                          <td className="p-3 font-bold text-cyan-400 flex items-center gap-1.5">
                            <span>{p.id}</span>
                            {isBeginnerMode && (
                              <span className="text-[7.5px] tracking-wider bg-cyan-500/10 text-cyan-300 font-extrabold px-1.5 py-0.5 rounded border border-cyan-500/15 animate-pulse">
                                AUTO
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-slate-300">
                            {`${+(p.nominal[0]*100).toFixed(1)}, ${+(p.nominal[2]*100).toFixed(1)}, ${+(p.nominal[1]*100).toFixed(1)}`}
                          </td>
                          <td className="p-3 font-semibold text-slate-400">
                            {p.deviation 
                              ? `${p.deviation[0] >= 0 ? '+' : ''}${p.deviation[0].toFixed(3)} / ${p.deviation[2] >= 0 ? '+' : ''}${p.deviation[2].toFixed(3)} / ${p.deviation[1] >= 0 ? '+' : ''}${p.deviation[1].toFixed(3)}` 
                              : 'Warte auf Tastung...'}
                          </td>
                          <td className={`p-3 text-right font-bold ${
                            p.status === 'pass' ? 'text-emerald-400' :
                            p.status === 'fail' ? 'text-amber-400' : 'text-slate-500'
                          }`}>
                            {p.error ? `${p.error.toFixed(4)} mm` : '-'}
                          </td>
                          <td className="p-3 text-center">
                            <span className={`px-2 py-0.5 rounded text-[8.5px] font-bold ${
                              p.status === 'pass' ? 'bg-emerald-950/60 border border-emerald-500/35 text-emerald-400' :
                              p.status === 'fail' ? 'bg-amber-950/60 border border-amber-500/35 text-amber-400' :
                              'bg-slate-950 border border-slate-800 text-slate-500'
                            }`}>
                              {p.status === 'pass' && 'PASS'}
                              {p.status === 'fail' && 'FAIL'}
                              {p.status === 'pending' && 'OFFEN'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Accuracy feedback checklist indicator */}
                <div className="bg-slate-950/30 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
                  <div className="text-xs leading-normal">
                    <span className="text-slate-400 uppercase font-mono text-[9px] block">Summierte Restabweichung</span>
                    <span className="text-[13px] font-mono text-slate-200 mt-0.5 font-bold">
                      {deviationSum > 0 ? `${(deviationSum).toFixed(4)} mm` : 'Keine Messdaten vorhanden.'}
                    </span>
                  </div>
                  <div className="text-right font-mono text-xs">
                    <span className="text-slate-400 uppercase text-[9px] block">CMM Genauigkeitsbewertung</span>
                    <span className={`text-base font-extrabold mt-0.5 inline-block ${accuracy >= 90 ? 'text-emerald-400' : 'text-orange-400'}`}>{accuracy}%</span>
                  </div>
                </div>
              </div>

              {/* Right Side: Gemini AI Advisor Report Analysis panel */}
              <div className="lg:col-span-5 bg-slate-950/45 p-5 rounded-xl border border-slate-850 flex flex-col justify-start">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-cyan-400 text-lg">auto_awesome</span>
                    <span className="font-mono text-[11px] font-bold text-cyan-400 tracking-wider">GEMINI KI-PROTKOLLANALYSE</span>
                  </div>
                  <span className="text-[8.5px] font-semibold bg-violet-500/10 text-violet-400 border border-violet-500/20 px-2 rounded">PRO-ENGINE</span>
                </div>

                <p className="text-[11px] text-slate-400 leading-normal mb-4">
                  Sende deine real gemessenen Abweichungen an das Gemini Modell. Sie analysiert die Mikrometertoleranzen und stellt ein echtes metrologisches Prüfzertifikat aus.
                </p>

                {aiReport ? (
                  <div className="bg-slate-900/40 p-3.5 rounded-lg border border-slate-800 text-xs leading-relaxed max-h-80 overflow-y-auto whitespace-pre-wrap font-sans text-slate-300">
                    {aiReport}
                    
                    <button 
                      onClick={() => setAiReport(null)}
                      className="mt-4 w-full py-2 bg-slate-850 hover:bg-slate-800 text-xs text-slate-400 font-semibold border border-slate-800 rounded-lg h-9 transition-colors flex items-center justify-center gap-1.5"
                    >
                      Bericht löschen & neu scannen
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center p-6 border border-dashed border-slate-800 rounded-xl text-center bg-slate-900/15">
                    {loadingReport ? (
                      <div className="py-4 flex flex-col items-center gap-3">
                        <div className="w-10 h-10 border-2 border-cyan-500 border-t-transparent animate-spin rounded-full" />
                        <span className="font-mono text-[10.5px] text-cyan-400 animate-pulse">Analysiere Form- und Lageabweichungen mit Gemini...</span>
                      </div>
                    ) : (
                      <>
                        <span className="material-symbols-outlined text-slate-600 text-4xl mb-2">analytics</span>
                        <span className="text-xs text-slate-400 font-medium mb-4 block">Noch keine Analyse generiert.</span>
                        <button
                          onClick={generateAiMetrologyReport}
                          disabled={targetPoints.some(p => p.status === 'pending')}
                          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5 ${
                            targetPoints.some(p => p.status === 'pending')
                              ? 'bg-slate-800 text-slate-500 border border-slate-750 cursor-not-allowed'
                              : 'bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-400 hover:to-cyan-500 text-slate-950 shadow-cyan-500/10'
                          }`}
                        >
                          <span className="material-symbols-outlined text-sm font-bold">sync_saved_locally</span>
                          {targetPoints.some(p => p.status === 'pending') ? 'Bitte alle Punkte anmessen' : 'KI-PROTKOLL GENERIEREN'}
                        </button>
                      </>
                    )}

                    {reportError && (
                      <div className="mt-4 text-[10px] text-rose-400 bg-rose-950/20 px-3 py-2 border border-rose-500/20 rounded-lg">
                        ⚠️ Hub-Fehler: {reportError}
                      </div>
                    )}
                  </div>
                )}
              </div>

            </div>

          </div>
        )}

        {/* TAB 3: BIBLIOTHEK (Metrology Customizations of styles and probe geometries) */}
        {activeTab === 'bibliothek' && (
          <div className="w-full max-w-4xl mx-auto pointer-events-auto bg-slate-950/95 backdrop-blur-3xl p-6 rounded-2xl border border-cyan-500/15 select-none shadow-2xl">
            <h2 className="text-base font-bold text-slate-100 uppercase mb-2 border-b border-slate-800 pb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-cyan-400">inventory_2</span>
                KOMPONENTEN- & WERKSTOFFBIBLIOTHEK
              </div>
              <button
                onClick={() => setActiveTab('steuern')}
                className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 px-4 py-1.5 rounded-lg border border-cyan-500/30 text-[10px] font-bold uppercase transition flex items-center gap-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[14px]">sports_esports</span>
                Zum Spiel
              </button>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
              
              {/* Material customizing columns */}
              <div className="space-y-4">
                <h3 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">1. Bauteil-Werkstoffe</h3>
                <p className="text-[11px] text-slate-400 leading-normal">
                  Ändere den Werkstoff des Prüfteils. Dies beeinflusst die Oberflächenrauheit, den Reflexionsgrad und die metallischen Shader-Materialien im 3D-Simulator.
                </p>

                <div className="grid grid-cols-2 gap-3.5">
                  {[
                    { name: 'Alu Matt', desc: 'Silbersandgestrahlt', icon: 'texture' },
                    { name: 'Alu Poliert', desc: 'Hochglänzendes Finish', icon: 'blur_on' },
                    { name: 'Granit Dunkel', desc: 'Hochpräzise Referenz', icon: 'grid_view' },
                    { name: 'Carbonfaser', desc: 'Leichtes Texturmuster', icon: 'grain' }
                  ].map((matOpt) => (
                    <button
                      key={matOpt.name}
                      onClick={() => setMaterial(matOpt.name)}
                      className={`text-left p-3.5 rounded-xl border flex flex-col gap-2 transition-all ${
                        material === matOpt.name
                          ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-300 font-semibold'
                          : 'bg-slate-950/30 border-slate-800/80 text-slate-400 hover:border-slate-750/80 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <span className="material-symbols-outlined text-[15px]">{matOpt.icon}</span>
                        <span className="text-xs uppercase font-mono">{matOpt.name}</span>
                      </div>
                      <span className="text-[9.5px] text-slate-500 italic block">{matOpt.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Taster needle probe geometries */}
              <div className="space-y-4">
                <h3 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">2. Messtaster (Renishaw Rubinstifte)</h3>
                <p className="text-[11px] text-slate-400 leading-normal">
                  Die Kugelgröße korrigiert den gemessenen Tastpunkt-Antastradius. Kleinere Taster dringen tiefer in Spalte ein, während größere Taster raue Flächen glätten.
                </p>

                <div className="space-y-3">
                  {[
                    { size: 1.0, name: 'A-5000-7801 Sensi (Ø 1.0mm)', desc: 'Für Mikrorohrkanäle und ultrafeine Bohrungsflanschen.' },
                    { size: 2.0, name: 'A-5000-3603 Standard (Ø 2.0mm)', desc: 'Hervorragender Kompromiss aus Festigkeit und Bohrungstiefe.' },
                    { size: 4.0, name: 'A-5000-4154 Heavy-Duty (Ø 4.0mm)', desc: 'Sehr formstabil, minimiert Biegungsverluste auf Granitflächen.' }
                  ].map((prb) => (
                    <button
                      key={prb.size}
                      onClick={() => setProbeSize(prb.size)}
                      className={`w-full text-left p-3.5 rounded-xl border flex justify-between items-center transition-all ${
                        probeSize === prb.size
                          ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-300 font-semibold'
                          : 'bg-slate-950/30 border-slate-800/80 text-slate-400 hover:border-slate-750/80 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex flex-col gap-0.5 max-w-[85%]">
                        <span className="text-xs font-mono">{prb.name}</span>
                        <span className="text-[9.5px] text-slate-500 leading-normal font-sans">{prb.desc}</span>
                      </div>
                      <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        probeSize === prb.size ? 'border-cyan-400 bg-cyan-500/10' : 'border-slate-700'
                      }`}>
                        {probeSize === prb.size && <div className="w-2 h-2 rounded-full bg-cyan-400" />}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 4: HILFE (Instructions on CMM and Game rules) */}
        {activeTab === 'hilfe' && (
          <div className="w-full max-w-4xl mx-auto pointer-events-auto bg-slate-950/95 backdrop-blur-3xl p-6 rounded-2xl border border-cyan-500/15 overflow-y-auto max-h-[calc(100vh-200px)] select-text shadow-2xl">
            <h2 className="text-base font-bold text-slate-100 uppercase mb-2 border-b border-slate-800 pb-3 flex items-center gap-2">
              <span className="material-symbols-outlined text-cyan-400">help_center</span>
              BEDIENUNGSANLEITUNG & METROLOGIE-KURSUS
            </h2>

            <div className="space-y-5 text-slate-300 text-xs leading-relaxed mt-4">
              
              <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800">
                <h3 className="text-cyan-400 font-bold mb-1.5 uppercase font-mono tracking-wide">📐 Metrologie 101: Die 3-2-1 Ausrichtung</h3>
                <p className="mb-2">
                  Bevor man messen kann, muss das Bauteil im Raum ausgerichtet werden – das Koordinatensystem der Maschine wird an das Bauteil gebunden. Dies geschieht durch die fundamentale <b>3-2-1 Regel (Räumliche Ausrichtung)</b>:
                </p>
                <ul className="list-disc pl-5 space-y-2 text-slate-400">
                  <li><b>3 Punkte (Hauptebene):</b> Taste 3 Punkte auf einer großen Fläche an. Dies definiert die Z-Achse (Richtung) und fixiert 3 Freiheitsgrade (Translation Z, Rotation X & Y).</li>
                  <li><b>2 Punkte (Rotationsachse):</b> Taste 2 Punkte auf einer langen Seitenkante an. Dies blockiert die Rotation um die Z-Achse und definiert die X-Ausrichtung.</li>
                  <li><b>1 Punkt (Nullpunkt):</b> Taste 1 Punkt an einer Stirnseite an. Dies fixiert die letzte Translation in Y-Richtung und bestimmt den Startnullpunkt (0,0,0).</li>
                </ul>
                <div className="mt-3 p-2 bg-emerald-950/30 border-l-2 border-emerald-500 text-[10px] text-emerald-400">Tipp: Level 2 simuliert genau diesen Aufbau – versuche ihn fehlerfrei abzuarbeiten!</div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950/20 p-4 rounded-xl border border-slate-850">
                  <h3 className="text-cyan-400 font-bold mb-1.5 uppercase font-mono tracking-wide">⚠️ Schaftantastung vermeiden</h3>
                  <p className="text-slate-400">
                    Eine <b>Schaftantastung</b> passiert, wenn nicht die exakt runde Rubinkugel das Bauteil berührt, sondern der zylindrische Tasterschaft. Dies führt zu massiven Messfehlern und verbogener Kinematik!
                    <br/><br/>
                    Um dies zu verhindern: Richte den Sensorkopf (REVO A/B-Winkel) immer exakt orthogonal (90°) zur Werkstückoberfläche aus. In unserem Expertenkanal musst du dies simulieren, indem du den Kopf bei gebogenen Stellen mitschwenkst.
                  </p>
                </div>
                
                <div className="bg-slate-950/20 p-4 rounded-xl border border-slate-850">
                  <h3 className="text-cyan-400 font-bold mb-1.5 uppercase font-mono tracking-wide">🏗️ Stabile Bezüge</h3>
                  <p className="text-slate-400">
                    Ein Bezugssystem ist nur so gut wie seine Basis. Wähle immer möglichst <b>weit auseinander liegende Antastpunkte</b>, um den Hebelarm-Fehler (kinematische Abweichungen) zu minimieren. Ein kleines unsauberes Spänchen auf kurzer Distanz verfälscht die ausgerichtete Raumachse viel stärker als bei weit verteilten Punkten (Stabilität und Dreibein-Prinzip).
                  </p>
                </div>

                <div className="bg-slate-950/20 p-4 rounded-xl border border-slate-850">
                  <h3 className="text-cyan-400 font-bold mb-1.5 uppercase font-mono tracking-wide">🔴 Warum Rubine als Taster?</h3>
                  <p className="text-slate-400">
                    Synthetischer Industrierubin (Monokristallines Aluminiumoxid) ist nach dem Diamanten eines der härtesten bekannten Materialien. Seine mechanische Steifigkeit verhindert Biegungen der Kugel unter Antastdruck, und die spiegelglatt polierte Oberfläche schützt das Werkstück vor Kratzern während die Formvollkommenheit Antastunsicherheiten minimiert.
                  </p>
                </div>
              </div>

              <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800 text-[10.5px] text-slate-400 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-mono font-bold text-slate-200 mb-1">CMM Simulator Entwicklungs-Informationen</h4>
                  <span>Vite React SPA mit Three.js WebGL & Google Gemini 3.5-Flash Analyse-Modul.</span>
                </div>
                <div className="text-right text-slate-500">
                  <span>Version 4.0.2</span>
                </div>
              </div>

            </div>

          </div>
        )}

      </main>

      {/* Fixed bottom industrial frosted Glass Navigation bar menu */}
      <nav className="fixed bottom-0 w-full bg-slate-950/98 backdrop-blur-2xl border-t border-cyan-500/15 flex justify-around items-start h-[calc(76px+env(safe-area-inset-bottom))] px-4 z-50 pt-2 pointer-events-auto">
        
        <button 
          onClick={() => setActiveTab('steuern')}
          className={`flex flex-col items-center justify-center w-1/4 h-12 relative transition-all duration-300 ${
            activeTab === 'steuern' ? 'text-cyan-300' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {activeTab === 'steuern' && (
            <div className="absolute -top-3 w-12 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_12px_#22d3ee]" />
          )}
          <span className="material-symbols-outlined text-2xl">videogame_asset</span>
          <span className="font-sans text-[11.5px] mt-1 font-bold">Steuern</span>
        </button>

        <button 
          onClick={() => setActiveTab('daten')}
          className={`flex flex-col items-center justify-center w-1/4 h-12 relative transition-all duration-300 ${
            activeTab === 'daten' ? 'text-cyan-300' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {activeTab === 'daten' && (
            <div className="absolute -top-3 w-12 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_12px_#22d3ee]" />
          )}
          <span className="material-symbols-outlined text-2xl">monitoring</span>
          <span className="font-sans text-[11.5px] mt-1 font-bold">Daten</span>
        </button>

        <button 
          onClick={() => setActiveTab('bibliothek')}
          className={`flex flex-col items-center justify-center w-1/4 h-12 relative transition-all duration-300 ${
            activeTab === 'bibliothek' ? 'text-cyan-300' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {activeTab === 'bibliothek' && (
            <div className="absolute -top-3 w-12 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_12px_#22d3ee]" />
          )}
          <span className="material-symbols-outlined text-2xl">inventory_2</span>
          <span className="font-sans text-[11.5px] mt-1 font-bold">Bibliothek</span>
        </button>

        <button 
          onClick={() => setActiveTab('hilfe')}
          className={`flex flex-col items-center justify-center w-1/4 h-12 relative transition-all duration-300 ${
            activeTab === 'hilfe' ? 'text-cyan-300' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {activeTab === 'hilfe' && (
            <div className="absolute -top-3 w-12 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_12px_#22d3ee]" />
          )}
          <span className="material-symbols-outlined text-2xl">help_center</span>
          <span className="font-sans text-[11.5px] mt-1 font-bold">Hilfe</span>
        </button>

      </nav>

    </div>
  );
}
