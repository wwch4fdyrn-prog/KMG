import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';
import { GoogleGenAI } from "@google/genai";
import dotenv from 'dotenv';

// Load environment variables for local development
dotenv.config();

export default defineConfig(() => {
  return {
    plugins: [
      react(), 
      tailwindcss(),
      {
        name: 'gemini-api-middleware',
        configureServer(server) {
          server.middlewares.use(async (req, res, next) => {
            if (req.url && req.url.startsWith('/api/gemini/analyze')) {
              if (req.method !== 'POST') {
                res.statusCode = 405;
                res.end(JSON.stringify({ error: 'Method Not Allowed' }));
                return;
              }

              let body = '';
              req.on('data', chunk => {
                body += chunk;
              });

              req.on('end', async () => {
                try {
                  const payload = JSON.parse(body);
                  const { measurements, partName, config } = payload;

                  const apiKey = process.env.GEMINI_API_KEY;
                  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ 
                      error: 'GEMINI_API_KEY ist nicht konfiguriert. Bitte erstelle den API-Key in den AI Studio Secrets.' 
                    }));
                    return;
                  }

                  const ai = new GoogleGenAI({
                    apiKey: apiKey,
                    httpOptions: {
                      headers: {
                        'User-Agent': 'aistudio-build',
                      }
                    }
                  });

                  const prompt = `Du bist ein hochpräziser deutscher Qualitätsprüfingenieur (Metrologe) an einer 3D-Koordinatenmessmaschine (KMG / CMM).
Analysiere die folgenden Messergebnisse für das Werkstück: "${partName}".

Einflussfaktoren:
- Taster: ${config.probeSize} mm Rubin-Messkugel.
- Werkstoff: ${config.material}.
- Toleranzvorgabe: ${config.tolerance} mm.

Messprotokoll-Punkte (Abweichungen von den Sollwerten):
${JSON.stringify(measurements, null, 2)}

Erstelle einen professionellen, detaillierten und leicht verständlichen "Metrologischen Prüfbericht" auf Deutsch.
Der Bericht muss folgende Abschnitte enthalten:
1. Zusammenfassung: Wurde die Toleranz eingehalten? (Zertifikat-Status: BESTANDEN / NICHT BESTANDEN).
2. Detailanalyse: Bespreche die gemessenen Punkte, weise auf besonders kritische Abweichungen (maximalen Fehler / Spannweite) hin. Erkläre wissenschaftlich, was die Abweichung bedeuten könnte (z.B. Temperaturverzug, Achsausrichtungsfehler oder Geometrie-Formfehler).
3. Metrologischer Rat: Gib 2-3 konkrete Tipps, wie die Messgenauigkeit verbessert werden kann (z.B. Einmessen der Tasterkugel, Reduktion von Tasterschaft-Biegung / Cosinus-Fehler, Temperierung auf genau 20 °C, etc.).

Halte den Tonfall absolut professionell, präzise und typisch deutsche-ingenieursmäßig, aber lehrreich und spannend für ein Simulationsspiel.
Verwende glasklares Markdown für eine übersichtliche Präsentation.`;

                  const response = await ai.models.generateContent({
                    model: "gemini-3.5-flash",
                    contents: prompt,
                  });

                  res.writeHead(200, { 'Content-Type': 'application/json' });
                  res.end(JSON.stringify({ text: response.text }));
                } catch (err: any) {
                  res.writeHead(500, { 'Content-Type': 'application/json' });
                  res.end(JSON.stringify({ error: err.message || 'Interner Serverfehler bei der Gemini API Ausführung.' }));
                }
              });
            } else {
              next();
            }
          });
        }
      }
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
